package com.jacsstuff.quizucan.Activities;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.jacsstuff.quiz.Question;
import com.jacsstuff.quiz.QuestionPack;
import com.jacsstuff.quizucan.DummyQuestionLoaderImpl;
import com.jacsstuff.quizucan.JSONParser;
import com.jacsstuff.quizucan.QuestionPackFileManager;
import com.jacsstuff.quizucan.QuestionPackSingleton;
import com.jacsstuff.quizucan.R;
import com.jacsstuff.quizucan.Utils;

import java.io.File;

public class CreateQuizActivity extends AppCompatActivity implements View.OnClickListener {

    private Button configureQuizButton;
    private ListView questionPackList;
    private TextView noQuestionPacksFoundText;
    private Context context;
    private QuestionPackFileManager questionPackFileManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_quiz);
        context = CreateQuizActivity.this;

        setupToolbar();
        questionPackFileManager = new QuestionPackFileManager(context);
        setupViews();
        if(configureQuizButton != null){
            configureQuizButton.setOnClickListener(this);
        }
        assignVisibilityLogic();
        Utils.initializeList(context, questionPackFileManager, questionPackList, noQuestionPacksFoundText, configureQuizButton);
    }

    private void setupViews(){
        noQuestionPacksFoundText = (TextView)findViewById(R.id.no_question_packs_found_text);
        questionPackList = (ListView) findViewById(R.id.listView);
        configureQuizButton = (Button) findViewById(R.id.configureQuizButton);
    }

    private void assignVisibilityLogic(){
        if(!questionPackFileManager.isEmpty()){
            noQuestionPacksFoundText.setVisibility(View.GONE);
        }
        else{
            questionPackList.setVisibility(View.GONE);
        }
    }


    private void setupToolbar(){
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_HOME_AS_UP | ActionBar.DISPLAY_SHOW_TITLE );
    }

    public void onClick(View view) {
        if (view.getId() == R.id.configureQuizButton) {
            new QuizFileLoader().execute("");
         }
    }


    private class QuizFileLoader extends AsyncTask<String, String, Integer> {


        public Integer doInBackground(String... params){

            JSONParser parser = new JSONParser();
            QuestionPackSingleton questionPackSingleton = QuestionPackSingleton.getInstance();
            questionPackSingleton.reset();
            for(File file: questionPackFileManager.getSelectedFiles()){
                String path = file.getAbsolutePath();
                QuestionPack questionPack = parser.parse(path);
                questionPackSingleton.add(questionPack);
            }

            if(questionPackSingleton.isEmpty()) {
                QuestionPack defaultQuestionPack = new QuestionPack("default questions");
                defaultQuestionPack.setDescription("A selection of random questions");
                defaultQuestionPack.addTopic("General Knowledge");
                for(Question question : new DummyQuestionLoaderImpl().loadQuestions()){
                    defaultQuestionPack.addQuestion(question);
                }
                questionPackSingleton.addDefaultQuestionPack(defaultQuestionPack);
            }
            return 1;
        }

        public void onPostExecute(Integer value){
            configureQuizActivity();
        }

    }



    public void configureQuizActivity(){

        Intent intent = new Intent(this, ConfigureQuizActivity.class);
        startActivity(intent);
    }


}