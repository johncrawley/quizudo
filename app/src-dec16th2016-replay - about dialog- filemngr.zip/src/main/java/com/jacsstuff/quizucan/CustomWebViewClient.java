package com.jacsstuff.quizucan;

import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * Created by John on 08/11/2016.
 */
public class CustomWebViewClient extends WebViewClient{

    WebView webView;
    public CustomWebViewClient(WebView webview){
        this.webView = webview;
    }

    @Override
    public void onPageFinished(WebView view, String url) {
        webView.loadUrl("javascript:window.HtmlViewer.showHTML" +
                "(document.getElementsByTagName('html')[0].innerHTML);");
    }
}
