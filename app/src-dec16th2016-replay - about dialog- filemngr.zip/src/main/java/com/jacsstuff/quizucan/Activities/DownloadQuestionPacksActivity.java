package com.jacsstuff.quizucan.Activities;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import static com.jacsstuff.quizucan.Utils.AUTHOR_NAME_INTENT_EXTRA;
import static com.jacsstuff.quizucan.Utils.NO_QUESTIONS_FOUND_RESPONSE;
import static com.jacsstuff.quizucan.Utils.QUESTION_PACK_NAMES_INTENT_EXTRA;
import static com.jacsstuff.quizucan.Utils.RESPONSE_PARSE_ERROR;
import static com.jacsstuff.quizucan.Utils.USER_NOT_FOUND_RESPONSE;

import com.jacsstuff.quizucan.LoadingDialog;
import com.jacsstuff.quizucan.QuestionPackFileManager;
import com.jacsstuff.quizucan.R;
import com.jacsstuff.quizucan.RequestManager;
import com.jacsstuff.quizucan.RequestType;
import com.jacsstuff.quizucan.Utils;
import com.jacsstuff.quizucan.WebViewFactory;

import java.util.HashSet;
import java.util.Set;

public class DownloadQuestionPacksActivity extends AppCompatActivity {

    private Button downloadButton;
    private ListView questionPackList;
    private TextView noQuestionPacksFoundText;
    private Context context;
    protected boolean isResponseGood;
    private Set<String> selectedItems;
    private RequestManager requestManager;
    private QuestionPackFileManager questionPackFileManager;
    private WebView webView;
    protected String [] questionPackNames;
    private String authorName;
    private LoadingDialog loadingDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_download_question_packs);
        context = DownloadQuestionPacksActivity.this;
        setupToolbar();
        requestManager = new RequestManager(context);
        questionPackFileManager = new QuestionPackFileManager(context);
        questionPackNames = getIntent().getStringArrayExtra(QUESTION_PACK_NAMES_INTENT_EXTRA);
        authorName = getIntent().getStringExtra(AUTHOR_NAME_INTENT_EXTRA);
        setToolbarTitle();
        selectedItems = new HashSet<>();
        loadingDialog = new LoadingDialog(context, R.string.download_qp_dialog_message);
        setupViews();
        setViewVisibilityLogic();
        setupKeyboardListener(questionPackNames);
        setupDownloadButtonListener();
        configureMultipleChoiceList(questionPackList, questionPackNames);
    }

    private void setupViews(){
        questionPackList = (ListView)findViewById(R.id.listView);
        downloadButton = (Button)findViewById(R.id.downloadSelectedButton);
        noQuestionPacksFoundText = (TextView)findViewById(R.id.noQuestionPacksAvailableText);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home_enabled_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if(id == R.id.home_menu_item) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }


    private void setupToolbar(){
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        ActionBar actionBar = getSupportActionBar();
        if(actionBar != null){
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayOptions(ActionBar.DISPLAY_HOME_AS_UP | ActionBar.DISPLAY_SHOW_TITLE );
        }
    }

    private void configureMultipleChoiceList(ListView list, String[] items) {
        list.setChoiceMode(AbsListView.CHOICE_MODE_MULTIPLE);
        list.setAdapter(new ArrayAdapter<>(context, android.R.layout.simple_list_item_checked, items));
        list.setSelector(R.color.selectedListItemHidden);
        selectedItems.clear();
    }


    private void setToolbarTitle(){
        String title = getResources().getString(R.string.author_title);
        if(authorName != null){
           title = title.concat(authorName);
        }
        ActionBar actionBar = getSupportActionBar();
        if(actionBar != null){
            actionBar.setTitle(title);
         }
    }


    private void setViewVisibilityLogic(){
        if(questionPackNames.length == 0){
            questionPackList.setVisibility(View.GONE);
            downloadButton.setVisibility(View.GONE);
            return;
        }
        if(noQuestionPacksFoundText != null) {
            noQuestionPacksFoundText.setVisibility(View.GONE);
        }

    }


    private void setupKeyboardListener(final String[] questionPackNames){
        questionPackList.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){
                String questionPackName = questionPackNames[position];
                if(selectedItems.contains(questionPackName)){
                    selectedItems.remove(questionPackName);
                }
                else{
                    selectedItems.add(questionPackName);
                }
                if(selectedItems.isEmpty()){
                    downloadButton.setEnabled(false);
                }
                else{
                    downloadButton.setEnabled(true);
                }
            }
        });
    }


    private void setupDownloadButtonListener(){
        downloadButton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view){
                requestManager.setParameter(Utils.AUTHOR_NAME_PARAM, authorName);
                requestManager.setParameter(Utils.QUIZ_PACK_NAMES_PARAM, selectedItems);
                String requestUrl = requestManager.getUrl(RequestType.GET_QUESTION_PACKS);

                webView = WebViewFactory.getWebview(context, new HttpGrabber());
                loadingDialog.show();
                webView.loadUrl(requestUrl);

            }
        });
    }


    private class HttpGrabber extends AsyncTask<String, String, Integer> {

        String response  = "";
        String toastMessage = "";

        public Integer doInBackground(String... params){

            int downloadCount=0;
            String request = params[0];
            response = Utils.getMessageBody(request);
            
            if(response.equals(RESPONSE_PARSE_ERROR)){
                toastMessage = getResources().getString(R.string.server_error);
            }
            else if(response.contains(USER_NOT_FOUND_RESPONSE)){
                toastMessage = getResources().getString(R.string.user_not_found_message);
            }
            else if(response.contains(NO_QUESTIONS_FOUND_RESPONSE)){
                isResponseGood = true;
                toastMessage = getResources().getString(R.string.user_not_found_message);
            }
            else if(response.isEmpty()){
                toastMessage =  getResources().getString(R.string.server_error_message);
            }
            else{

                Log.i("downloadQP", "downloadCount is: " + downloadCount);
                downloadCount = questionPackFileManager.saveQuizPacksFromResponse(response, authorName);
                Log.i("downloadQP", "downloadCount is now: " + downloadCount);
                isResponseGood = true;
                if(downloadCount == 1){
                    toastMessage =  getResources().getString(R.string.single_download_complete_toast);
                }else {
                    toastMessage = getResources().getString(R.string.download_complete_toast, downloadCount);
                }
            }
            return 1;
        }


        public void onPostExecute(Integer value){

            if(!isResponseGood) {
                Utils.makeToast(context, toastMessage);
            }
            else{
                // make a toast counting number of successful downloaded files
                Utils.makeToast(context, toastMessage);
                configureMultipleChoiceList(questionPackList, questionPackNames);
            }
            loadingDialog.dismiss();
        }

    }

}
