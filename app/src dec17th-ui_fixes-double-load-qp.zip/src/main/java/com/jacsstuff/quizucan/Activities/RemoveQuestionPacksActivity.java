package com.jacsstuff.quizucan.Activities;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.jacsstuff.quizucan.QuestionPackFileManager;
import com.jacsstuff.quizucan.R;
import com.jacsstuff.quizucan.Utils;

public class RemoveQuestionPacksActivity extends AppCompatActivity implements View.OnClickListener {

    private Button deleteSelectedQuestionPacksButton;
    private ListView questionPackList;
    private Context context;
    private TextView noQuestionPacksFoundText;
    private QuestionPackFileManager questionPackFileManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remove_question_packs);
        context = RemoveQuestionPacksActivity.this;
        setupToolbar();
        setupViews();
        questionPackFileManager = new QuestionPackFileManager(context);
        initializeList();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home_enabled_menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if(id == R.id.home_menu_item) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    private void setupToolbar() {
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayOptions(ActionBar.DISPLAY_HOME_AS_UP | ActionBar.DISPLAY_SHOW_TITLE);
        }
    }
    private void setupViews() {

        noQuestionPacksFoundText = (TextView) findViewById(R.id.no_question_packs_found_text);
        questionPackList = (ListView) findViewById(R.id.listView);
        deleteSelectedQuestionPacksButton = (Button) findViewById(R.id.delete_question_packs_button);
        if (deleteSelectedQuestionPacksButton != null) {
            deleteSelectedQuestionPacksButton.setOnClickListener(this);

        }
    }
    public void onClick(View view) {
        if (view.getId() == R.id.delete_question_packs_button) {
            new QuizFileDeleter().execute("");
        }
    }

    private void initializeList(){
        Utils.initializeList(context, questionPackFileManager, questionPackList, noQuestionPacksFoundText, deleteSelectedQuestionPacksButton);
    }

    private class QuizFileDeleter extends AsyncTask<String, String, Integer> {

        String deleteMessage = "";

        public Integer doInBackground(String... params){

            int deletedFilesCount = questionPackFileManager.deleteSelectedFiles(); //Utils.deleteSelectedFiles(context, fileSet);
            if(deletedFilesCount > 1){
                deleteMessage = getResources().getString(R.string.files_deleted, deletedFilesCount);
            }
            else{
                deleteMessage = getResources().getString(R.string.file_deleted);
            }
            return 1;
        }

        public void onPostExecute(Integer value){
            initializeList();
            deleteSelectedQuestionPacksButton.setEnabled(false);
            Utils.makeToast(context, deleteMessage);
        }
    }

}

