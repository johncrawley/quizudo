package com.jacsstuff.quizucan.Activities;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;
import com.jacsstuff.quizucan.list.MenuListAdapter;
import com.jacsstuff.quizucan.list.ListMenuItem;
//import com.jacsstuff.quizucan.Utils;
import com.jacsstuff.quizucan.controller.MainController;
import com.jacsstuff.quizucan.R;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity  {

    private MainController controller;
    private Context context;
    private final int CREATE_QUIZ_BUTTON_ID = 1001;
    private final int MANAGE_QUESTIONS_BUTTON_ID = 1002;
    //private final int TEST_DIALOG_ID = 1003;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = MainActivity.this;
        setupToolbar();
        controller = new MainController(context);
        setupMenuList();

    }

    private void setupToolbar(){
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_activity_menu, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if(id == R.id.about_menu_item) {
            Intent intent = new Intent(this, AboutAppActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    private void setupMenuList(){

        ListView menuList;
        List<ListMenuItem> menuItems;

        menuList = (ListView)findViewById(R.id.listView);
        if(menuList == null){
            return;
        }
        menuItems = new ArrayList<>(2);
        menuItems.add(new ListMenuItem(CREATE_QUIZ_BUTTON_ID, getResources().getString(R.string.main_activity_start_quiz_button)));
        menuItems.add(new ListMenuItem(MANAGE_QUESTIONS_BUTTON_ID, getResources().getString(R.string.manage_questions_button_text)));
        //menuItems.add(new ListMenuItem(TEST_DIALOG_ID, "Test Dialog activity"));
        MenuListAdapter menuListAdapter = new MenuListAdapter(context, R.layout.menu_row, menuItems);

        menuList.setAdapter(menuListAdapter);
        menuList.setChoiceMode(AbsListView.CHOICE_MODE_SINGLE);
        menuList.setSelector(R.color.selectedListItem);
        menuList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                loadActivity(view);
            }
        });

    }

    public void loadActivity(View view){
        int id = (int)view.getTag();
        Intent intent;
        if(id == CREATE_QUIZ_BUTTON_ID){
           controller.execute("new quiz");
       }else if(id == MANAGE_QUESTIONS_BUTTON_ID){
            intent = new Intent(context, PreferencesActivity.class);
            context.startActivity(intent);
        }
        /*
        else if(id == TEST_DIALOG_ID){
            String trivia = getResources().getString(R.string.lorem_ipsum);
            intent = new Intent(context, AnswerDialogActivity.class);
            intent.putExtra(Utils.TRIVIA_INTENT_EXTRA, trivia);
            intent.putExtra(Utils.IS_ANSWER_CORRECT_INTENT_EXTRA, true);
            intent.putExtra(Utils.CORRECT_ANSWER_INTENT_EXTRA, "lorem ipsum");
            context.startActivity(intent);
        }*/
    }
}
