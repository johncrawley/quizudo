package com.jacsstuff.quizucan;

/**
 * Created by John on 12/12/2016.
 *
 * Contains the name and author of a question pack.
 * Also contains a reference to the key that holds the parent questionPackFile in the QuestionPackManager.
 */
public class QuestionPackDetail {

    private int key;
    private String name;
    private String author;

    public QuestionPackDetail(int key, String name, String author){
        this.key = key;
        this.name = name;
        this.author = author;
    }


    public int getKey() {
        return key;
    }

    public String getName() {
        return name;
    }

    public String getAuthor() {
        return author;
    }
}
