package com.jacsstuff.quizucan.list;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.jacsstuff.quizucan.QuestionPackDetail;
import com.jacsstuff.quizucan.R;

import java.util.List;

/**
 * Created by John on 12/12/2016.
 */
public class QuestionPackListAdapter extends ArrayAdapter<QuestionPackDetail> {

    Context context;
    private List<QuestionPackDetail> items;

    public QuestionPackListAdapter(Context context, int textViewResourceId, List<QuestionPackDetail> items){
        super(context, textViewResourceId, items);
        this.context = context;
        this.items = items;
    }



    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        View view = convertView;
        if(view == null){
            LayoutInflater vi = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = vi.inflate(R.layout.question_pack_list_item, null);
        }

        QuestionPackDetail questionPackDetail = items.get(position);
        if(questionPackDetail != null){
            TextView displayName = (TextView)view.findViewById(R.id.displayName);
            TextView authorName = (TextView)view.findViewById(R.id.author);


            if(displayName != null){
                displayName.setText(questionPackDetail.getName());
            }
            if(authorName != null){
                authorName.setText(questionPackDetail.getAuthor());
            }
            view.setTag(questionPackDetail);
        }
        return view;
    }
}
