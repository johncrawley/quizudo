package com.jacsstuff.quizucan;

import android.app.ProgressDialog;
import android.content.Context;

/**
 * Created by John on 14/12/2016.
 */
public class LoadingDialog {


    private ProgressDialog mDialog;

    public LoadingDialog(Context context, int messageId){
            mDialog = new ProgressDialog(context);
            mDialog.setMessage(context.getResources().getString(messageId));
            mDialog.setCancelable(false);

    }

    public void show(){
        mDialog.show();
    }

   public void dismiss(){
       mDialog.hide();
       mDialog.dismiss();
   }


}
