package com.jacsstuff.quizucan;

import android.content.Context;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import static com.jacsstuff.quizucan.Utils.AUTHOR_DELIMITER;

import static com.jacsstuff.quizucan.Utils.QUIZ_PACK_RESPONSE_NAME_IDENTIFIER;
import static com.jacsstuff.quizucan.Utils.FILENAME_EXTENSION;
import static com.jacsstuff.quizucan.Utils.QUIZ_PACK_RESPONSE_DATA_DELIMITER;
import static com.jacsstuff.quizucan.Utils.QUIZ_PACK_RESPONSE_DELIMITER;
/**
 * Created by John on 08/12/2016.
 *
 *  The aim is to supply the name of the author alongside the quiz pack when it is displayed in a list
 *  Without a database, the author will have to be added to the stored filename. This also has the benefit of
 *  being able to store unique files with the same original quiz pack names but from different authors.
 *
 *  When the filename is being displayed, it will have to be modified to look more like a list entry, rather than a
 *  file.
 */
public class QuestionPackFileManager {

    private Context context;
    private Map<Integer, QuestionPackFile> questionPacks;

    //private Map<String, Boolean> selectedQuestionPacks;


    public QuestionPackFileManager(Context context){
        int keyCount = 0;
        this.context = context;
        questionPacks = new HashMap<>();
        for(File file: getStoredQuizFiles(context)){
            questionPacks.put(keyCount, new QuestionPackFile(file, keyCount));
            keyCount++;
        }
    }


    public List<File> getSelectedFiles(){
        List<File> files = new ArrayList<>();
        for(int key : questionPacks.keySet()){
            QuestionPackFile questionPackFile = questionPacks.get(key);
            if(questionPackFile.isSelected()) {
                files.add(questionPacks.get(key).getFile());
            }
        }
        return files;
    }

    public String createFilename(String originalFilename, String author){

        return author + AUTHOR_DELIMITER + originalFilename + FILENAME_EXTENSION;
    }


    public int saveQuizPacksFromResponse(String response, String authorName){
        int downloadCount = 0;
        String [] questionPackArray = response.split(QUIZ_PACK_RESPONSE_DELIMITER);

        Log.i("saveQpMethod", "downloadCount initial: "+ downloadCount + ", qp array size: " + questionPackArray.length);
        for(String questionPack : questionPackArray){
            int delimiterIndex = questionPack.indexOf(QUIZ_PACK_RESPONSE_DATA_DELIMITER);
            int nameIdentifierEndIndex = questionPack.indexOf(QUIZ_PACK_RESPONSE_NAME_IDENTIFIER) + QUIZ_PACK_RESPONSE_NAME_IDENTIFIER.length();

            boolean areIndexesWithinBounds = Utils.withinBounds(questionPack, delimiterIndex) && Utils.withinBounds(questionPack, nameIdentifierEndIndex);
            if(areIndexesWithinBounds){
                String name =  questionPack.substring(nameIdentifierEndIndex, delimiterIndex);
                String data =  questionPack.substring(delimiterIndex + 1);
                String filename = createFilename(name, authorName);
                boolean wasDownloadSuccessful =  writeToFile(filename, data.trim());
                if(wasDownloadSuccessful){
                    downloadCount++;
                    Log.i("saveQpMethod", "downloadCount incremented, is now: " + downloadCount);
                }
            }
        }

        Log.i("saveQpMethod", "returning downloadCount, is now: " + downloadCount);
        return downloadCount;
    }

    public boolean hasSomethingSelected(){
        for(int key: questionPacks.keySet()){
            if(questionPacks.get(key).isSelected()){
                return true;
            }
        }
        return false;
    }

    public static List<File> getStoredQuizFiles(Context context){

        String externalPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).toString();
        File externalDir = new File(externalPath);
        File internalDir = context.getFilesDir();
        List <File> files = new ArrayList<>();
        files.addAll(getFilesFromStorage(externalDir));
        files.addAll(getFilesFromStorage(internalDir));

        return files;
    }

    private static boolean isQuizFile(File file){
        return file.getName().endsWith(FILENAME_EXTENSION);
    }


    private static List<File> getFilesFromStorage(File directory){
        File files[] = directory.listFiles();
        if (files == null) {
            return new ArrayList<>();
        }
        List<File> fileList = new ArrayList<>();

        for(File file : files){
            if(isQuizFile(file)){
                fileList.add(file);
            }
        }
        return fileList;
    }


    public List<QuestionPackDetail> getQuestionPackDetails(){
        List<QuestionPackDetail> qpDetails = new ArrayList<>();
        for(int key: questionPacks.keySet()){
            qpDetails.add(questionPacks.get(key).getQuestionPackDetail());
        }
        return qpDetails;
    }



    public void setSelected(QuestionPackDetail questionPackDetail, boolean isSelected){
        int key = questionPackDetail.getKey();
        questionPacks.get(key).setSelected(isSelected);
    }

    // returns the number of selected files that were deleted
    public int deleteSelectedFiles() {
        int deleteCount = 0;
        List <Integer> itemsToDelete = new ArrayList<>();
        for (int key : questionPacks.keySet()) {
            QuestionPackFile qpFile = questionPacks.get(key);
            if (qpFile.isSelected()) {

                itemsToDelete.add(key);
                if (qpFile.delete()) {
                    itemsToDelete.add(key);
                    deleteCount++;
                }
            }
        }
        for(int key : itemsToDelete){
            questionPacks.remove(key);
        }
        return deleteCount;
    }




    protected boolean writeToFile(String filename, String data){

        boolean wasDownloadSuccessful = false;
        FileOutputStream outputStream;

        try {
            outputStream = context.openFileOutput(filename, Context.MODE_PRIVATE);
            outputStream.write(data.getBytes());
            outputStream.close();
            wasDownloadSuccessful = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return wasDownloadSuccessful;
    }


    public boolean isEmpty(){
        return this.questionPacks.isEmpty();
    }

}
