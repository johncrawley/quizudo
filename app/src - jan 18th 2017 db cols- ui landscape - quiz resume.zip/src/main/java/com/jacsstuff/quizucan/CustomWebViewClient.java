package com.jacsstuff.quizucan;

import android.util.Log;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * Created by John on 08/11/2016.
 */
public class CustomWebViewClient extends WebViewClient{

    WebView webView;
    public CustomWebViewClient(WebView webview){
        this.webView = webview;
    }

    @Override
    public void onPageFinished(WebView view, String url) {
        webView.loadUrl("javascript:window.HtmlViewer.showHTML" +
                "(document.getElementsByTagName('html')[0].innerHTML);");
    }

    /**
     * Report web resource loading error to the host application. These errors usually indicate
     * inability to connect to the server. Note that unlike the deprecated version of the callback,
     * the new version will be called for any resource (iframe, image, etc), not just for the main
     * page. Thus, it is recommended to perform minimum required work in this callback.
     * @param view The WebView that is initiating the callback.
     * @param request The originating request.
     * @param error Information about the error occured.
     */
    public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
        Log.i("CustomWebViewClient", "Error recorded!!");
    }

}
