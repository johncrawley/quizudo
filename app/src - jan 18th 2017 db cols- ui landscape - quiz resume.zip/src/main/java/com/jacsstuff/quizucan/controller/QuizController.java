package com.jacsstuff.quizucan.controller;

import android.content.Context;
import android.content.Intent;

import com.jacsstuff.quizucan.Activities.AnswerDialogActivity;
import com.jacsstuff.quizucan.Activities.QuizActivity;
import com.jacsstuff.quizucan.Activities.QuizResultsActivity;
import com.jacsstuff.quizucan.QuestionResultsSingleton;
import com.jacsstuff.quizucan.Quiz;
import com.jacsstuff.quizucan.QuizSingleton;
import com.jacsstuff.quizucan.R;

import java.util.ArrayList;
import java.util.List;

import static com.jacsstuff.quizucan.Utils.IS_ANSWER_CORRECT_INTENT_EXTRA;
import static com.jacsstuff.quizucan.Utils.CORRECT_ANSWER_INTENT_EXTRA;
import static com.jacsstuff.quizucan.Utils.TRIVIA_INTENT_EXTRA;
/**
 * Created by John on 27/06/2016.
 *
 * Handles the bulk of the control logic for the Quiz Activity
 *
 */
public class QuizController {

    private QuizActivity quizActivity;
    private Context context;
    private boolean isDialogActivityStarted = false;
    private Quiz quiz;
    private boolean isAnswerSubmittedOnTouch,isResultDisplayedAfterQuestion;
    private List<Integer> selectedItemPositions;


    public QuizController(QuizActivity quizActivity, int numberOfQuestions, boolean submitAnswerOnTouch, boolean isResultDisplayedAfterQuestion){

        QuizSingleton quizSingleton = QuizSingleton.getInstance();
        quiz = quizSingleton.getQuiz();
        quiz.createQuiz(numberOfQuestions);

        this.quizActivity = quizActivity;
        this.isResultDisplayedAfterQuestion = isResultDisplayedAfterQuestion;
        this.isAnswerSubmittedOnTouch = submitAnswerOnTouch;

        context = quizActivity.getContext();

        loadQuestion();
        setToolbarTitle();
        quizActivity.setAnswerChoices(quiz.getCurrentAnswerChoices());
        if(submitAnswerOnTouch){
            quizActivity.hideNextButton();
        }
    }

    public void setAnswer(int position){
        selectedItemPositions.clear();
        selectedItemPositions.add(position);
    }

    /*
    // at one time there was an idea of adding the option of multiple-selection for answers
    public void setAnswer(int position) {

         boolean isSingleAnswerMode = true; // single-answer-mode means that we only allow one answer to be selected
        // if multiple answers can be selected, there's different logic when keeping track of the chosen answer.

        if (isSingleAnswerMode) {
            selectedItemPositions.clear();
            selectedItemPositions.add(position);
            return;
        }

        if (selectedItemPositions.contains(position)) {
            selectedItemPositions.remove(selectedItemPositions.indexOf(position));
            return;
        }
        selectedItemPositions.add(position);
    }
*/
    public boolean submitAnswer() {

        if (!selectedItemPositions.isEmpty()) {
            quiz.submitAnswers(selectedItemPositions);
            return true;
        }
        return false;
    }


    private void finishQuiz() {
        quiz.finish();
        Intent intent = new Intent(context, QuizResultsActivity.class);
        context.startActivity(intent);
    }


    public String getCurrentCorrectAnswers() {

        List<String> currentCorrectAnswers = quiz.getCurrentCorrectAnswers();
        if (currentCorrectAnswers == null) {
            return "";
        }
        StringBuilder strBuilder = new StringBuilder();
        //if(currentCorrectAnswers.size() == 0){return context.getResources().getString(R.string.no_correct_answer_result_message);}
        //if(currentCorrectAnswers.size() == 1){strBuilder.append(context.getResources().getString(R.string.single_correct_answer_result_message));}
        //else{                                 strBuilder.append(context.getResources().getString(R.string.multiple_correct_answer_result_message));}
        //strBuilder.deleteCharAt(strBuilder.length()-1);
        for (String correctAnswer : currentCorrectAnswers) {
            strBuilder.append(correctAnswer);
            strBuilder.append(", ");
        }
        if(strBuilder.length() > 1) {
            strBuilder.deleteCharAt(strBuilder.length() - 2); //removing the last comma.
        }
        return strBuilder.toString();
    }


    public void loadNextQuestion() {

        if (quiz.isFinalQuestion()) {
            finishQuiz();
        }
        else {
            quiz.nextQuestion();
            loadQuestion();
            setToolbarTitle();
        }
    }

    private void setToolbarTitle(){
        int currentQuestion = quiz.getCurrentQuestionNumber();
        int totalQuestions = quiz.getTotalNumberOfQuestions();
        String title = context.getResources().getString(R.string.quiz_activity_title, currentQuestion, totalQuestions);
        quizActivity.setToolbarTitle(title);
    }


    // this assigns the current question data to the UI Views. It's called once when the quiz
    // starts and then each time the user completes a question (unless that question is the last question).
    public void loadQuestion(){
        quizActivity.setQuestion(quiz.getCurrentQuestionText());
        quizActivity.setQuestionCounter(quiz.getQuestionCounter());
        quizActivity.setAnswerChoices(quiz.getCurrentAnswerChoices());
        selectedItemPositions = new ArrayList<>();

        if(quiz.isFinalQuestion()){
            quizActivity.setNextButtonText(context.getResources().getString(R.string.next_question_button_finish));
        }
    }

    // what happens when the 'next question' button is clicked.
    public void nextButton(){
        if(submitAnswer()) {
            if (isResultDisplayedAfterQuestion) {
                displayResult();
                loadNextQuestion();
                return;
            }
            loadNextQuestion();
        }
    }

    private void displayResult(){
        isDialogActivityStarted = true;
        if(quiz.isCurrentAnswerCorrect()) {
            displayResultDialog(true, quiz.getCurrentQuestionTrivia(), getCurrentCorrectAnswers());
            return;
        }
        displayResultDialog(false, quiz.getCurrentQuestionTrivia(), getCurrentCorrectAnswers());
    }

    public void notifyQuizResumed(){
        if(isDialogActivityStarted){
            isDialogActivityStarted = false;
            loadNextQuestion();
        }

    }

    public void displayResultDialog(boolean isCorrect, String trivia, String correctAnswer){

        Intent intent = new Intent(context, AnswerDialogActivity.class);
        if(trivia == null){
            trivia = "";
        }
        if(correctAnswer == null){
            correctAnswer = "";
        }
        intent.putExtra(TRIVIA_INTENT_EXTRA, trivia);
        intent.putExtra(IS_ANSWER_CORRECT_INTENT_EXTRA, isCorrect);
        intent.putExtra(CORRECT_ANSWER_INTENT_EXTRA, correctAnswer);
        context.startActivity(intent);
    }

    public void answerItemClick(int position){
        setAnswer(position);
        if(isAnswerSubmittedOnTouch){
            submitAnswer();
            if(isResultDisplayedAfterQuestion){
                displayResult();
            }
            else{
                loadNextQuestion();
            }
        }
    }


    public void resultClick(){
            loadNextQuestion();
            quizActivity.hideResultView();

    }


}
