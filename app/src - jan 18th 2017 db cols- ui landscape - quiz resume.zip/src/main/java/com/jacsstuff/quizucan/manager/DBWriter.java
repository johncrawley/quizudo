package com.jacsstuff.quizucan.manager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.jacsstuff.quiz.Question;
import com.jacsstuff.quizucan.JSONParser;
import com.jacsstuff.quizucan.QuestionPackDetail;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;


/**
 * Created by John on 31/12/2016.
 *
 *
 * Used for writing question pack and question data to the DB
 */
public class DBWriter {

    QuestionPackDBHelper mDbHelper;

    public DBWriter(Context context){

        mDbHelper = QuestionPackDBHelper.getInstance(context);
    }


    public boolean addQuestionPack(String data){
        JSONParser parser = new JSONParser();
        QuestionPackDBDetail questionPack = parser.parseQuestionPackFromJson(data);
        SQLiteDatabase db = mDbHelper.getWritableDatabase();
        db.beginTransaction();
        deleteQuestionPackWithUniqueName(db, questionPack.getUniqueName());
        db.setTransactionSuccessful();
        db.endTransaction();

        db.beginTransaction();
        long qpRowId = addQuestionPackRecord(questionPack, db);

        if(questionPack.getQuestionDetails() == null){
            db.endTransaction();
            closeConnection();
            return false; // transaction was not successful.
        }

        for(QuestionDBDetail question : questionPack.getQuestionDetails()){
            addQuestion(question, db, qpRowId);
        }
        db.setTransactionSuccessful();
        db.endTransaction();
        //closeConnection();
        return true; //transaction was successful.
    }

    public int deleteQuestionPacks(Set<String> uniqueNames){

        int deleteCount = 0;
        for( String uniqueName : uniqueNames){

            if(deleteQuestionPack(uniqueName)){
                deleteCount++;
            }
        }
        return deleteCount;
    }

    private boolean deleteQuestionPack(String uniqueName){
        SQLiteDatabase db = mDbHelper.getWritableDatabase();
        db.beginTransaction();

            if(!deleteQuestionPackWithUniqueName(db, uniqueName)){
                db.endTransaction();
                return false;
            }

        db.setTransactionSuccessful();
        db.endTransaction();
        return true;
    }

    private boolean deleteQuestionPackWithUniqueName(SQLiteDatabase db, String uniqueName){

        String getIdQuery = "SELECT " + DbContract.QuestionPackEntry._ID +
                            " FROM  " + DbContract.QuestionPackEntry.TABLE_NAME +
                            " WHERE " + DbContract.QuestionPackEntry.COLUMN_NAME_UNIQUE_NAME + " = " +
                            "'" +   uniqueName + "';" ;

        Cursor cursor = db.rawQuery(getIdQuery, null);

        long questionPackId = -1;
        while(cursor.moveToNext()){
            questionPackId = getLong( cursor, DbContract.QuestionPackEntry._ID);
        }
        cursor.close();

        if(questionPackId != -1){
            // i.e. return true(success) if both the questions and question pack are deleted.
            return deleteQuestions(db, questionPackId) && deleteQuestionPackRow(db, questionPackId);
        }
        return false;
    }

    private boolean deleteQuestionPackRow(SQLiteDatabase db, long questionPackId){

        String query = "DELETE FROM " + DbContract.QuestionPackEntry.TABLE_NAME +
                " WHERE " + DbContract.QuestionPackEntry._ID + " = " +
                questionPackId + ";" ;
        return runQuery(db, query);
    }

    private boolean deleteQuestions(SQLiteDatabase db, long questionPackId) {

        String query =  "DELETE FROM "  + DbContract.QuestionsEntry.TABLE_NAME +
                        " WHERE "       + DbContract.QuestionsEntry.COLUMN_NAME_QUESTION_PACK_ID +
                        " = " + questionPackId + ";" ;
        return runQuery(db, query);
    }

    private boolean runQuery(SQLiteDatabase db, String query){
        boolean isSuccessful = true;
        try {
            db.execSQL(query);
        }catch(SQLException e){
            e.printStackTrace();
            isSuccessful = false;
        }
        return isSuccessful;


    }

    private void addQuestion(QuestionDBDetail q, SQLiteDatabase db , long questionPackRowId){

        ContentValues questionValues = new ContentValues();
        questionValues.put(DbContract.QuestionsEntry.COLUMN_NAME_QUESTION, q.getQuestion());
        questionValues.put(DbContract.QuestionsEntry.COLUMN_NAME_QUESTION_PACK_ID, questionPackRowId);
        questionValues.put(DbContract.QuestionsEntry.COLUMN_NAME_TOPICS, q.getTopics());
        questionValues.put(DbContract.QuestionsEntry.COLUMN_NAME_TOPICS, q.getDifficulty());
        questionValues.put(DbContract.QuestionsEntry.COLUMN_NAME_FLAGS, q.getFlags());
        try {
            db.insertOrThrow(DbContract.QuestionsEntry.TABLE_NAME, null, questionValues);
        }catch(SQLException e){
            e.printStackTrace();
            db.endTransaction();
        }
    }


    private long addQuestionPackRecord(QuestionPackDBDetail qp, SQLiteDatabase db ){
        ContentValues questionPackValues = new ContentValues();

        questionPackValues.put(DbContract.QuestionPackEntry.COLUMN_NAME_AUTHOR,             qp.getAuthor());
        questionPackValues.put(DbContract.QuestionPackEntry.COLUMN_NAME_TITLE,              qp.getName());
        questionPackValues.put(DbContract.QuestionPackEntry.COLUMN_NAME_VERSION,            qp.getVersion());
        questionPackValues.put(DbContract.QuestionPackEntry.COLUMN_NAME_UNIQUE_NAME,        qp.getUniqueName());
        questionPackValues.put(DbContract.QuestionPackEntry.COLUMN_NAME_DATE_DOWNLOADED,    qp.getDateDownloaded());
        questionPackValues.put(DbContract.QuestionPackEntry.COLUMN_NAME_DATE_CREATED,       qp.getDateCreated());
        questionPackValues.put(DbContract.QuestionPackEntry.COLUMN_NAME_DESCRIPTION,        qp.getDescription());
        questionPackValues.put(DbContract.QuestionPackEntry.COLUMN_NAME_DIFFICULTY,          qp.getDifficulty());
        questionPackValues.put(DbContract.QuestionPackEntry.COLUMN_NAME_NUMBER_OF_QUESTIONS,qp.getNumberOfQuestions());
        // returns the ID for the question pack, which will be used by each related question
        return db.insert(DbContract.QuestionPackEntry.TABLE_NAME, null, questionPackValues);
    }


    public Map<Integer, QuestionPackDetail> getQuestionPackDetails(){

        Log.i("DBWriter", "Entered getQuestionPackDetails()");
      //  SQLiteDatabase db = mDbHelper.getReadableDatabase();
        SQLiteDatabase db = mDbHelper.getWritableDatabase();
    /*
        // Define a projection that specifies which columns from the database
        // you will actually use after this query.
        String[] projection = {
                DbContract.QuestionPackEntry._ID,
                DbContract.QuestionPackEntry.COLUMN_NAME_TITLE,
                DbContract.QuestionPackEntry.COLUMN_NAME_DATE_CREATED,
                DbContract.QuestionPackEntry.COLUMN_NAME_DATE_DOWNLOADED,
                DbContract.QuestionPackEntry.COLUMN_NAME_AUTHOR,
                DbContract.QuestionPackEntry.COLUMN_NAME_UNIQUE_NAME,
                DbContract.QuestionPackEntry.COLUMN_NAME_VERSION,
                DbContract.QuestionPackEntry.COLUMN_NAME_NUMBER_OF_QUESTIONS,
                DbContract.QuestionPackEntry.COLUMN_NAME_DESCRIPTION
        };

        // Filter results WHERE "title" = 'My Title'
        //String selection = DbContract.QuestionPackEntry.COLUMN_NAME_TITLE + " = ?";
        String selection = DbContract.QuestionPackEntry.COLUMN_NAME_UNIQUE_NAME + " = ?";
        String[] selectionArgs = { "*" };

        // How you want the results sorted in the resulting Cursor
        String sortOrder = DbContract.QuestionPackEntry.COLUMN_NAME_TITLE + " DESC";

        Cursor cursor = db.query(
                DbContract.QuestionPackEntry.TABLE_NAME,                     // The table to query
                projection,                               // The columns to return
                selection,                                // The columns for the WHERE clause
                selectionArgs,                            // The values for the WHERE clause
                null,                                     // don't group the rows
                null,                                     // don't filter by row groups
                sortOrder                                 // The sort order
        );
        */

        String query2 = "SELECT * FROM "  + DbContract.QuestionPackEntry.TABLE_NAME + ";";
        Cursor cursor =  db.rawQuery(query2, null);
        Map<Integer, QuestionPackDetail> qpDetailsMap = new HashMap<>();
        QuestionPackDetail qpDetail;
        int counter = 0;
        while(cursor.moveToNext()) {
            qpDetail = new QuestionPackDetail();
            qpDetail.setName             (getString( cursor, DbContract.QuestionPackEntry.COLUMN_NAME_TITLE));
            qpDetail.setDescription      (getString( cursor, DbContract.QuestionPackEntry.COLUMN_NAME_DESCRIPTION));
            qpDetail.setUniqueName       (getString( cursor, DbContract.QuestionPackEntry.COLUMN_NAME_UNIQUE_NAME));
            qpDetail.setAuthor           (getString( cursor, DbContract.QuestionPackEntry.COLUMN_NAME_AUTHOR));
            qpDetail.setDateCreated      (getString( cursor, DbContract.QuestionPackEntry.COLUMN_NAME_DATE_CREATED));
            qpDetail.setVersion          (getInt(    cursor, DbContract.QuestionPackEntry.COLUMN_NAME_VERSION));
            qpDetail.setNumberOfQuestions(getInt(    cursor, DbContract.QuestionPackEntry.COLUMN_NAME_NUMBER_OF_QUESTIONS));
            qpDetail.setDateDownloaded   (getLong(   cursor, DbContract.QuestionPackEntry.COLUMN_NAME_DATE_DOWNLOADED));
            qpDetail.setId               (getLong(   cursor, DbContract.QuestionPackEntry._ID));
            qpDetail.setKey(counter);

            qpDetailsMap.put(counter, qpDetail);
            counter++;
        }
        cursor.close();
        return qpDetailsMap;
    }

    public int getQuestionsCount(SQLiteDatabase db){
        db.beginTransaction();
        String query = "SELECT * FROM " + DbContract.QuestionsEntry.TABLE_NAME + ";";
        Cursor cursor = db.rawQuery(query, null);
        int count = cursor.getCount();
        cursor.close();
        db.setTransactionSuccessful();
        db.endTransaction();
        return count;
    }


    public List<Question> getQuestions(Set<Long> questionPackRowIds){

        List<Question> questions = new ArrayList<>();
        SQLiteDatabase db = mDbHelper.getWritableDatabase();
        String criteria = deriveInCriteria(questionPackRowIds);

        String query = "SELECT "    + DbContract.QuestionsEntry.COLUMN_NAME_QUESTION
                    + " FROM "      + DbContract.QuestionsEntry.TABLE_NAME
                    + " WHERE "     + DbContract.QuestionsEntry.COLUMN_NAME_QUESTION_PACK_ID
                    + " IN "        + criteria;

        Cursor cursor = db.rawQuery(query, null);
        JSONParser jsonParser = new JSONParser();
        while(cursor.moveToNext()) {
            Question question = jsonParser.parseQuestion(getString( cursor, DbContract.QuestionsEntry.COLUMN_NAME_QUESTION));
            if(question != null){
                questions.add(question);
            }
        }
        cursor.close();
        return questions;
    }

    public void closeConnection(){
        //mDbHelper.close();
    }

    private String deriveInCriteria(Set <Long> questionPackRowIds){

        StringBuilder str = new StringBuilder();
        str.append("( ");
        for ( long qpRowId :questionPackRowIds ) {
            str.append(qpRowId);
            str.append(" ,");
        }
        str.deleteCharAt(str.lastIndexOf(","));
        str.append(" )");
        return str.toString();
    }

    private String getString(Cursor cursor, String name){
        return cursor.getString(cursor.getColumnIndexOrThrow(name));
    }


    private int getInt(Cursor cursor, String name){
        return cursor.getInt(cursor.getColumnIndexOrThrow(name));
    }

    private long getLong(Cursor cursor, String name){
        return cursor.getLong(cursor.getColumnIndexOrThrow(name));
    }




}
