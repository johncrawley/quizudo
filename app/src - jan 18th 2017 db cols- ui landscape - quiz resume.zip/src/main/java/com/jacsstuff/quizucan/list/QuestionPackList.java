package com.jacsstuff.quizucan.list;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.ListView;
import android.widget.TextView;

import com.jacsstuff.quizucan.QuestionPackDetail;
import com.jacsstuff.quizucan.R;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by John on 27/12/2016.
 *
 * This class groups together a list used to display question pack items,
 *  the textView that is shown when no question pack items are in the list,
 *  and the button that performs the action on the selected question pack items.
 *
 * The action performed by the button will change per activity, so there is a public method
 *  that allows the caller to specify an OnClickListener for it.
 *
 */
public class QuestionPackList {

    protected ListView listView; //the list that contains  the question pack items
    protected Button buttonView; // the button that initiates the action to be performed on the selected list items
    protected TextView noQuestionPacksFoundText; // the text that will appear when there are no list items to display
    protected Context context;
    private Map <Integer, Boolean> isSelectedMap;
    protected Activity activity;

/*
    public QuestionPackList(Context context, Activity a, int listId, int buttonId, int textId){
        this.context = context;
        this.activity = a;
        listView = (ListView)getView(listId);
        buttonView = (Button)getView(buttonId);
        noQuestionPacksFoundText = (TextView)getView(textId);
        isSelectedMap = new HashMap<>();
    }
*/

    public QuestionPackList(Context context, Activity a){
        this.context = context;
        this.activity = a;
        isSelectedMap = new HashMap<>();
    }

    public void setButtonView(int buttonId){
        buttonView = (Button)getView(buttonId);
    }

    public void setListView(int listId){
        listView = (ListView)getView(listId);
    }
    public void setTextView(int textId){
        noQuestionPacksFoundText = (TextView)getView(textId);
    }

    public void disableButton(){
        buttonView.setEnabled(false);
    }

    private View getView(int id){
        return activity.findViewById(id);
    }

    public void setButtonOnClick(View.OnClickListener listener){
        buttonView.setOnClickListener(listener);
    }

    public void initializeList(final List<QuestionPackDetail> questionPackDetails){

        setupViews(!questionPackDetails.isEmpty());
        ArrayAdapter arrayAdapter = new QuestionPackListAdapter(context, android.R.layout.simple_list_item_checked, questionPackDetails);
        setListViewOptions(arrayAdapter);
        setupListClickListener();
        disableButton();
    }

    protected void setupViews(boolean areItemsPresent){
        if(areItemsPresent){
            setupViewsForItemsPresent();
            return;
        }
        setupViewsForItemsNotPresent();
    }

    private void setupViewsForItemsPresent(){
        noQuestionPacksFoundText.setVisibility(View.GONE);
    }

    private void setupViewsForItemsNotPresent(){
        listView.setVisibility(View.GONE);
        buttonView.setVisibility(View.GONE);
        noQuestionPacksFoundText.setVisibility(View.VISIBLE);
    }

    protected void setListViewOptions(ArrayAdapter arrayAdapter){

        listView.setChoiceMode(AbsListView.CHOICE_MODE_MULTIPLE);
        listView.setAdapter(arrayAdapter);
        listView.setSelector(R.color.selectedListItemHidden);
    }





    protected void setupListClickListener(){
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){

                ViewGroup layout = (ViewGroup)view;
                CheckedTextView checkedTextItem = (CheckedTextView)layout.getChildAt(1);
                boolean isChecked = checkedTextItem.isChecked();
                isChecked = !isChecked;
                checkedTextItem.setChecked(isChecked);
                int questionPackId = (int)view.getTag();
                isSelectedMap.put(questionPackId, isChecked);

                if(!isSomethingSelected(isSelectedMap)){
                    buttonView.setEnabled(false);
                }
                else{
                    buttonView.setEnabled(true);
                }
            }
        });
    }


    private static boolean isSomethingSelected(Map<Integer, Boolean> itemsMap){

        boolean isSomethingSelected = false;
        for(int tempKey: itemsMap.keySet()){
            if(itemsMap.get(tempKey)){
                isSomethingSelected = true;
                break;
            }
        }
        return isSomethingSelected;
    }


    public Set<Integer> getSelectedIds(){
        return isSelectedMap.keySet();
    }
}




