package com.jacsstuff.quizucan.list;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by John on 29/12/2016.
 *
 * Simple version of the Question Pack List that only displays the strings and returns selected strings.
 */
public class QuestionPackSimpleList extends QuestionPackList{


    // maybe put the simple list stuff into a new class
    private String[] questionPackNames;
    private Set<String> selectedItems;

    public QuestionPackSimpleList(Context context, Activity a){
        super(context, a);
        selectedItems = new HashSet<>();
    }


    public void initializeSimpleList(final String[] questionPackNames){
        setupViews(questionPackNames.length > 0);
        this.questionPackNames = questionPackNames;
        selectedItems.clear();
        ArrayAdapter arrayAdapter = new ArrayAdapter<>(context, android.R.layout.simple_list_item_checked, questionPackNames);
        setListViewOptions(arrayAdapter);
        setupListClickListener();
        disableButton();
    }

    @Override
    protected void setupListClickListener(){
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){
                String questionPackName = questionPackNames[position];
                if(selectedItems.contains(questionPackName)){
                    selectedItems.remove(questionPackName);
                }
                else{
                    selectedItems.add(questionPackName);
                }
                if(selectedItems.isEmpty()){
                    buttonView.setEnabled(false);
                }
                else{
                    buttonView.setEnabled(true);
                }
            }
        });
    }



    public Set<String> getSelectedStrings(){
        return this.selectedItems;

    }

}
