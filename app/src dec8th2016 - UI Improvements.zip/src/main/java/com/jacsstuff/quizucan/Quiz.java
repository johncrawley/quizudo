package com.jacsstuff.quizucan;

import android.util.Log;

import com.jacsstuff.quiz.Question;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Created by John on 25/06/2016.
 */
public class Quiz {

    private int maxNumberOfQuestions;
    private int questionIndex;
    private List<Question> questions;
    private Question currentQuestion;
    private Random random;
    private List<String> currentAnswerChoices;
    private QuestionResultsSingleton singletonResultsStore;

    private boolean isCurrentAnswerCorrect;
    private String currentTrivia;

    public Quiz(){
        questions = new ArrayList<>();
        random = new Random(System.currentTimeMillis()/1000L);
        singletonResultsStore = QuestionResultsSingleton.getInstance();
    }



    public void createQuiz(int maxNumberOfQuestions, List<String> topics){

        random = new Random(System.currentTimeMillis()/1000L);
        this.maxNumberOfQuestions = maxNumberOfQuestions;
        questionIndex = 0; //init at -1, because first question is index 0, and
        singletonResultsStore = QuestionResultsSingleton.getInstance();
        singletonResultsStore.resetResults();

        if(questions == null){
            Log.i("Quiz - createQuiz()", "questions list is null before loading from store.");
        }


        QuestionPackSingleton questionPacks = QuestionPackSingleton.getInstance();
        questions.addAll(questionPacks.getQuestions());

        if(questions!= null && !questions.isEmpty()) {
            // saving this for call to nextQuestion() so we  can start with an index of -1 and then
            // increment it to 0
            currentQuestion = questions.get(questionIndex);
            Collections.shuffle(questions, random);
            currentQuestion = questions.get(questionIndex);
        }
        else{
            Log.i("Quiz - createQuiz()", "questions list is null or empty");
        }
    }



    public void submitAnswers(List <Integer> selectedAnswerPositions){
        List <String> chosenAnswers = new ArrayList<>();
        for(int position : selectedAnswerPositions){
            chosenAnswers.add(currentAnswerChoices.get(position));
        }

        QuestionResult questionResult = new QuestionResult(currentQuestion, questionIndex + 1, chosenAnswers);
        isCurrentAnswerCorrect = questionResult.wasAnsweredCorrectly();
        questionResult.setQuestionNumber(questionIndex);
        singletonResultsStore.addResult(questionResult);
        //Log.i("Quiz", "#" + questionIndex + ".  answer given: " + asString(chosenAnswers) + "  actual answers: "+ asString(questionResult.getCorrectAnswers()));
    }


    private String asString(List<String> listName){
        StringBuilder str = new StringBuilder();
        if(listName == null){
            return "";
        }
        for(String item:listName){
            str.append(item);
        }
        return str.toString();
    }

    public void printAnswerChoice(int position){
        Log.i("Quiz", "Answer choice at position: " + position + " is: " + currentAnswerChoices.get(position));
    }



    public boolean isFinalQuestion(){
        //Log.i("Quiz isFinalQuestion()", "maxNumberOfQuestions: "+ maxNumberOfQuestions + " questionIndex: " +  questionIndex);
        boolean isFinalQuestion = questionIndex == (maxNumberOfQuestions - 1);
        //Log.i("isFinalQuestion()", "return value: "+  isFinalQuestion + "  questionIndex:" + questionIndex + " maxQuestions: " + maxNumberOfQuestions + " maxQuestions - 1: "+  (maxNumberOfQuestions -1));
        return isFinalQuestion;
    }


    public boolean isSecondLastQuestion(){
        return questionIndex == (maxNumberOfQuestions -2);
    }

    public boolean isLastOrSecondLastQuestion(){
        return isSecondLastQuestion() || isFinalQuestion();
    }

    public void nextQuestion(){
        currentQuestion = questions.get(++questionIndex);
    }


    public int getTotalNumberOfQuestions(){
        return maxNumberOfQuestions;
    }

    public String getQuestionCounter(){
        return questionIndex + 1 + "/" + ( maxNumberOfQuestions);
    }

    public String getCurrentQuestionText(){
        if(currentQuestion != null) {
            return currentQuestion.getQuestionText();
        }
        return "";
    }

    // for display purposes, the first question will be of index 0 in the list,
    // but we want to display it as "Question 1", for example, so adding 1 to the return value.
    public int getCurrentQuestionNumber(){
        return questionIndex + 1;
    }

    public String[] getCurrentAnswerChoices(){
        if(!questions.isEmpty()) {
            currentAnswerChoices = currentQuestion.getAnswerChoices();
            Collections.shuffle(currentAnswerChoices, random);

            return currentAnswerChoices.toArray(new String[currentAnswerChoices.size()]);
        }
        return new String[0];
    }


    public List<String> getCurrentCorrectAnswers(){
        if(!questions.isEmpty()){
           return currentQuestion.getCorrectAnswers();
        }
        return null;
    }

    public String getCurrentQuestionTrivia(){
        if(currentQuestion!= null){
            return currentQuestion.getTrivia();
        }
        return "";
    }

    public boolean isCurrentAnswerCorrect(){
        return isCurrentAnswerCorrect;
    }

    // for a given quiz run, the user specifies what question stores to use
    //  (or rather they are pulled in automatically from a directory on the filesystem)
    // The user will select a number of topics and the questions will be drawn from these topics
    //  So... how to associate questions with topics?
    //  The topic can't just be a collection, since a question can have multiple topics
    //  Each question could have a List of topic tags...
    // If you load a question store with 10,000 questions will it take a long time to find every time a new quiz starts
    // so maybe, on the first time loading a question store, we create an index
    public void addQuestionsFromStores(String topic){

    }

}
