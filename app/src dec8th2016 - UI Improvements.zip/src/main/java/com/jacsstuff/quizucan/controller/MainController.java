package com.jacsstuff.quizucan.controller;

import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.jacsstuff.quizucan.Activities.CreateQuizActivity;
import com.jacsstuff.quizucan.Activities.QuizActivity;

/**
 * Created by John on 27/06/2016.
 */
public class MainController {

    Context context;

    public MainController(Context context){
        this.context = context;
    }

    public void execute(String action){
        switch(action){
            case "new quiz":
                newQuiz();
            case "exit quiz":
                exitQuiz();
        }



    }

    public void newQuiz(){
        Log.i("new Quiz", "Beginning new quiz");
        Intent intent = new Intent(context, CreateQuizActivity.class);
        context.startActivity(intent);
    }

    public void exitQuiz(){

    }
}
