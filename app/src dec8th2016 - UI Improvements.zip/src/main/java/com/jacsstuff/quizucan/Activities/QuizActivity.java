package com.jacsstuff.quizucan.Activities;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.jacsstuff.quizucan.QuestionResultsSingleton;
import com.jacsstuff.quizucan.ResultView;
import com.jacsstuff.quizucan.controller.QuizController;
import com.jacsstuff.quizucan.R;

public class QuizActivity extends AppCompatActivity implements View.OnClickListener{

    ListView answerList;
    TextView questionText;
    TextView questionCounterText;
    Button nextQuestionButton;
    ResultView resultView;
    Context context;
    QuizController quizController;
    boolean isResultDisplayedAfterQuestion;
    boolean isAnswerSubmittedOnTouch;

    protected void onResume(){
        super.onResume();
        QuestionResultsSingleton questionResults = QuestionResultsSingleton.getInstance();
        if(questionResults.isQuizFinished()){
            questionResults.resetResults();
            finish();
        }
        quizController.notifyQuizResumed();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);
        context = QuizActivity.this;

        Intent intent = getIntent();
        int numberOfQuestions = intent.getIntExtra("numberOfQuestions", 10);
        isAnswerSubmittedOnTouch = intent.getBooleanExtra("isAnswerSubmittedOnTouch", false);
        isResultDisplayedAfterQuestion = intent.getBooleanExtra("isResultDisplayedAfterQuestion", false);
        setupToolbar();
        setupViews();

        quizController = new QuizController(this, numberOfQuestions, isAnswerSubmittedOnTouch, isResultDisplayedAfterQuestion);

        answerList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                  quizController.answerItemClick(position);
                }
        });
    }

    private void setupToolbar(){

        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_HOME_AS_UP | ActionBar.DISPLAY_SHOW_TITLE );

    }


    private void setupViews(){
        questionText = (TextView) findViewById(R.id.question_text);
        answerList = (ListView) findViewById(R.id.listView);
        nextQuestionButton = (Button)findViewById(R.id.next_question_button);
        questionCounterText = (TextView)findViewById(R.id.question_counter);
        resultView = (ResultView)findViewById(R.id.resultView);

        if(resultView != null){
            resultView.setVisibility(View.INVISIBLE);
            resultView.setOnClickListener(this);
        }
        nextQuestionButton.setOnClickListener(this);
    }


    public void onClick(View view){
        if(view.getId() == R.id.next_question_button){
            quizController.nextButton();
        }
        if(view.getId() == R.id.resultView){
            quizController.resultClick();
        }

    }

    public void setToolbarTitle(String title){
        getSupportActionBar().setTitle(title);
    }

    public void hideNextButton(){
        this.nextQuestionButton.setVisibility(View.INVISIBLE);
    }



    public void showResultView(boolean isCorrect, String message){
        if(isCorrect){
            resultView.setCorrectAnswer(getResources().getString(R.string.result_overlay_correct_heading), message);
        }
        else{
            resultView.setIncorrectAnswer(getResources().getString(R.string.result_overlay_incorrect_heading), message);
        }

        resultView.setVisibility(View.VISIBLE);
    }



    public void setAnswerChoices(String[] currentAnswerChoices) {
        answerList.setAdapter(new ArrayAdapter<>(context, android.R.layout.simple_list_item_1, currentAnswerChoices));
        answerList.setChoiceMode(AbsListView.CHOICE_MODE_SINGLE);
        answerList.setSelector(R.color.selectedListItem);
    }

    public void setNextButtonText(String newText){
        this.nextQuestionButton.setText(newText);
    }

    public void setQuestion(String questionText){
        this.questionText.setText(questionText);
    }

    public void setQuestionCounter(String counterValue){
        this.questionCounterText.setText(counterValue);
    }


    public void hideResultView(){
        this.resultView.setVisibility(View.INVISIBLE);
    }

    public Context getContext(){
        return this.context;
    }


}