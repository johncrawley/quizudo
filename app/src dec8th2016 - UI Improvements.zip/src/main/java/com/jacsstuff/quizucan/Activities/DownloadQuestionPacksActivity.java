package com.jacsstuff.quizucan.Activities;

import android.content.Context;
import android.os.AsyncTask;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import static com.jacsstuff.quizucan.Utils.AUTHOR_NAME_INTENT_EXTRA;
import static com.jacsstuff.quizucan.Utils.NO_QUESTIONS_FOUND_RESPONSE;
import static com.jacsstuff.quizucan.Utils.QUESTION_PACK_NAMES_INTENT_EXTRA;
import static com.jacsstuff.quizucan.Utils.QUESTION_PACK_REQUEST_DELIMITER;
import static com.jacsstuff.quizucan.Utils.QUIZ_PACK_RESPONSE_NAME_IDENTIFIER;
import static com.jacsstuff.quizucan.Utils.RESPONSE_PARSE_ERROR;
import static com.jacsstuff.quizucan.Utils.USER_NOT_FOUND_RESPONSE;

import com.jacsstuff.quizucan.CustomWebViewClient;
import com.jacsstuff.quizucan.R;
import com.jacsstuff.quizucan.RequestManager;
import com.jacsstuff.quizucan.RequestType;
import com.jacsstuff.quizucan.Utils;
import com.jacsstuff.quizucan.WebViewFactory;

import java.io.FileOutputStream;
import java.util.HashSet;
import java.util.Set;

public class DownloadQuestionPacksActivity extends AppCompatActivity {

    private Button downloadButton;
    private ListView questionPackList;
    private TextView noQuestionPacksFoundText;
    private Context context;
    protected boolean isResponseGood;
    private Set<String> selectedItems;
    private RequestManager requestManager;
    private WebView webView;
    private String [] questionPackNames;
    private String authorName;
    protected int downloadCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_download_question_packs);
        context = DownloadQuestionPacksActivity.this;
        setupToolbar();
        requestManager = new RequestManager(context);

        questionPackNames = getIntent().getStringArrayExtra(QUESTION_PACK_NAMES_INTENT_EXTRA);
        authorName = getIntent().getStringExtra(AUTHOR_NAME_INTENT_EXTRA);
        setToolbarTitle();
        questionPackList = (ListView)findViewById(R.id.listView);
        downloadButton = (Button)findViewById(R.id.downloadSelectedButton);
        noQuestionPacksFoundText = (TextView)findViewById(R.id.noQuestionPacksAvailableText);
        selectedItems = new HashSet<>();

        setViewVisibilityLogic();
        setupKeyboardListener(questionPackNames);
        setupDownloadButtonListener();

        Utils.configureMultipleChoiceList(context, questionPackList, questionPackNames);
    }


    private void setupToolbar(){
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_HOME_AS_UP | ActionBar.DISPLAY_SHOW_TITLE );
    }


    private void setToolbarTitle(){
        String title = getResources().getString(R.string.author_title);
        if(authorName != null){
           title = title.concat(authorName);
        }
        getSupportActionBar().setTitle(title);
    }


    private void setViewVisibilityLogic(){
        if(questionPackNames.length == 0){
            questionPackList.setVisibility(View.GONE);
            downloadButton.setVisibility(View.GONE);
        }
        else{
            if(noQuestionPacksFoundText != null) {
                noQuestionPacksFoundText.setVisibility(View.GONE);
            }
        }
    }


    private void setupKeyboardListener(final String[] questionPackNames){
        questionPackList.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){
                String questionPackName = questionPackNames[position];
                if(selectedItems.contains(questionPackName)){
                    selectedItems.remove(questionPackName);
                }
                else{
                    selectedItems.add(questionPackName);
                }

                if(selectedItems.isEmpty()){
                    downloadButton.setEnabled(false);
                }
                else{
                    downloadButton.setEnabled(true);
                }
            }
        });
    }


    private void setupDownloadButtonListener(){
        downloadButton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view){
                requestManager.setParameter(Utils.AUTHOR_NAME_PARAM, authorName);
                requestManager.setParameter(Utils.QUIZ_PACK_NAMES_PARAM, selectedItems);
                String requestUrl = requestManager.getUrl(RequestType.GET_QUESTION_PACKS);

                webView = WebViewFactory.getWebview(context, new HttpGrabber());
                Log.i("DownloadPacks", "request url: "+  requestUrl);
                webView.loadUrl(requestUrl);

            }
        });
    }

    protected boolean writeToFile(String filename, String data){

        boolean wasDownloadSuccessful = false;
        FileOutputStream outputStream;

        try {
            outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
            outputStream.write(data.getBytes());
            outputStream.close();
            wasDownloadSuccessful = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return wasDownloadSuccessful;
    }


    private class HttpGrabber extends AsyncTask<String, String, Integer> {

        String response  = "";
        String toastMessage = "";
        String questionPackNames = "";

        public Integer doInBackground(String... params){

            questionPackNames = "";
            response = Utils.getMessageBody(params[0]);
            
            if(response.equals(RESPONSE_PARSE_ERROR)){
                toastMessage = getResources().getString(R.string.server_error);
            }
            else if(response.contains(USER_NOT_FOUND_RESPONSE)){
                toastMessage = getResources().getString(R.string.user_not_found_message);
            }
            else if(response.contains(NO_QUESTIONS_FOUND_RESPONSE)){
                isResponseGood = true;
                toastMessage = getResources().getString(R.string.user_not_found_message);
            }
            else if(response.isEmpty()){
                toastMessage =  getResources().getString(R.string.server_error_message);
            }
            else{
                String [] questionPacks = response.split(Utils.QUIZ_PACK_RESPONSE_DELIMITER);
                for(String questionPack : questionPacks){
                    int delimiterIndex = questionPack.indexOf(Utils.QUIZ_PACK_RESPONSE_DATA_DELIMITER);
                    int nameIdentifierEndIndex = questionPack.indexOf(Utils.QUIZ_PACK_RESPONSE_NAME_IDENTIFIER) + QUIZ_PACK_RESPONSE_NAME_IDENTIFIER.length();

                    String name = "not found!";
                    String data = "not found!";

                    boolean areIndexesWithinBounds = Utils.withinBounds(questionPack, delimiterIndex) && Utils.withinBounds(questionPack, nameIdentifierEndIndex);
                    if(areIndexesWithinBounds){
                        name =  questionPack.substring(nameIdentifierEndIndex, delimiterIndex);
                        data =  questionPack.substring(delimiterIndex + 1);
                        boolean wasDownloadSuccessful =  writeToFile(name + Utils.FILENAME_EXTENSION, data.trim());
                        if(wasDownloadSuccessful){
                            downloadCount++;
                        }
                    }
                    Log.i("Download QP " , "name = " + name + " data = " + data);


                }
                toastMessage =  getResources().getString(R.string.download_complete_toast, downloadCount);
                downloadCount = 0;

            }
            return 1;
        }


        public void onPostExecute(Integer value){

            if(!isResponseGood) {
                Utils.makeToast(context, toastMessage);
            }
            else{
                // make a toast counting number of succesful downloaded files
                Utils.makeToast(context, toastMessage);
            }
        }

    }

}
