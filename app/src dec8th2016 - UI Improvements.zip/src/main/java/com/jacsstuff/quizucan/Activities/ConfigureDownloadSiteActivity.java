package com.jacsstuff.quizucan.Activities;

import android.content.Context;
import android.os.AsyncTask;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import com.jacsstuff.quizucan.R;
import com.jacsstuff.quizucan.RequestManager;
import com.jacsstuff.quizucan.RequestType;
import com.jacsstuff.quizucan.Utils;
import com.jacsstuff.quizucan.WebViewFactory;
import static com.jacsstuff.quizucan.Utils.QUIZ_SITE_TEST_EXPECTED_RESPOSE;

public class ConfigureDownloadSiteActivity extends AppCompatActivity {

    private Button testConnectionButton;
    private EditText downloadSiteInputText;
    protected Context context;
    protected String currentSite;
    private RequestManager requestManager;
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_configure_download_site);
        context = ConfigureDownloadSiteActivity.this;
        setupToolbar();
        requestManager = new RequestManager(context);

        testConnectionButton = (Button)findViewById(R.id.test_connection_button);
        downloadSiteInputText = (EditText)findViewById(R.id.download_site_input_text);
        downloadSiteInputText.setText(requestManager.getDownloadSite());

        downloadSiteInputText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    testConnection();
                    return true;
                }
                return false;
            }
        });

        testConnectionButton.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View view){
                testConnection();
            }
        });
    }


    private void setupToolbar(){
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_HOME_AS_UP | ActionBar.DISPLAY_SHOW_TITLE );
    }


    private void testConnection(){
        String newDownloadSite = downloadSiteInputText.getText().toString().trim();

        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(downloadSiteInputText.getWindowToken(), 0);

        String testUrl = requestManager.getTempUrl(newDownloadSite, RequestType.TEST_CONNECTION);
        webView = WebViewFactory.getWebview(context, new HttpGrabber());
        webView.loadUrl(testUrl);
    }


    private class HttpGrabber extends AsyncTask<String, String, Integer> {

        String response  = "";
        boolean isResponseGood = false;
        String toastMessage = "";

        public Integer doInBackground(String... params){
            response = Utils.getMessageBody(params[0]);
            if(response.equals(QUIZ_SITE_TEST_EXPECTED_RESPOSE)){
                isResponseGood = true;
                toastMessage = context.getResources().getString(R.string.test_connection_good);
            }
            else{
                Log.i("ConfigDownloadSite", "bad response: "+  response);
                toastMessage = context.getResources().getString(R.string.test_connection_bad);
            }
            return 1;
        }

        public void onPostExecute(Integer value){
            requestManager.saveDownloadSite(currentSite);
            Utils.makeToast(context, toastMessage);
        }
    }

}
