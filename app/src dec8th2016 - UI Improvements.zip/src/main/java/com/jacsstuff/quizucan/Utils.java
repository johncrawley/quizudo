package com.jacsstuff.quizucan;

import android.accounts.NetworkErrorException;
import android.app.AlertDialog;
import android.content.Context;
import android.os.Environment;
import android.util.Log;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by John on 03/11/2016.
 */
public class Utils {

    public static final String HTTP_PREFIX = "http://";
    public static final String GET_LIST_OF_FILES_REQUEST = "/listAvailableFiles.php";
    public static final String QUESTION_PACK_REQUEST = "/getQuizPacks.php";
    public static final String QUIZ_SITE_TEST_REQUEST = "/test.php";
    public static final String AUTHOR_NAME_PARAM = "userId";
    public static final String QUIZ_PACK_NAMES_PARAM = "names";
    public static final String PARAMS_START = "?";
    public static final String PARAM_EQUALS = "=";
    public static final String PARAM_DELIMITER = "&";
    public static final String QUIZ_SITE_TEST_EXPECTED_RESPOSE = "quizquiz!";
    public static final String USER_NOT_FOUND_RESPONSE = "[User Not Found]";
    public static final String NO_QUESTIONS_FOUND_RESPONSE = "[No Questions Found]";
    public static final String RESPONSE_BRACKETS = "~~~";
    public static final String RESPONSE_PARSE_ERROR = "Response Parse Error.";
    public static final String FILENAME_EXTENSION = ".qzp";
    public static final String QUIZ_PACK_RESPONSE_DELIMITER = "%~~%";
    public static final String QUIZ_PACK_RESPONSE_NAME_IDENTIFIER = "id=";
    public static final String QUIZ_PACK_RESPONSE_DATA_DELIMITER = ",";

    public static final String QUESTION_PACK_NAMES_INTENT_EXTRA = "questionPackNames";
    public static final String AUTHOR_NAME_INTENT_EXTRA = "authorName";
    public static final String QUESTION_PACK_REQUEST_DELIMITER = ",";

    public static final String ADD_QUESTIONS_PREFERENCE = "AddQuestionPacks";
    public static final String REMOVE_QUESTIONS_PREFERENCE = "RemoveQuestionPacks";
    public static final String CONFIGURE_DOWNLOAD_SITE_PREFERENCE = "ConfigureDownloadSite";
    public static final String PREVIOUS_NUMBER_OF_QUESTIONS_PREFERENCE = "previousNumberOfQuestions";
    public static final String PREVIOUS_SUBMIT_ANSWER_ON_TOUCH_PREFERENCE = "submitAnswerOnTouch";
    public static final String PREVIOUS_SHOW_ANSWER_PREFERENCE = "showAnswer";
    public static final int DEFAULT_NUMBER_OF_QUESTIONS = 10;

    public static final String IS_ANSWER_CORRECT_INTENT_EXTRA = "isAnswerCorrect";
    public static final String CORRECT_ANSWER_INTENT_EXTRA = "correctAnswer";
    public static final String TRIVIA_INTENT_EXTRA = "trivia";

    public static List<File> getStoredQuizFiles(Context context){

        String externalPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).toString();
        File externalDir = new File(externalPath);
        File internalDir = context.getFilesDir();
        List <File> files = new ArrayList<>();
        files.addAll(getFilesFromStorage(context, externalDir));
        files.addAll(getFilesFromStorage(context, internalDir));

        return files;
    }

    private static List<File> getFilesFromStorage(Context context, File directory){
        File files[] = directory.listFiles();
        if (files == null) {
            return new ArrayList<File>();
        }
        List<File> fileList = new ArrayList<>();

        for(File file : files){
            if(isQuizFile(file)){
                fileList.add(file);
            }
        }
        return fileList;
    }

    private static boolean isQuizFile(File file){
        return file.getName().endsWith(FILENAME_EXTENSION);
    }

    public static void configureMultipleChoiceList(Context context, ListView list, String[] items) {
        list.setChoiceMode(AbsListView.CHOICE_MODE_MULTIPLE);
        list.setAdapter(new ArrayAdapter<>(context, android.R.layout.simple_list_item_checked, items));
        list.setSelector(R.color.selectedListItemHidden);
    }

    public static boolean withinBounds(String str, int index){
        if(index > -1 && index < str.length()){
            return true;
        }
        return false;
    }


    public boolean isExternalStorageAvailableAndWriteable(){
        boolean externalStorageAvailable = false;
        boolean externalStorageWriteable = false;
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state)) {

            externalStorageAvailable = externalStorageWriteable = true;
            Log.i("storagecheck", "External storage is available and writeable");
        } else if (Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
            externalStorageAvailable = true;
            externalStorageWriteable  = false;

            Log.i("storagecheck", "External storage is available but not writeable!");
        }else{
            externalStorageAvailable = false;
            externalStorageWriteable = false;

            Log.i("storagecheck", "External storage is neither available nor writeable!!!!");
        }
        return (externalStorageWriteable && externalStorageAvailable);
    }

    public static String deleteSelectedFiles(Context context, FileSet fileset){
        List <File> selectedFiles = fileset.getSelectedFiles();
        int selectedFilesNumber = selectedFiles.size();
        int deleteCount = 0;
        for(File file : fileset.getSelectedFiles()){
            boolean deleted =  file.delete();
            if(deleted) {
                deleteCount++;
            }
        }
        String deleteMessage = deleteCount + context.getResources().getString(R.string.files_deleted);
        if(deleteCount == 1){
            deleteMessage = deleteCount + context.getResources().getString(R.string.file_deleted);
        }
       return deleteMessage;
    }


    public static void makeToast(Context context, String deleteMessage){

        Toast.makeText(context, deleteMessage, Toast.LENGTH_SHORT).show();
    }




    public static void sendHTTPWebRequest(Context context, String inputUrl){

        String data = "no data yet";
        final WebView webview = new WebView(context);
        webview.getSettings().setJavaScriptEnabled(true);
        CustomJavaScriptInterface2 jsInterface = new CustomJavaScriptInterface2(context, data);
        webview.addJavascriptInterface(jsInterface, "HtmlViewer");
        CustomWebViewClient webViewClient = new CustomWebViewClient(webview);

        webview.setWebViewClient(webViewClient);
        webview.loadUrl(inputUrl);/*
        Thread thread = webViewClient.getThread();
        try {
            thread.join();
        }catch(InterruptedException e){
            e.printStackTrace();
        }*/

        Log.i("method thread name", Thread.currentThread().getName());
        data = jsInterface.getData();
        Thread jsThread = jsInterface.getThread();

        Log.i("jsthread name", "currently: " + Thread.currentThread().getName());
        /*
        synchronized (jsThread){
            try{
                System.out.println("Waiting for b to complete...");
                jsThread.wait();
            }catch(InterruptedException e){
                e.printStackTrace();
            }
        }
    */
        Log.i("utils", "data is now: " + data);

    }



    static class CustomJavaScriptInterface {
        private Context ctx;

        CustomJavaScriptInterface(Context ctx) {

            this.ctx = ctx;
        }

        @android.webkit.JavascriptInterface
        public void showHTML(String html) {
            Log.i("Utils", "html: "+ html);
        }
    }

    static class CustomJavaScriptInterface2 {
        private Context ctx;
        TextView textView;
        String data = "no data yet..";
        CustomJavaScriptInterface2(Context ctx, String data) {
            this.ctx = ctx;
            this.textView = textView;
            data = "still no data";
        }

        public Thread getThread(){
            return Thread.currentThread();
        }

        @android.webkit.JavascriptInterface
        public void showHTML(String html) {

            //synchronized (Thread.currentThread()){
            Log.i("Utils", "html: "+ html);
            String responseBody = html;
            int startIndex = responseBody.indexOf(RESPONSE_BRACKETS) + RESPONSE_BRACKETS.length();
            int endIndex = responseBody.lastIndexOf(RESPONSE_BRACKETS);
            Log.i("Utils", "response  body: "+ responseBody);
            if(startIndex > 0 && endIndex > 0 && startIndex < endIndex){
                responseBody = responseBody.substring(startIndex, endIndex);
            }
            else{
                responseBody = RESPONSE_PARSE_ERROR;

            }
            data = responseBody;

            //    notify();
           // }
            Log.i("JS thread name", Thread.currentThread().getName());
/*
            try {
                Thread.currentThread().getName();
            }catch(InterruptedException e){
                Log.i("thread exception", e.toString());
                e.printStackTrace();
            }*/
            //textView.setText(responseBody);
        }

        public String getData(){
            return this.data;
        }

    }

    public static String getMessageBody(String response){
        String messageBody= "";
        int startIndex = response.indexOf(RESPONSE_BRACKETS) + RESPONSE_BRACKETS.length();
        int endIndex = response.lastIndexOf(RESPONSE_BRACKETS);
        Log.i("Utils", "response  body: "+ response);
        if(startIndex > 0 && endIndex > 0 && startIndex < endIndex){
            messageBody = response.substring(startIndex, endIndex);
        }
        else{
            messageBody = RESPONSE_PARSE_ERROR;
        }
        return messageBody;
    }



    public static String sendHTTPRequest(String addressString, String requestString) throws NetworkErrorException, SocketTimeoutException, IOException{

        StringBuilder str = new StringBuilder();

            if(addressString.indexOf(HTTP_PREFIX)!= 0){
                addressString = HTTP_PREFIX + addressString;
            }

            URL url = new URL(addressString);
        Log.i("Utils", "url:" + url.getPath());
            URLConnection urlConnection = url.openConnection();
            urlConnection.setDoInput(true);
            urlConnection.setReadTimeout(4000);
            urlConnection.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            String line;

            while((line = reader.readLine()) != null){
                str.append(line);
            }
            reader.close();

       // try {
       //     Thread.sleep(300);
       // }catch(InterruptedException e){
       // }
        return str.toString();
    }








}
