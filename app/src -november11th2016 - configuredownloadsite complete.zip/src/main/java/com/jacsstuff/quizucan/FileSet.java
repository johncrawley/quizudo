package com.jacsstuff.quizucan;

import android.content.Context;
import android.util.Log;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by John on 29/08/2016.
 * Contains a list of files that can return an array of file names (minus the extension)
 *  for displaying in the
 */
public class FileSet {

    private Map<String,File> filesMap;
    String FILENAME_EXTENSION;
    String[] displayNames;
    Map<String,Boolean> selectedDisplayNames;

    public FileSet(Context context, List<File> files){
        FILENAME_EXTENSION = context.getResources().getString(R.string.quiz_file_extension);
        filesMap = new HashMap<>();
        selectedDisplayNames = new HashMap<>();

        for(File file : files){
            String name = file.getName();
            String key = name.substring(0, name.indexOf(FILENAME_EXTENSION));
            filesMap.put(key, file);
        }
    }


    public String[] getDisplayNames(){
        if(filesMap.isEmpty()){
            return new String[]{""};
        }
        displayNames = filesMap.keySet().toArray(new String[filesMap.size()]);
        return displayNames;
    }


    public String getFilePath(String displayName){
        return this.filesMap.get(displayName + FILENAME_EXTENSION).getAbsolutePath();
    }

    public int size(){
        return filesMap.size();
    }


    public void setSelected(int filenamePosition, boolean isSelected){
        if(displayNames != null) {
            selectedDisplayNames.put(displayNames[filenamePosition], isSelected);
        }
    }

    public List<File> getSelectedFiles() {
        List<File> selectedFileList = new ArrayList<>();
        for (String name : selectedDisplayNames.keySet()) {
            if (selectedDisplayNames.get(name)) {
                selectedFileList.add(filesMap.get(name));
            }
        }
        return selectedFileList;
    }



}
