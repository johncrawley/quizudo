package com.jacsstuff.quizucan.Activities;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import com.jacsstuff.quizucan.MenuListAdapter;
import com.jacsstuff.quizucan.ListMenuItem;
import com.jacsstuff.quizucan.ResultView;
import com.jacsstuff.quizucan.controller.MainController;
import com.jacsstuff.quizucan.R;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private MainController controller;
    private Context context;
    private Button new_quiz_button;
    private ListView menuList;
    private List<ListMenuItem> menuItems;

    private final int CREATE_QUIZ_BUTTON_ID = 1001;
    private final int MANAGE_QUESTIONS_BUTTON_ID = 1002;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setHomeButtonEnabled(true);

        context = MainActivity.this;
        menuList = (ListView)findViewById(R.id.listView);
        menuItems = new ArrayList<>(2);
        menuItems.add(new ListMenuItem(CREATE_QUIZ_BUTTON_ID, getResources().getString(R.string.main_activity_start_quiz_button)));
        menuItems.add(new ListMenuItem(MANAGE_QUESTIONS_BUTTON_ID, getResources().getString(R.string.manage_questions_button_text)));


        controller = new MainController(context);
        //new_quiz_button = (Button)findViewById(R.id.new_quiz_button);
       // new_quiz_button.setOnClickListener(this);

        menuList.setAdapter(new com.jacsstuff.quizucan.MenuListAdapter(context, R.layout.menu_row, menuItems));
        menuList.setChoiceMode(AbsListView.CHOICE_MODE_SINGLE);
        menuList.setSelector(R.color.selectedListItem);

        menuList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
               loadActivity(view);
            }
        });

    }

    public void onClick(View view){
        //if(view.getId()==(R.id.new_quiz_button)){
         //   controller.execute("new quiz");
       // }
    }

    public void loadActivity(View view){
        int id = (int)view.getTag();
        if(id == CREATE_QUIZ_BUTTON_ID){

           controller.execute("new quiz");

       }else if(id == MANAGE_QUESTIONS_BUTTON_ID){
            Intent intent = new Intent(context, ManageQuestionsActivity.class);
            context.startActivity(intent);
       }
        else Log.i("mainActivity", "tag id = " + view.getTag());
    }
}
