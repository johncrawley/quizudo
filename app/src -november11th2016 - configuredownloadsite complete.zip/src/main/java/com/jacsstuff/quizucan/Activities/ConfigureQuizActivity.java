package com.jacsstuff.quizucan.Activities;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import com.jacsstuff.quizucan.QuestionNumberFilter;
import com.jacsstuff.quizucan.QuestionPackSingleton;
import com.jacsstuff.quizucan.R;

public class ConfigureQuizActivity extends AppCompatActivity implements View.OnClickListener{


    CheckBox instantResults;
    CheckBox submitAnswerOnTouch;
    Button beginQuizButton;
    TextView numberOfQuestionsLabel;
    EditText selectNumberOfQuestionsEditText;
    TextView numberOfQuestionsAvailableText;
    QuestionPackSingleton questionPackSingleton;

    private final int DEFAULT_QUESTION_LIMIT = 15;
    private final int DEFAULT_NUMBER_OF_QUESTIONS = 10;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_configure_quiz);
            Log.i("onCreate()", "OnCREATE!!!!");

        // Setting up the toolbar
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_HOME_AS_UP | ActionBar.DISPLAY_SHOW_TITLE );


        questionPackSingleton = QuestionPackSingleton.getInstance();

        numberOfQuestionsAvailableText = (TextView) findViewById(R.id.numberOfQuestionsAvailable);
        instantResults = (CheckBox) findViewById(R.id.instantResults);
        submitAnswerOnTouch = (CheckBox) findViewById(R.id.submitAnswerOnTouch);
        numberOfQuestionsLabel = (TextView) findViewById(R.id.selectNumberOfQuestionsLabel);
        selectNumberOfQuestionsEditText = (EditText)findViewById(R.id.selectNumberOfQuestions);
        beginQuizButton = (Button)findViewById(R.id.beginQuiz);

        //assigning previously used option selections
        submitAnswerOnTouch.setChecked(questionPackSingleton.getPreviousIsAnswerSubmittedOnTouch());
        instantResults.setChecked(questionPackSingleton.getPreviousIsResultDisplayedInstantly());
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(!s.toString().equals("")){
                    findViewById(R.id.noNumberSpecifiedText).setVisibility(View.INVISIBLE);
                    beginQuizButton.setEnabled(true);
                    return;
                }
                findViewById(R.id.noNumberSpecifiedText).setVisibility(View.VISIBLE);
                beginQuizButton.setEnabled(false);
            }
        };
        selectNumberOfQuestionsEditText.addTextChangedListener(textWatcher);
        //.setOnKeyListener(this);

        // Setting up the maximum number of questions
        int previousLimit = questionPackSingleton.getPreviousNumberOfQuestions();
        int questionNumberLimit = DEFAULT_QUESTION_LIMIT;
        int questionCount = questionPackSingleton.getNumberOfQuestions();

        if(questionCount > 0){
            questionNumberLimit = questionCount;
            String numberOfQuestionsAvailable = getResources().getString(R.string.configure_quiz_questions_maximum_found, questionCount);
            numberOfQuestionsAvailableText.setText(numberOfQuestionsAvailable);
        }

        // Figuring out what to set the number of questions to in the edit text view.
        int existingSelectNumber = questionNumberLimit;
        if(previousLimit < questionNumberLimit){
            existingSelectNumber = previousLimit;
        }else if(DEFAULT_NUMBER_OF_QUESTIONS < questionNumberLimit) {
            existingSelectNumber = DEFAULT_NUMBER_OF_QUESTIONS;
        }

        selectNumberOfQuestionsEditText.setText(existingSelectNumber + "");
        selectNumberOfQuestionsEditText.setFilters(new InputFilter[]{new QuestionNumberFilter(1, questionNumberLimit)});

        beginQuizButton.setOnClickListener(this);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        Log.i("Configchanged", "Config changed.");
    }

    @Override
    public void onRestart(){
        super.onRestart();
        Log.i("RestartActivity", " !!!");
    }

    public void onClick(View view){
        if(view.getId()==R.id.beginQuiz){
            saveCurrentConfig();
            startQuizActivity();
        }
    }

    public boolean onKey(View view, int keyCode, KeyEvent event){
        Log.i("OK", "key pressed on number of questions input");
        if((keyCode == KeyEvent.KEYCODE_ENTER) || (keyCode == EditorInfo.IME_ACTION_DONE)){
            if(selectNumberOfQuestionsEditText.getText().toString().equals("")){
                findViewById(R.id.noNumberSpecifiedText).setVisibility(View.VISIBLE);
                beginQuizButton.setEnabled(false);
            }
            else{
                findViewById(R.id.noNumberSpecifiedText).setVisibility(View.INVISIBLE);
                beginQuizButton.setEnabled(true);

            }
        }
        super.onKeyDown(keyCode,event);
        TextView textView = (TextView)findViewById(R.id.noNumberSpecifiedText);

        return true;
    }

    private void saveCurrentConfig(){
        questionPackSingleton.setAnswerSubmittedOnTouch(submitAnswerOnTouch.isChecked());
        questionPackSingleton.setResultDisplayedInstantly(instantResults.isChecked());
        questionPackSingleton.setNumberOfQuestions(Integer.valueOf(selectNumberOfQuestionsEditText.getText().toString()));

    }

    private void startQuizActivity(){

        Log.i("startQuizActivity()", "Starting quiz activity.");
        Intent intent = new Intent(this, QuizActivity.class);
        intent.putExtra("numberOfQuestions", Integer.valueOf(selectNumberOfQuestionsEditText.getText().toString()));
        intent.putExtra("isResultDisplayedAfterQuestion", instantResults.isChecked());
        intent.putExtra("isAnswerSubmittedOnTouch", submitAnswerOnTouch.isChecked());

        startActivity(intent);
    }



}
