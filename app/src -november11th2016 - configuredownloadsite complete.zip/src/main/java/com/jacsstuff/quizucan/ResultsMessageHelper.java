package com.jacsstuff.quizucan;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by John on 05/08/2016.
 */
public class ResultsMessageHelper {	Map<Integer, ResultMessage> resultMessageMap;

    public ResultsMessageHelper(){
        resultMessageMap = new HashMap<>();
        //setResultText()

        resultMessageMap.put(20,ResultMessage.LESS_THAN_TWENTY);
        resultMessageMap.put(40,ResultMessage.LESS_THAN_FORTY);
        resultMessageMap.put(50,ResultMessage.LESS_THAN_FIFTY);
        resultMessageMap.put(60,ResultMessage.LESS_THAN_SIXTY);
        resultMessageMap.put(70,ResultMessage.LESS_THAN_SEVENTY);
        resultMessageMap.put(80,ResultMessage.LESS_THAN_EIGHTY);
        resultMessageMap.put(90,ResultMessage.LESS_THAN_NINTY);
        resultMessageMap.put(99,ResultMessage.LESS_THAN_PERFECT);
    }


    public String getResultMessage(int correctAnswers, int totalQuestionNumber){
        // calling the zero and perfect messages out individually because we don't want them
        // getting called based on a rounded up/rounded down percentage.
        if(correctAnswers  == 0){
            return ResultMessage.NONE_CORRECT.getMessage();
        }
        else if(correctAnswers == totalQuestionNumber){
            return ResultMessage.PERFECT.getMessage();
        }
        float percentage = ((float)correctAnswers / totalQuestionNumber) * 100;
        return getResultMessage((int)percentage);
    }



    public String getResultMessage(int scorePercentage){
        if(scorePercentage < 0 || scorePercentage > 100){
            return "";
        }

        int highestThresholdKey = 1000;
        // we're looking for the lowest threshold that is higher than the provided scorePercentage
        System.out.println("ResultsMessageHelper.getResultMessage(), scorePercentage: " + scorePercentage);
        for(int key : resultMessageMap.keySet()){
            if(scorePercentage < key){
                if(key < highestThresholdKey){
                    highestThresholdKey = key;
                }
            }
        }
        if(highestThresholdKey == -1){
            return "";
        }
        else return resultMessageMap.get(highestThresholdKey).getMessage();

    }
}
