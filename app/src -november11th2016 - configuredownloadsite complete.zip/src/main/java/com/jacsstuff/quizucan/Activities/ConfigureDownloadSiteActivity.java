package com.jacsstuff.quizucan.Activities;

import android.accounts.NetworkErrorException;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.jacsstuff.quizucan.R;
import com.jacsstuff.quizucan.Utils;
import com.jacsstuff.quizucan.WebViewFactory;

import java.io.IOException;

import static com.jacsstuff.quizucan.Utils.HTTP_PREFIX;
import static com.jacsstuff.quizucan.Utils.QUIZ_SITE_TEST_EXPECTED_RESPOSE;
import static com.jacsstuff.quizucan.Utils.QUIZ_SITE_TEST_SERVICE;

public class ConfigureDownloadSiteActivity extends AppCompatActivity {

    private Button testConnectionButton;
    private EditText downloadSiteInputText;
    protected boolean isValidDownloadSite = false;
    protected Context context;
    protected String currentSite;
    protected SharedPreferences sharedPreferences;
    SharedPreferences.Editor preferencesEditor;
    private String defaultSite;
    WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_configure_download_site);
        context = ConfigureDownloadSiteActivity.this;

        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_HOME_AS_UP | ActionBar.DISPLAY_SHOW_TITLE );

        sharedPreferences = getPreferences(Context.MODE_PRIVATE);
        defaultSite = getResources().getString(R.string.default_download_site);
        currentSite = sharedPreferences.getString(getResources().getString(R.string.prefkey_download_site), defaultSite);

        testConnectionButton = (Button)findViewById(R.id.test_connection_button);
        downloadSiteInputText = (EditText)findViewById(R.id.download_site_input_text);
        downloadSiteInputText.setText(currentSite);

        downloadSiteInputText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    testConnection();
                    return true;
                }
                return false;
            }
        });

        testConnectionButton.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View view){
                testConnection();
            }
        });
    }


    private void testConnection(){
        currentSite = downloadSiteInputText.getText().toString();
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(downloadSiteInputText.getWindowToken(), 0);

        // performSearch(v.getText().toString());
       // new DownloadSiteTester().execute();
        String testUrl = HTTP_PREFIX + currentSite + QUIZ_SITE_TEST_SERVICE;
        Log.i("configDownloadSite", "test url: " + testUrl);

        webView = WebViewFactory.getWebview(context, new HttpGrabber());
        webView.loadUrl(testUrl);
    }


    private class HttpGrabber extends AsyncTask<String, String, Integer> {

        String response  = "";
        String deleteMessage = "";
        boolean isResponseGood = false;
        String toastMessage = "";

        public Integer doInBackground(String... params){
            response = Utils.getMessageBody(params[0]);
            if(response.equals(QUIZ_SITE_TEST_EXPECTED_RESPOSE)){
                isResponseGood = true;
                toastMessage = context.getResources().getString(R.string.test_connection_good);
            }
            else{
                Log.i("ConfigDownloadSite", "bad response: "+  response);
                toastMessage = context.getResources().getString(R.string.test_connection_bad);
            }
            return 1;
        }

        public void onPostExecute(Integer value){

            preferencesEditor = sharedPreferences.edit();
            preferencesEditor.putString(getResources().getString(R.string.prefkey_download_site), currentSite);
            preferencesEditor.apply();
            Utils.makeToast(context, toastMessage);
        }
    }


/*
    private class DownloadSiteTester extends AsyncTask<String, String, Integer> {

        String deleteMessage = "";
        boolean isResponseGood = false;
        String response = "";
        String toastMessage = "";

        public Integer doInBackground(String... params){
            try {
               response = Utils.sendHTTPRequest(currentSite + QUIZ_SITE_TEST_SERVICE, "");
                if(response.equals(QUIZ_SITE_TEST_EXPECTED_RESPOSE)){
                    isResponseGood = true;
                    toastMessage = context.getResources().getString(R.string.test_connection_good);
                }
                else{
                    Log.i("ConfigDownloadSite", "bad response: "+  response);
                    toastMessage = context.getResources().getString(R.string.test_connection_bad);
                }
            }catch(IOException e){
                isResponseGood = false;
                Log.i("ConfigDownloadSite", "bad response: "+  response);
                toastMessage = context.getResources().getString(R.string.test_connection_error);
            }
            catch(NetworkErrorException e){

                toastMessage = context.getResources().getString(R.string.test_connection_network_error);
            }

            return 1;
        }

        public void onPostExecute(Integer value){

            Utils.makeToast(context, toastMessage);
        }
    }
*/



}
