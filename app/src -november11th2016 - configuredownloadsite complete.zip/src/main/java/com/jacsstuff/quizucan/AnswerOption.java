package com.jacsstuff.quizucan;

/**
 * Created by John on 24/06/2016.
 */
public class AnswerOption {

    String text;
    boolean isCorrectAnswer;

    public AnswerOption(String text, boolean isCorrectAnswer){
        this.text = text;
        this.isCorrectAnswer = isCorrectAnswer;
    }

    public String getText(){
        return text;
    }

    public boolean isCorrectAnswer(){
        return isCorrectAnswer;
    }
}
