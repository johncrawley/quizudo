package com.jacsstuff.quizucan.Activities;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;

import com.jacsstuff.quizucan.MenuListAdapter;
import com.jacsstuff.quizucan.R;

import com.jacsstuff.quizucan.ListMenuItem;
import java.util.ArrayList;
import java.util.List;

public class ManageQuestionsActivity extends AppCompatActivity {

    private ListView optionsList;
    List <ListMenuItem> menuItems;
    private Context context;
    private final int ADD_QUESTION_PACKS_MENU_ITEM_ID = 1001;
    private final int DELETE_QUESTION_PACKS_MENU_ITEM_ID = 1002;
    private final int CONFIGURE_DOWNLOAD_SITE_MENU_ITEM_ID = 1003;
    private final int TEST_ACTIVITY_MENU_ITEM_ID = 1009;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_questions);
        this.context = ManageQuestionsActivity.this;

        menuItems = new ArrayList<>(3);
        menuItems.add(new ListMenuItem(ADD_QUESTION_PACKS_MENU_ITEM_ID,     getResources().getString(R.string.add_question_packs_menu_item)));
        menuItems.add(new ListMenuItem(DELETE_QUESTION_PACKS_MENU_ITEM_ID,  getResources().getString(R.string.delete_question_packs_menu_item)));
        menuItems.add(new ListMenuItem(CONFIGURE_DOWNLOAD_SITE_MENU_ITEM_ID,getResources().getString(R.string.configure_download_site_menu_item)));
        menuItems.add(new ListMenuItem(TEST_ACTIVITY_MENU_ITEM_ID, "Test Activity"));

        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_HOME_AS_UP | ActionBar.DISPLAY_SHOW_TITLE );

        optionsList = (ListView)findViewById(R.id.listView);
        optionsList.setAdapter(new MenuListAdapter(context, R.layout.menu_row, menuItems));
        optionsList.setChoiceMode(AbsListView.CHOICE_MODE_SINGLE);
        optionsList.setSelector(R.color.selectedListItem);

        optionsList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                startActivity(view);
            }
        });
    }

    private void startActivity(View view){

        Class activity = null;
        int menuItemId = (int)view.getTag();
        switch (menuItemId){
            case ADD_QUESTION_PACKS_MENU_ITEM_ID:
                activity = SelectAuthorActivity.class; break;
            case DELETE_QUESTION_PACKS_MENU_ITEM_ID:
                activity = RemoveQuestionPacksActivity.class; break;
            case CONFIGURE_DOWNLOAD_SITE_MENU_ITEM_ID:
                activity = ConfigureDownloadSiteActivity.class; break;
            case TEST_ACTIVITY_MENU_ITEM_ID:
                activity = TestActivity.class;
        }
        if(activity == null){
            return;
        }
        Intent intent = new Intent(context, activity);
        context.startActivity(intent);
    }

}
