package com.jacsstuff.quizucan;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by John on 17/09/2016.
 */
public class ResultsListAdapter extends ArrayAdapter<QuestionResult>{

    Context context;
    private List<QuestionResult> items;

    public ResultsListAdapter(Context context, int textViewResourceId, List<QuestionResult> items){
        super(context, textViewResourceId, items);
        this.context = context;
        this.items = items;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        View view = convertView;
        if(view == null){
            LayoutInflater vi = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = vi.inflate(R.layout.result_row,null);
        }

        QuestionResult questionResult = items.get(position);
        if(questionResult != null){
            TextView questionText = (TextView)view.findViewById(R.id.resultQuestionText);
            TextView correctAnswerText = (TextView)view.findViewById(R.id.resultCorrectAnswerText);
            ImageView imageView = (ImageView)view.findViewById(R.id.resultAnsweredCorrectlyImage);


            if(questionText != null){
                questionText.setText(questionResult.getQuestionResultText());
            }
            if(correctAnswerText != null){
                List<String> correctAnswers = questionResult.getCorrectAnswers();

                if(correctAnswers != null && correctAnswers.get(0) != null){
                    correctAnswerText.setText(correctAnswers.get(0));
                }
            }
            if(imageView != null){
                if(questionResult.wasAnsweredCorrectly()){
                    imageView.setImageResource(R.drawable.correct_icon);
                }
                else{
                    imageView.setImageResource(R.drawable.incorrect_icon);
                }
            }
        }
        return view;
    }
}
