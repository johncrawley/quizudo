package com.jacsstuff.quizucan.Activities;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.jacsstuff.quiz.QuestionPack;
import com.jacsstuff.quizucan.FileSet;
import com.jacsstuff.quizucan.JSONParser;
import com.jacsstuff.quizucan.QuestionPackSingleton;
import com.jacsstuff.quizucan.R;
import com.jacsstuff.quizucan.Utils;

import java.io.File;

public class CreateQuizActivity extends AppCompatActivity implements View.OnClickListener {

    Button configureQuizButton;
    ListView questionPackList;
    TextView noQuestionPacksFoundText;
    Context context;
    FileSet fileSet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_quiz);
        context = CreateQuizActivity.this;

        // Setting up the toolbar
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_HOME_AS_UP | ActionBar.DISPLAY_SHOW_TITLE );

        noQuestionPacksFoundText = (TextView)findViewById(R.id.no_question_packs_found_text);

        questionPackList = (ListView) findViewById(R.id.listView);
        configureQuizButton = (Button) findViewById(R.id.configureQuizButton);
        configureQuizButton.setOnClickListener(this);

        // this variable has to beset to final because it is accessed from within an inner class.
        final FileSet finalFileSet = new FileSet(context, Utils.getFilesFromExternalStorage(context));
        fileSet = finalFileSet;
        if(fileSet.size() != 0){
            noQuestionPacksFoundText.setVisibility(View.GONE);
        }
        else{
            questionPackList.setVisibility(View.GONE);
        }
        Utils.assignToList(context, questionPackList, finalFileSet.getDisplayNames());
        questionPackList.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){
                    CheckedTextView item = (CheckedTextView)view;
                    boolean checked = item.isChecked();
                    finalFileSet.setSelected(position,checked);
            }
        });
        finalFileSet.getSelectedFiles();
    }

    public void onClick(View view) {
        if (view.getId() == R.id.configureQuizButton) {
            fileSet.getSelectedFiles();
            new QuizFileLoader().execute(fileSet);
         }
    }


    private class QuizFileLoader extends AsyncTask<FileSet, String, Integer> {


        public Integer doInBackground(FileSet... params){

            Log.i("doInBackground()"," starting jsonparser now");
            JSONParser parser = new JSONParser();
            FileSet questionFiles = params[0];
            QuestionPackSingleton questionPackSingleton = QuestionPackSingleton.getInstance();
            questionPackSingleton.reset();
            for(File file: questionFiles.getSelectedFiles()){
                String path = file.getAbsolutePath();
                Log.i("doInBackground()", "path to jsonfile:"  + path);
                QuestionPack questionPack = parser.parse(path);
                System.out.println(questionPack);
                questionPackSingleton.add(questionPack);
            }
            return 1;
        }

        public void onPostExecute(Integer value){
            Log.i("QuizFileLoader"," entering onPostExecute()");
            configureQuizActivity();
        }

    }



    public void configureQuizActivity(){

        Intent intent = new Intent(this, ConfigureQuizActivity.class);

        startActivity(intent);
    }


}