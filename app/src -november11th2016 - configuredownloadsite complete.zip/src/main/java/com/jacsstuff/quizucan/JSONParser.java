package com.jacsstuff.quizucan;

import android.util.Log;

import com.jacsstuff.quiz.Question;
import com.jacsstuff.quiz.QuestionPack;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by John on 30/08/2016.
 */
public class JSONParser {

    public void log(String msg){
        Log.i("parse()", msg);
    }

    public QuestionPack parse(String filepath){

        // try(InputStream inputStream = new FileInputStream(filepath);
        // JsonReader reader = Json.createReader(inputStream)){

        QuestionPack questionPack = new QuestionPack();
        Question question;
        log("about to enter try block");
        try{
            log("about to create inputStream");
            InputStream inputStream = new FileInputStream(filepath);
            log("about to create StringBuilder");
            StringBuilder str = new StringBuilder();
            int input;
            log("about to loop through inputstream read()");
            while((input = inputStream.read()) != -1){
                str.append((char)input);
            }
            log("about to close inputStream");
            inputStream.close();

            log("about to create the JSON object");
            JSONObject quizObject = new JSONObject(str.toString());
            //JsonObject  quizObject = reader.readObject();
            JSONArray results = quizObject.getJSONArray("questions");
            JSONArray quizTopics = quizObject.getJSONArray("topics");

            for(int i=0;  i< quizTopics.length();i++){
                String topic = quizTopics.getString(i);
                if(!topic.equals("")){
                    topic = topic.substring(1,topic.length()-1);
                }
                questionPack.addTopic(topic);
            }
            questionPack.setName(quizObject.getString("name"));
            questionPack.setDescription(quizObject.getString("description"));
            for(int i=0;i<results.length();i++){
                JSONObject result = results.getJSONObject(i);

                question = new Question();

                question.addTopics(parseValues(result, "topics"));
                question.addAnswers(parseValues(result, "answerChoices"),false);
                question.addAnswers(parseValues(result, "correctAnswers"), true);
                question.setTrivia(result.getString("trivia"));
                question.setQuestionText(result.getString("questionText"));
                log("About to add question to questionPack: " + question.getQuestionText());
                questionPack.addQuestion(question);

            }
        }

        catch(IOException e){
            System.out.println(e.getMessage());

        }catch(JSONException e){
            Log.i("JSON EXCEPTION","Oh well. Unable to read JSON file: " + filepath);
        }
        return questionPack;
    }



    private List<String> parseValues(JSONObject result, String arrayName){

        List<String> valuesList = new ArrayList<>();
        try {
            JSONArray jsonValueArray = result.getJSONArray(arrayName);
            if(jsonValueArray !=null){
                for(int i=0; i<jsonValueArray.length();i++){
                    String value = jsonValueArray.getString(i).trim();

                    value = value.trim();
                    if (value.startsWith("\"")) {
                        value = value.substring(1);
                    }
                    if (value.endsWith("\"")) {
                        value = value.substring(0, value.length() - 1);
                    }
                    if (!value.equals("")) {
                        valuesList.add(value);
                    }
                }
            }

        }catch(JSONException e){
            Log.i("JSONEXCEPTION:", " Unable to parse json list: " + arrayName);
        }
        return valuesList;
    }



}
