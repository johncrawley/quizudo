package com.jacsstuff.quizucan.controller;

import android.content.Context;
import android.content.Intent;

import com.jacsstuff.quizucan.Activities.QuizActivity;
import com.jacsstuff.quizucan.Activities.QuizResultsActivity;
import com.jacsstuff.quizucan.QuestionResultsSingleton;
import com.jacsstuff.quizucan.Quiz;
import com.jacsstuff.quizucan.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by John on 27/06/2016.
 */
public class QuizController {

    QuizActivity quizActivity;
    Context context;
    Quiz quiz;
    List<String> topics;
    boolean isAnswerSubmittedOnTouch,isResultDisplayedAfterQuestion;
    boolean isSingleAnswerMode = true; // single-answer-mode means that we only allow one answer to be selected
                                        // if multiple answers can be selected, there's different logic when keeping track of the chosen answer.
    List<Integer> selectedItemPositions;


    public QuizController(QuizActivity quizActivity, int numberOfQuestions, boolean submitAnswerOnTouch, boolean isResultDisplayedAfterQuestion){

        quiz = new Quiz();
        topics = new ArrayList<>(1);
        topics.add("General Knowledge");
        quiz.createQuiz(numberOfQuestions, topics);

        this.quizActivity = quizActivity;
        this.isResultDisplayedAfterQuestion = isResultDisplayedAfterQuestion;
        this.isAnswerSubmittedOnTouch = submitAnswerOnTouch;

        context = quizActivity.getContext();

        loadQuestion();
        quizActivity.setAnswerChoices(quiz.getCurrentAnswerChoices());
        if(submitAnswerOnTouch){
            quizActivity.hideNextButton();
        }
    }


    public void setAnswer(int position) {

        if (isSingleAnswerMode) {
            selectedItemPositions.clear();
            selectedItemPositions.add(position);

        } else {
            if (selectedItemPositions.contains(position)) {

                selectedItemPositions.remove(selectedItemPositions.indexOf(position));
                return;
            }
            selectedItemPositions.add(position);
        }
    }

    public boolean submitAnswer() {

        if (!selectedItemPositions.isEmpty()) {
            quiz.submitAnswers(selectedItemPositions);
            return true;
        }
        return false;
    }


    private void finishQuiz() {
        QuestionResultsSingleton.getInstance().setQuizFinished(true);
        Intent intent = new Intent(context, QuizResultsActivity.class);
        context.startActivity(intent);
    }


    public String getCurrentCorrectAnswers() {

        List<String> currentCorrectAnswers = quiz.getCurrentCorrectAnswers();
        if (currentCorrectAnswers == null) {
            return "";
        }
        StringBuilder strBuilder = new StringBuilder();
        if(currentCorrectAnswers.size() == 0){return context.getResources().getString(R.string.no_correct_answer_result_message);}
        if(currentCorrectAnswers.size() == 1){strBuilder.append(context.getResources().getString(R.string.single_correct_answer_result_message));}
        else{                                 strBuilder.append(context.getResources().getString(R.string.multiple_correct_answer_result_message));}

        strBuilder.deleteCharAt(strBuilder.length()-1);
        for (String correctAnswer : currentCorrectAnswers) {
            strBuilder.append(correctAnswer);
            strBuilder.append(", ");
        }
        if(strBuilder.length() > 1) {
            strBuilder.deleteCharAt(strBuilder.length() - 2); //removing the last comma.
        }
        return strBuilder.toString();
    }


    public void loadNextQuestion() {

        if (quiz.isFinalQuestion()) {
            finishQuiz();
        }
        else {
            quiz.nextQuestion();
            loadQuestion();
        }
    }


    // this assigns the current question data to the UI Views. It's called once when the quiz
    // starts and then each time the user completes a question (unless that question is the last question).
    public void loadQuestion(){
        quizActivity.setQuestion(quiz.getCurrentQuestionText());
        quizActivity.setQuestionCounter(quiz.getQuestionCounter());

        quizActivity.setAnswerChoices(quiz.getCurrentAnswerChoices());
        selectedItemPositions = new ArrayList<>();

        if(quiz.isFinalQuestion()){
            quizActivity.setNextButtonText("Finish");
        }
    }

    // what happens when the 'next question' button is clicked.
    public void nextButton(){
        if(submitAnswer()) {
            if (isResultDisplayedAfterQuestion) {
                displayResult();
            } else {
                loadNextQuestion();
            }
        }
    }

    private void displayResult(){
        if(quiz.isCurrentAnswerCorrect()) {
            quizActivity.showResultView(true, quiz.getCurrentQuestionTrivia());
        }
        else{
            quizActivity.showResultView(false, getCurrentCorrectAnswers());
        }

    }


    public void answerItemClick(int position){
        setAnswer(position);
        if(isAnswerSubmittedOnTouch){
            submitAnswer();
            if(isResultDisplayedAfterQuestion){
                displayResult();
            }
            else{
                loadNextQuestion();
            }
        }
    }


    public void resultClick(){
            loadNextQuestion();
            quizActivity.hideResultView();

    }


}
