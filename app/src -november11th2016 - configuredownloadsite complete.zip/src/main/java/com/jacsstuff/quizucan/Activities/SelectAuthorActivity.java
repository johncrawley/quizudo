package com.jacsstuff.quizucan.Activities;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.jacsstuff.quizucan.R;

import java.util.HashSet;
import java.util.Set;

public class SelectAuthorActivity extends AppCompatActivity {

    Context context;
    Set<String> authorsSet;
    ListView authorsList;
    EditText authorInput;
    SharedPreferences sharedPref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_author);

        context = SelectAuthorActivity.this;
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_HOME_AS_UP | ActionBar.DISPLAY_SHOW_TITLE );

        authorsList = (ListView)findViewById(R.id.listView);
        authorInput = (EditText)findViewById(R.id.editText);
        authorInput.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(authorInput.getWindowToken(), 0);
                    performSearch(v.getText().toString());
                    return true;
                }
                return false;
            }
        });

        sharedPref = getPreferences(Context.MODE_PRIVATE);
        //int defaultValue = getResources().getInteger(R.string.saved_high_score_default);
        //long highScore = sharedPref.getInt(getString(R.string.saved_high_score), defaultValue);
        //SharedPreferences.Editor preferencesEditor = sharedPref.edit();
        authorsSet = sharedPref.getStringSet(getResources().getString(R.string.prefkey_authors), new HashSet<String>(0));
       // preferencesEditor.putStringSet(getResources().getString(R.string.prefkey_authors),authorsSet);

        authorsList.setChoiceMode(AbsListView.CHOICE_MODE_SINGLE);
        authorsList.setAdapter(new ArrayAdapter<String>(context, android.R.layout.simple_list_item_1, authorsSet.toArray(new String[authorsSet.size()])));
        authorsList.setSelector(R.color.selectedListItemHidden);

      //  int test = sharedPref.getInt("testSave", 0);
      //  test ++;
       // Log.i("SelectAuthorAct", "test: " + test);
     //   SharedPreferences.Editor preferencesEditor = sharedPref.edit();
      //  preferencesEditor.putInt("testSave", test);
      //  preferencesEditor.apply();

    }

    //TODO: add download option
    private void performSearch(String text){

        SharedPreferences.Editor preferencesEditor = sharedPref.edit();
        Set <String> authors = new HashSet<>();
        authors.addAll(sharedPref.getStringSet(getResources().getString(R.string.prefkey_authors), new HashSet<String>(0)));
        Log.i("performSearch", "authorsSet size on load from prefs: "+ authors.size());
        authors.add(text);
        preferencesEditor.putStringSet(getResources().getString(R.string.prefkey_authors), authors);

        preferencesEditor.commit();
        StringBuilder bldr = new StringBuilder();
        for( String author : authors){
            bldr.append(" ");
            bldr.append(author);
        }
        Log.i("SeletAuthorsAct", "current authors: " + bldr.toString());

        authorsList.setAdapter(new ArrayAdapter<String>(context, android.R.layout.simple_list_item_1, authors.toArray(new String[authors.size()])));

    }
}