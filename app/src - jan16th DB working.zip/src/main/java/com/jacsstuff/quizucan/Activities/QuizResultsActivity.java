package com.jacsstuff.quizucan.Activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.TextView;

import com.jacsstuff.quizucan.QuestionResultsSingleton;
import com.jacsstuff.quizucan.controller.QuizResultsController;
import com.jacsstuff.quizucan.R;
import static com.jacsstuff.quizucan.Utils.PREVIOUS_SHOW_ANSWER_PREFERENCE;
import static com.jacsstuff.quizucan.Utils.PREVIOUS_SUBMIT_ANSWER_ON_TOUCH_PREFERENCE;
import static com.jacsstuff.quizucan.Utils.PREVIOUS_NUMBER_OF_QUESTIONS_PREFERENCE;
import static com.jacsstuff.quizucan.Utils.NUMBER_OF_QUESTIONS_INTENT_EXTRA;
import static com.jacsstuff.quizucan.Utils.DISPLAY_ANSWER_DIALOG_INTENT_EXTRA;
import static com.jacsstuff.quizucan.Utils.SUBMIT_ANSWER_ON_TOUCH_INTENT_EXTRA;
import static com.jacsstuff.quizucan.Utils.QUIZ_SETTINGS_PREFERENCES;

public class QuizResultsActivity extends AppCompatActivity {

    private TextView quizResultsMessage;
    private TextView quizResultsStatistic;
    private  ListView quizResultsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_results);
        setupToolbar();

        quizResultsMessage = (TextView)findViewById(R.id.quiz_results_message);
        quizResultsStatistic = (TextView)findViewById(R.id.quiz_results_statistic);
        quizResultsList = (ListView)findViewById(R.id.quiz_results_list);

        QuizResultsController quizResultsController = new QuizResultsController(QuizResultsActivity.this, this);
        quizResultsController.process();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.quiz_results_menu, menu);
        return true;
    }

    public ListView getResultsListView(){
        return this.quizResultsList;
    }
    public TextView getResultsTextView(){
        return this.quizResultsMessage;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if(id == R.id.home_menu_item) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        //noinspection SimplifiableIfStatement
        if (id == R.id.retry_menu_item) {
            QuestionResultsSingleton questionResultsSingleton = QuestionResultsSingleton.getInstance();
            questionResultsSingleton.resetResults();
            SharedPreferences preferences = getSharedPreferences(QUIZ_SETTINGS_PREFERENCES,MODE_PRIVATE);
            Intent intent = new Intent(this, QuizActivity.class);
            int numberOfQuestions = preferences.getInt(PREVIOUS_NUMBER_OF_QUESTIONS_PREFERENCE, 0);
            boolean showAnswerDialog = preferences.getBoolean(PREVIOUS_SHOW_ANSWER_PREFERENCE, false);
            boolean submitAnswerOnTouch = preferences.getBoolean(PREVIOUS_SUBMIT_ANSWER_ON_TOUCH_PREFERENCE, false);

            intent.putExtra(NUMBER_OF_QUESTIONS_INTENT_EXTRA, numberOfQuestions);
            intent.putExtra(DISPLAY_ANSWER_DIALOG_INTENT_EXTRA, showAnswerDialog);
            intent.putExtra(SUBMIT_ANSWER_ON_TOUCH_INTENT_EXTRA, submitAnswerOnTouch);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    private void setupToolbar(){
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        ActionBar actionBar = getSupportActionBar();
        if(actionBar == null){
            return;
        }
        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayOptions(ActionBar.DISPLAY_HOME_AS_UP | ActionBar.DISPLAY_SHOW_TITLE );
        actionBar.setDisplayShowHomeEnabled(true);
        String title = getResources().getString(R.string.quiz_completed_heading);
        actionBar.setTitle(title);
    }

    public void setStatistic(int correctlyAnswered, int totalQuestions){
        quizResultsStatistic.setText(getResources().getString(R.string.quiz_results_statistic, correctlyAnswered, totalQuestions));
    }

}
