package com.jacsstuff.quizucan;

import android.os.AsyncTask;

/**
 * Created by John on 09/11/2016.
 */
public class CustomJavaScriptInterface {

    AsyncTask<String, String, Integer> asyncTask;
    public CustomJavaScriptInterface(AsyncTask<String, String, Integer> task){
        this.asyncTask = task;
    }

    @android.webkit.JavascriptInterface
    public void showHTML(String html) {
        asyncTask.execute(html);
    }
}