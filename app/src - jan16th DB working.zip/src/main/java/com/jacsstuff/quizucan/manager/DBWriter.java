package com.jacsstuff.quizucan.manager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.jacsstuff.quiz.Question;
import com.jacsstuff.quizucan.JSONParser;
import com.jacsstuff.quizucan.QuestionPackDetail;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;


/**
 * Created by John on 31/12/2016.
 *
 *
 * Used for writing question pack and question data to the DB
 */
public class DBWriter {

    QuestionPackDBHelper mDbHelper;

    public DBWriter(Context context){

        mDbHelper = QuestionPackDBHelper.getInstance(context);
    }


    public boolean addQuestionPack(String data){
        Log.i("DBWriter", "Entered addQuestionPack");
        JSONParser parser = new JSONParser();
        QuestionPackDBDetail questionPack = parser.parseQuestionPackFromJson(data);
        Log.i("DBWriter", "parsed question pack from data into questionPackDBDetail.");
        SQLiteDatabase db = mDbHelper.getWritableDatabase();
        db.beginTransaction();
        Log.i("DBWriter", "transaction begun, about to delete existing Question Pack, if exists.");
        deleteQuestionPackWithUniqueName(db, questionPack.getUniqueName());
        Log.i("DBWriter", "about to enter addQuestionPackRecord()");

        db.setTransactionSuccessful();
        db.endTransaction();

        Log.i("DBWriter", "questionsCount = " + getQuestionsCount(db));

        db.beginTransaction();
        long qpRowId = addQuestionPackRecord(questionPack, db);

        if(questionPack.getQuestionDetails() == null){
            db.endTransaction();
            Log.i("DBWriter", "addQuestionPack() db transaction ended, getQPDetails() is null");
            closeConnection();
            return false; // transaction was not successful.
        }

        for(QuestionDBDetail question : questionPack.getQuestionDetails()){
            addQuestion(question, db, qpRowId);
        }
        db.setTransactionSuccessful();
        db.endTransaction();

        Log.i("DBWriter", "addQuestionPack() db transaction successful!");
        //closeConnection();
        return true; //transaction was successful.

        //db.endTransaction(); in case of error
    }

    public int deleteQuestionPacks(Set<String> uniqueNames){

        int deleteCount = 0;
        for( String uniqueName : uniqueNames){

            if(deleteQuestionPack(uniqueName)){
                deleteCount++;
            }
        }
        return deleteCount;
    }

    private boolean deleteQuestionPack(String uniqueName){
        SQLiteDatabase db = mDbHelper.getWritableDatabase();
        db.beginTransaction();

            if(!deleteQuestionPackWithUniqueName(db, uniqueName)){
                db.endTransaction();
                return false;
            }

        db.setTransactionSuccessful();
        db.endTransaction();
        return true;
    }

    private boolean deleteQuestionPackWithUniqueName(SQLiteDatabase db, String uniqueName){

        Log.i("DBWriter", "Entered deleteQuestionPack()");
        String getIdQuery = "SELECT " + DbContract.QuestionPackEntry._ID +
                            " FROM  " + DbContract.QuestionPackEntry.TABLE_NAME +
                            " WHERE " + DbContract.QuestionPackEntry.COLUMN_NAME_UNIQUE_NAME + " = " +
                            "'" +   uniqueName + "';" ;

        Log.i("DBWriter", "About to rawQuery: " + getIdQuery);
        Cursor cursor = db.rawQuery(getIdQuery, null);

        long questionPackId = -1;
        int loopCount = 1;
        while(cursor.moveToNext()){
            Log.i("DBWriter", "Entered cursorMoveToNext loop" + loopCount++);
            questionPackId = getLong( cursor, DbContract.QuestionPackEntry._ID);
        }
        cursor.close();

        Log.i("DBWriter", "Past the loop, questionPackId is now: " + questionPackId);
        if(questionPackId != -1){
            // i.e. return true(success) if both the questions and question pack are deleted.
            return deleteQuestions(db, questionPackId) && deleteQuestionPackRow(db, questionPackId);
        }
        return false;
    }

    private boolean deleteQuestionPackRow(SQLiteDatabase db, long questionPackId){

        String query = "DELETE FROM " + DbContract.QuestionPackEntry.TABLE_NAME +
                " WHERE " + DbContract.QuestionPackEntry._ID + " = " +
                questionPackId + ";" ;
        return runQuery(db, query);
    }

    private boolean deleteQuestions(SQLiteDatabase db, long questionPackId) {

        String query =  "DELETE FROM "  + DbContract.QuestionsEntry.TABLE_NAME +
                        " WHERE "       + DbContract.QuestionsEntry.COLUMN_NAME_QUESTION_PACK_ID +
                        " = " + questionPackId + ";" ;

        String query2 = "SELECT * FROM " + DbContract.QuestionsEntry.TABLE_NAME;

        Cursor cursor = db.rawQuery(query2, null);
        Log.i("DBWriter", "deleteQuestions() - delete questions with related qp id of : " + questionPackId);
        while(cursor.moveToNext()){
            long qp_id = getLong(cursor, DbContract.QuestionsEntry.COLUMN_NAME_QUESTION_PACK_ID);
            long id = getLong(cursor, DbContract.QuestionsEntry._ID);

            Log.i("DBWriter", "deleteQuestions: question record id: "+ id + " related_qp_id: "+ qp_id);

        }
        cursor.close();

        boolean wasQuerySuccessful = runQuery(db, query);




        return wasQuerySuccessful;

    }

    private boolean runQuery(SQLiteDatabase db, String query){
        boolean isSuccessful = true;
        try {
            db.execSQL(query);
        }catch(SQLException e){
            e.printStackTrace();
            Log.i("DBWriter", "Problem with query: " + e.getMessage());
            isSuccessful = false;
        }
        Log.i("DBWriter", "query: "+ query + " was successful.");
        return isSuccessful;


    }

    private void addQuestion(QuestionDBDetail q, SQLiteDatabase db , long questionPackRowId){

        ContentValues questionValues = new ContentValues();
        questionValues.put(DbContract.QuestionsEntry.COLUMN_NAME_QUESTION, q.getQuestion());
        questionValues.put(DbContract.QuestionsEntry.COLUMN_NAME_QUESTION_PACK_ID, questionPackRowId);
        questionValues.put(DbContract.QuestionsEntry.COLUMN_NAME_TOPICS, q.getTopics());
        questionValues.put(DbContract.QuestionsEntry.COLUMN_NAME_FLAGS, q.getFlags());
        Log.i("DBWriter", "addQuestion() - about to insert new row to QuestionsEntry Table");
        try {
            db.insertOrThrow(DbContract.QuestionsEntry.TABLE_NAME, null, questionValues);
        }catch(SQLException e){
            Log.i("DBWRITER", "SQLException on addQuestion: "+ e.toString());
            e.printStackTrace();
            db.endTransaction();
        }
    }


    private long addQuestionPackRecord(QuestionPackDBDetail qp, SQLiteDatabase db ){
        Log.i("DBWriter", "Entered addQuestionPackRecord");
        ContentValues questionPackValues = new ContentValues();

        questionPackValues.put(DbContract.QuestionPackEntry.COLUMN_NAME_AUTHOR,             qp.getAuthor());
        questionPackValues.put(DbContract.QuestionPackEntry.COLUMN_NAME_TITLE,              qp.getName());
        questionPackValues.put(DbContract.QuestionPackEntry.COLUMN_NAME_VERSION,            qp.getVersion());
        questionPackValues.put(DbContract.QuestionPackEntry.COLUMN_NAME_UNIQUE_NAME,        qp.getUniqueName());
        questionPackValues.put(DbContract.QuestionPackEntry.COLUMN_NAME_DATE_DOWNLOADED,    qp.getDateDownloaded());
        questionPackValues.put(DbContract.QuestionPackEntry.COLUMN_NAME_DATE_CREATED,       qp.getDateCreated());
        questionPackValues.put(DbContract.QuestionPackEntry.COLUMN_NAME_DESCRIPTION,        qp.getDescription());
        questionPackValues.put(DbContract.QuestionPackEntry.COLUMN_NAME_NUMBER_OF_QUESTIONS,qp.getNumberOfQuestions());
        Log.i("DBWriter", "addQuestionPackRecord() - questionPackValues specified, about to run db.insert()");
        // returns the ID for the question pack, which will be used by each related question

        return db.insert(DbContract.QuestionPackEntry.TABLE_NAME, null, questionPackValues);
    }


    public Map<Integer, QuestionPackDetail> getQuestionPackDetails(){

        Log.i("DBWriter", "Entered getQuestionPackDetails()");
      //  SQLiteDatabase db = mDbHelper.getReadableDatabase();
        SQLiteDatabase db = mDbHelper.getWritableDatabase();

        // Define a projection that specifies which columns from the database
        // you will actually use after this query.
        String[] projection = {
                DbContract.QuestionPackEntry._ID,
                DbContract.QuestionPackEntry.COLUMN_NAME_TITLE,
                DbContract.QuestionPackEntry.COLUMN_NAME_DATE_CREATED,
                DbContract.QuestionPackEntry.COLUMN_NAME_DATE_DOWNLOADED,
                DbContract.QuestionPackEntry.COLUMN_NAME_AUTHOR,
                DbContract.QuestionPackEntry.COLUMN_NAME_UNIQUE_NAME,
                DbContract.QuestionPackEntry.COLUMN_NAME_VERSION,
                DbContract.QuestionPackEntry.COLUMN_NAME_NUMBER_OF_QUESTIONS,
                DbContract.QuestionPackEntry.COLUMN_NAME_DESCRIPTION
        };

        // Filter results WHERE "title" = 'My Title'
        //String selection = DbContract.QuestionPackEntry.COLUMN_NAME_TITLE + " = ?";
        String selection = DbContract.QuestionPackEntry.COLUMN_NAME_UNIQUE_NAME + " = ?";
        String[] selectionArgs = { "*" };

        // How you want the results sorted in the resulting Cursor
        String sortOrder = DbContract.QuestionPackEntry.COLUMN_NAME_TITLE + " DESC";
/*
        Cursor cursor = db.query(
                DbContract.QuestionPackEntry.TABLE_NAME,                     // The table to query
                projection,                               // The columns to return
                selection,                                // The columns for the WHERE clause
                selectionArgs,                            // The values for the WHERE clause
                null,                                     // don't group the rows
                null,                                     // don't filter by row groups
                sortOrder                                 // The sort order
        );
        */

        String query2 = "SELECT * FROM "  + DbContract.QuestionPackEntry.TABLE_NAME + ";";
        Cursor cursor =  db.rawQuery(query2, null);
        Map<Integer, QuestionPackDetail> qpDetailsMap = new HashMap<>();
        QuestionPackDetail qpDetail;
        int counter = 0;
        while(cursor.moveToNext()) {
            qpDetail = new QuestionPackDetail();
            qpDetail.setName             (getString( cursor, DbContract.QuestionPackEntry.COLUMN_NAME_TITLE));
            qpDetail.setDescription      (getString( cursor, DbContract.QuestionPackEntry.COLUMN_NAME_DESCRIPTION));
            qpDetail.setUniqueName       (getString( cursor, DbContract.QuestionPackEntry.COLUMN_NAME_UNIQUE_NAME));
            qpDetail.setAuthor           (getString( cursor, DbContract.QuestionPackEntry.COLUMN_NAME_AUTHOR));
            qpDetail.setDateCreated      (getString( cursor, DbContract.QuestionPackEntry.COLUMN_NAME_DATE_CREATED));
            qpDetail.setVersion          (getInt(    cursor, DbContract.QuestionPackEntry.COLUMN_NAME_VERSION));
            qpDetail.setNumberOfQuestions(getInt(    cursor, DbContract.QuestionPackEntry.COLUMN_NAME_NUMBER_OF_QUESTIONS));
            qpDetail.setDateDownloaded   (getLong(   cursor, DbContract.QuestionPackEntry.COLUMN_NAME_DATE_DOWNLOADED));
            qpDetail.setId               (getLong(   cursor, DbContract.QuestionPackEntry._ID));
            qpDetail.setKey(counter);

            qpDetailsMap.put(counter, qpDetail);
            counter++;
        }
        Log.i("DBWriter", "Question Pack count: " + counter);
        for(int key : qpDetailsMap.keySet()){

            Log.i("DBWriter", "Question Pack Detail :");
            Log.i("DBWriter", "**********************");
            Log.i("DBWriter", "Name: " + qpDetailsMap.get(key).getName());
            Log.i("DBWriter", "Unique Name: " + qpDetailsMap.get(key).getUniqueName());
            Log.i("DBWriter", "Author: " + qpDetailsMap.get(key).getAuthor());
            Log.i("DBWriter", "DateCreated: " + qpDetailsMap.get(key).getDateCreated());
            Log.i("DBWriter", "DateDownloaded: " + qpDetailsMap.get(key).getDateDownloaded());
            Log.i("DBWriter", "Version: " + qpDetailsMap.get(key).getVersion());
            Log.i("DBWriter", "Key: " + qpDetailsMap.get(key).getKey());
            Log.i("DBWriter", "NumberOfQuestions: " + qpDetailsMap.get(key).getNumberOfQuestions());
            Log.i("DBWriter", "Description: " + qpDetailsMap.get(key).getDescription());
            Log.i("DBWriter", "**********************");
        }
        cursor.close();
/*
        Cursor cursor2 = db.rawQuery(query2, null);

        int counter2 = 0;
        while(cursor2.moveToNext()) {
            counter2++;
        }
        cursor2.close();
        Log.i("DBWRITER", "Query return size: " + counter2);
*/
        return qpDetailsMap;
    }

    public int getQuestionsCount(SQLiteDatabase db){
        db.beginTransaction();
        String query = "SELECT * FROM " + DbContract.QuestionsEntry.TABLE_NAME + ";";
        Cursor cursor = db.rawQuery(query, null);
        int count = cursor.getCount();
        cursor.close();
        db.setTransactionSuccessful();
        db.endTransaction();
        return count;
    }


    public List<Question> getQuestions(Set<Long> questionPackRowIds){

        List<Question> questions = new ArrayList<>();
        SQLiteDatabase db = mDbHelper.getWritableDatabase();
        String criteria = deriveInCriteria(questionPackRowIds);

        Log.i("DBWriter", "getQuestionsQuery(): row count in questions db: "+ getQuestionsCount(db));


        String query = "SELECT "    + DbContract.QuestionsEntry.COLUMN_NAME_QUESTION
                    + " FROM "      + DbContract.QuestionsEntry.TABLE_NAME
                    + " WHERE "     + DbContract.QuestionsEntry.COLUMN_NAME_QUESTION_PACK_ID
                    + " IN "        + criteria;

        Log.i("DBWriter" , " getQuestionsQuery(): " + query);

        Cursor cursor = db.rawQuery(query, null);
        int count = cursor.getCount();
        Log.i("DBWriter", "getQuestionsQuery(): number of results from cursor:" + count);
        JSONParser jsonParser = new JSONParser();
        while(cursor.moveToNext()) {
            Question question = jsonParser.parseQuestion(getString( cursor, DbContract.QuestionsEntry.COLUMN_NAME_QUESTION));
            if(question != null){
                questions.add(question);
            }
        }
        Log.i("DBWriter", "getQuestionsQuery(): size of questions list: "+ questions.size());
        cursor.close();
        return questions;
    }

    public void closeConnection(){
        //mDbHelper.close();
    }

    private String deriveInCriteria(Set <Long> questionPackRowIds){

        StringBuilder str = new StringBuilder();
        str.append("( ");
        for ( long qpRowId :questionPackRowIds ) {
            str.append(qpRowId);
            str.append(" ,");
        }
        str.deleteCharAt(str.lastIndexOf(","));
        str.append(" )");
        return str.toString();
    }

    private String getString(Cursor cursor, String name){
        return cursor.getString(cursor.getColumnIndexOrThrow(name));
    }


    private int getInt(Cursor cursor, String name){
        return cursor.getInt(cursor.getColumnIndexOrThrow(name));
    }

    private long getLong(Cursor cursor, String name){
        return cursor.getLong(cursor.getColumnIndexOrThrow(name));
    }




}
