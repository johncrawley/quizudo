package com.jacsstuff.quizucan.controller;

import android.content.Context;
import android.widget.ListView;
import android.widget.TextView;

import com.jacsstuff.quizucan.Activities.QuizResultsActivity;
import com.jacsstuff.quizucan.QuestionResult;
import com.jacsstuff.quizucan.QuestionResultsSingleton;
import com.jacsstuff.quizucan.R;
import com.jacsstuff.quizucan.ResultsMessageHelper;
import com.jacsstuff.quizucan.list.ResultsListAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by John on 29/06/2016.
 *
 * Helps out the Quiz Results Activity
 */
public class QuizResultsController {

    Context context;

    QuestionResultsSingleton singletonResultsStore;
    List<QuestionResult> questionResults;
    String[] resultStringsArray;
    List <String> resultStringsList;
    ResultsMessageHelper resultsMessageHelper;
    QuizResultsActivity quizResultsActivity;
    TextView quizResultsMessage;
    ListView quizResultsList;

    public QuizResultsController(Context context, QuizResultsActivity quizResultsActivity) {
        this.context = context;
        this.quizResultsActivity = quizResultsActivity;
        this.quizResultsMessage = quizResultsActivity.getResultsTextView();
        this.quizResultsList = quizResultsActivity.getResultsListView();
        resultStringsList = new ArrayList<>();
        singletonResultsStore = QuestionResultsSingleton.getInstance();
        questionResults = singletonResultsStore.getResults();
        resultsMessageHelper = new ResultsMessageHelper(context);
    }

    public void process(){
        for(QuestionResult result : questionResults){
            resultStringsList.add(result.getResultAsString());
        }
        resultStringsArray = resultStringsList.toArray(new String[resultStringsList.size()]);
        int correctAnswerCount = singletonResultsStore.getCorrectAnswerCount();
        int questionCount = questionResults.size();

        quizResultsActivity.setStatistic(correctAnswerCount, questionCount);
        String resultsMessage = resultsMessageHelper.getResultMessage(correctAnswerCount, questionResults.size());
        quizResultsMessage.setText(resultsMessage);
        quizResultsList.setAdapter(new ResultsListAdapter(context, R.layout.result_row, questionResults));
    }

}
