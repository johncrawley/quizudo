package com.jacsstuff.quizucan;

import android.util.Log;

import com.jacsstuff.quiz.Question;
import com.jacsstuff.quiz.QuestionPack;
import com.jacsstuff.quizucan.manager.QuestionDBDetail;
import com.jacsstuff.quizucan.manager.QuestionPackDBDetail;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by John on 30/08/2016.
 */
public class JSONParser {

    public static final String TOPICS_DELIMITER = ",";

    public void log(String msg){
        Log.i("parseFile()", msg);
    }

    public QuestionPack parseFile(String filepath){

        // try(InputStream inputStream = new FileInputStream(filepath);
        // JsonReader reader = Json.createReader(inputStream)){

        QuestionPack questionPack = new QuestionPack();
        try{
            InputStream inputStream = new FileInputStream(filepath);
            StringBuilder str = new StringBuilder();
            int input;
            while((input = inputStream.read()) != -1){
                str.append((char)input);
            }
            inputStream.close();
            questionPack = parseString(str.toString());

        }

        catch(IOException e){
            System.out.println(e.getMessage());

        }
        return questionPack;
    }

    public QuestionPack parseString(String input){

        QuestionPack questionPack = new QuestionPack();
        Question question;

        try{
            JSONObject quizObject = new JSONObject(input);
            JSONArray results = quizObject.getJSONArray("questions");

            questionPack.setName(quizObject.getString("name"));
            questionPack.setDescription(quizObject.getString("description"));

            for(int i=0; i<results.length(); i++){
                JSONObject result = results.getJSONObject(i);
                question = new Question();
                question.addTopics(parseValues(result, "topics"));
                question.addAnswers(parseValues(result, "answerChoices"),false);
                question.addAnswers(parseValues(result, "correctAnswers"), true);
                question.setTrivia(result.getString("trivia"));
                question.setQuestionText(result.getString("questionText"));
                questionPack.addQuestion(question);
            }
        }catch(JSONException e){
            Log.i("JSON EXCEPTION","Oh well. Unable to read JSON string: " + input);
        }
        return questionPack;
    }

    public Question parseQuestion(String json){
        Question outputQuestion = null;
        try {
            JSONObject jsonObject = new JSONObject(json);
            Question question = new Question();

            question.addTopics(parseValues(jsonObject, "topics"));
            question.addAnswers(parseValues(jsonObject, "answerChoices"),false);
            question.addAnswers(parseValues(jsonObject, "correctAnswers"), true);
            question.setTrivia(jsonObject.getString("trivia"));
            question.setQuestionText(jsonObject.getString("questionText"));
            outputQuestion = question;
        }catch (JSONException e){
            Log.i("JSON Exception", "Unable to parse question from : " +  json);
        }
        return outputQuestion;
    }

    private String getTopicsFromQuestion(JSONObject question){

        List <String> topicsList = parseValues(question, "topics");
        StringBuilder topics = new StringBuilder();
        for(String topic : topicsList){
            topics.append(topic);
            topics.append(TOPICS_DELIMITER);
        }
        return topics.toString();
    }

    public QuestionPackDBDetail parseQuestionPackFromJson(String data){
        QuestionPackDBDetail questionPackDBDetail = new QuestionPackDBDetail();
        try {
            JSONObject quizObject = new JSONObject(data);
            Log.i("json parser", "data: " + data);

            questionPackDBDetail = new QuestionPackDBDetail(
                    quizObject.getString("name"),
                    quizObject.getString("author"),
                    quizObject.getString("description"),
                    quizObject.getString("date"),
                    System.currentTimeMillis(),
                    quizObject.getInt("numberOfQuestions"),
                    quizObject.getInt("version"));

            JSONArray results = quizObject.getJSONArray("questions");

            Log.i("json parser", "questions as string: " + results.toString());
            for(int i = 0; i < results.length(); i++){
                JSONObject result = results.getJSONObject(i);
                String question = result.toString();
                String topics = getTopicsFromQuestion(result);
                // Don't need to worry about getting flags until later, but do need to add flags to the DB schema
                String flags = "";
                QuestionDBDetail questionDbDetail = new QuestionDBDetail(question, topics, flags);
                questionPackDBDetail.addQuestion(questionDbDetail);
            }
        }catch(JSONException e){
            Log.i("JSON EXCEPTION","Unable to read JSON string: " + data);
        }
        return questionPackDBDetail;
    }


    private List<String> parseValues(JSONObject result, String arrayName){

        List<String> valuesList = new ArrayList<>();
        try {
            JSONArray jsonValueArray = result.getJSONArray(arrayName);
            if(jsonValueArray !=null){
                for(int i=0; i<jsonValueArray.length();i++){
                    String value = jsonValueArray.getString(i).trim();

                    value = value.trim();
                    if (value.startsWith("\"")) {
                        value = value.substring(1);
                    }
                    if (value.endsWith("\"")) {
                        value = value.substring(0, value.length() - 1);
                    }
                    if (!value.equals("")) {
                        valuesList.add(value);
                    }
                }
            }

        }catch(JSONException e){
            Log.i("JSONEXCEPTION:", " Unable to parseFile json list: " + arrayName);
        }
        return valuesList;
    }



}
