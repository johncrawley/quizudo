package com.jacsstuff.quizucan.manager;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by John on 31/12/2016.
 *
 *
 */
public class QuestionPackDBHelper extends SQLiteOpenHelper {

    private static QuestionPackDBHelper instance;

    // If you change the database schema, you must increment the database version.
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "Quiz.db";

    private static final String OPENING_BRACKET = " (";
    private static final String CLOSING_BRACKET = " );";
    private static final  String INTEGER = " INTEGER";
    private static final String TEXT = " TEXT";
    private static final String COMMA = ",";
    private static final String PRIMARY_KEY = " PRIMARY KEY";


    private static final String SQL_CREATE_QUESTION_ENTRIES =
            "CREATE TABLE IF NOT EXISTS " + DbContract.QuestionsEntry.TABLE_NAME + OPENING_BRACKET +
                    DbContract.QuestionPackEntry._ID                          + INTEGER + PRIMARY_KEY + COMMA +
                    DbContract.QuestionsEntry.COLUMN_NAME_QUESTION_PACK_ID    + INTEGER               + COMMA +
                    DbContract.QuestionsEntry.COLUMN_NAME_QUESTION            + TEXT                  + COMMA +
                    DbContract.QuestionsEntry.COLUMN_NAME_FLAGS               + TEXT                  + COMMA +
                    DbContract.QuestionsEntry.COLUMN_NAME_TOPICS              + TEXT + CLOSING_BRACKET;

    private static final String SQL_CREATE_QUESTION_PACK_ENTRIES =
            "CREATE TABLE IF NOT EXISTS " + DbContract.QuestionPackEntry.TABLE_NAME + OPENING_BRACKET +
                    DbContract.QuestionPackEntry._ID                            + INTEGER + PRIMARY_KEY + COMMA +
                    DbContract.QuestionPackEntry.COLUMN_NAME_AUTHOR             + TEXT                  + COMMA +
                    DbContract.QuestionPackEntry.COLUMN_NAME_DATE_CREATED       + TEXT                  + COMMA +
                    DbContract.QuestionPackEntry.COLUMN_NAME_DATE_DOWNLOADED    + INTEGER               + COMMA +
                    DbContract.QuestionPackEntry.COLUMN_NAME_VERSION            + INTEGER               + COMMA +
                    DbContract.QuestionPackEntry.COLUMN_NAME_NUMBER_OF_QUESTIONS+ INTEGER               + COMMA +
                    DbContract.QuestionPackEntry.COLUMN_NAME_DESCRIPTION        + TEXT                  + COMMA +
                    DbContract.QuestionPackEntry.COLUMN_NAME_UNIQUE_NAME        + TEXT                  + COMMA +
                    DbContract.QuestionPackEntry.COLUMN_NAME_TITLE              + TEXT + CLOSING_BRACKET;


    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + DbContract.QuestionsEntry.TABLE_NAME;


    private QuestionPackDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public static QuestionPackDBHelper getInstance(Context context){
        if(instance == null){
            instance = new QuestionPackDBHelper(context);
        }
        return instance;
    }
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_QUESTION_ENTRIES);
        db.execSQL(SQL_CREATE_QUESTION_PACK_ENTRIES);

    }
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
    }
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }





}
