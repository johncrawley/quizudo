package com.jacsstuff.quizucan.Activities;

import android.content.Context;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;
import android.widget.TextView;

import com.jacsstuff.quizucan.R;
import com.jacsstuff.quizucan.Utils;
import com.jacsstuff.quizucan.WebViewFactory;

public class TestActivity extends AppCompatActivity {
 private Context context;
    TextView textResult;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
        context = TestActivity.this;
        String url = "http://quizudo.byethost7.com/listAvailableFiles.php?userId=geography";
        textResult = (TextView)findViewById(R.id.textResult);

        HttpGrabber task = new HttpGrabber();
        final WebView webView = WebViewFactory.getWebview(context, task);
        webView.loadUrl("http://quizudo.byethost7.com/listAvailableFiles.php?userId=geography");
    }


    private class HttpGrabber extends AsyncTask<String, String, Integer> {

        String data  = "";
        public Integer doInBackground(String... params){
            data = Utils.getMessageBody(params[0]);
            return 1;
        }

        public void onPostExecute(Integer value){

            Utils.toast(context, data);
            textResult.setText(data);
        }
    }






}