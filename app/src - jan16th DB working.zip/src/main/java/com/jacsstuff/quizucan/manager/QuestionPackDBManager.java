package com.jacsstuff.quizucan.manager;

import android.content.Context;
import android.util.Log;

import com.jacsstuff.quiz.Question;
import com.jacsstuff.quiz.QuestionPack;
import com.jacsstuff.quizucan.QuestionPackDetail;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by John on 31/12/2016.
 *
 *  Takes care of managing the the db connection for loading and saving question packs
 *  Also contains a detailed list of question packs available
 * TODO: what happens if a user downloads the same question pack again
 *   delete existing and overwrite?
 *   still need to implement delete code.
 */
public class QuestionPackDBManager implements QuestionPackManager {

    DBWriter dbWriter;
    private Map<Integer, QuestionPackDetail> questionPacks;


    public QuestionPackDBManager(Context context){
        questionPacks = new HashMap<>();
        dbWriter = new DBWriter(context);
    }

    public int saveQuestionPacks(Map<String, String> dataChunks, String authorName){

        int successCount = 0;
        for(String key: dataChunks.keySet()){
           if(dbWriter.addQuestionPack(dataChunks.get(key))){
               successCount++;
           };
        }
        return successCount;
    }

    public List<QuestionPackDetail> getQuestionPackDetails() {
        this.questionPacks = dbWriter.getQuestionPackDetails();
        List<QuestionPackDetail> qpDetailList = new ArrayList<>();
        for (int key : questionPacks.keySet()){
            qpDetailList.add(questionPacks.get(key));
        }
        return qpDetailList;
    }

    public int deleteQuestionPacks(Set<Integer> ids){

        int successfullyDeletedCount = dbWriter.deleteQuestionPacks(getQuestionPackUniqueNames(ids));

        return successfullyDeletedCount;
    }

    private Set<Long> getRowIdSet(Set <Integer> ids){
        Set <Long> questionPackRowIdList= new HashSet<>();
        for( int key : ids){
            questionPackRowIdList.add(questionPacks.get(key).getId());
        }
        return questionPackRowIdList;
    }

    private Set<String> getQuestionPackUniqueNames(Set <Integer> ids){

        Set <String> uniqueNames = new HashSet<>();
        for(int id: ids){
            QuestionPackDetail qpDetail = questionPacks.get(id);
            if(qpDetail != null){
                uniqueNames.add(qpDetail.getUniqueName());
            }
        }
        return uniqueNames;
    }

    public List <QuestionPack> getQuestionPacks(Set<Integer> ids){
        return null;
    }

    public List <Question> getQuestions(Set<Integer> keys){
        StringBuilder idBldr = new StringBuilder();
        Set<Long> ids = new HashSet<>();
        for(int key: keys){
            QuestionPackDetail qpDetail = questionPacks.get(key);
            if(qpDetail != null) {
                ids.add(qpDetail.getId());
            }
        }

        for(Long id : ids){
            idBldr.append(" ");
            idBldr.append(id);
        }
        Log.i("QPDBManager","getQuestionPacks() - ids: "+ idBldr.toString());
      // return dbWriter.getQuestions(getRowIdSet(ids));
        return dbWriter.getQuestions(ids);
    }

    public boolean isEmpty(){
        return questionPacks.isEmpty();
    }


    public void closeConnections(){
        dbWriter.closeConnection();
    }
}
