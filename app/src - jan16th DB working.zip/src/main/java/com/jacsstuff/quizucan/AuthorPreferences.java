package com.jacsstuff.quizucan;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.widget.ArrayAdapter;

import java.util.HashSet;
import java.util.Set;

/**
 * Created by John on 09/12/2016.
 */
public class AuthorPreferences {

    private Context context;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor preferencesEditor;
    public AuthorPreferences(Context context){

        this.context = context;
        sharedPreferences = context.getSharedPreferences("authors", context.MODE_PRIVATE);
        preferencesEditor = sharedPreferences.edit();
    }


    public Set<String> saveAuthorName(String authorName){
        Set<String> authors = new HashSet<>();
        authors.addAll(sharedPreferences.getStringSet(context.getResources().getString(R.string.prefkey_authors), new HashSet<String>(0)));
        Log.i("performSearch", "authorsSet size on load from prefs: " + authors.size());
        authors.add(authorName);
        preferencesEditor.putStringSet(context.getResources().getString(R.string.prefkey_authors), authors);
        preferencesEditor.apply();
        return authors;
    }

    public String[] getAuthors(){
        Set<String> authorsSet = sharedPreferences.getStringSet(context.getResources().getString(R.string.prefkey_authors), new HashSet<String>(0));
        return authorsSet.toArray(new String[authorsSet.size()]);
    }

    public void removeAuthorName(String authorName){
        Set<String> authors = new HashSet<>();
        authors.addAll(sharedPreferences.getStringSet(context.getResources().getString(R.string.prefkey_authors), new HashSet<String>(0)));
        authors.remove(authorName);
        preferencesEditor.putStringSet(context.getResources().getString(R.string.prefkey_authors), authors);
        preferencesEditor.apply();
    }
}
