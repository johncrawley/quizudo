package com.jacsstuff.quizucan.manager;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by John on 07/01/2017.
 *
 *
 QuestionPAckDBDetail
 name
 author
 description
 date created - set by the server on QP creation
 date downloaded (to be added).. by the parser class?
 [[topics? no!!! only a question has a topic]]
 */
public class QuestionPackDBDetail {

    private String name;
    private String author;
    private String description;
    private String dateCreated;
    private List<QuestionDBDetail> questionDetails;
    private long dateDownloaded;
    private String uniqueName;
    private int version;
    private int numberOfQuestions;

    public QuestionPackDBDetail(){

    }
    public QuestionPackDBDetail(String name, String author, String description, String dateCreated, long dateDownloaded, int numberOfQuestions, int version){

        this.name = name;
        this.author = author;
        this.description = description;
        this.dateCreated = dateCreated;
        this.dateDownloaded = dateDownloaded;
        this.questionDetails = new ArrayList<>();
        this.uniqueName = author + "_" + name;
        this.numberOfQuestions = numberOfQuestions;
        this.version = version;
    }

    public void addQuestion(QuestionDBDetail questionDetail){
        this.questionDetails.add(questionDetail);
    }


    public int getNumberOfQuestions() {
        return numberOfQuestions;
    }

    public void setNumberOfQuestions(int numberOfQuestions) {
        this.numberOfQuestions = numberOfQuestions;
    }

    public String getUniqueName(){return this.uniqueName;}

    public List<QuestionDBDetail> getQuestionDetails(){
        return this.questionDetails;
    }

    public long getDateDownloaded() {
        return dateDownloaded;
    }

    public void setDateDownloaded(long dateDownloaded) {
        this.dateDownloaded = dateDownloaded;
    }

    public String getName() {
        return name;
    }
    public int getVersion() {
        return version;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(String dateCreated) {
        this.dateCreated = dateCreated;
    }







}
