package com.jacsstuff.quizucan.Activities;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;

import static com.jacsstuff.quizucan.Utils.AUTHOR_NAME_INTENT_EXTRA;
import static com.jacsstuff.quizucan.Utils.NO_QUESTIONS_FOUND_RESPONSE;
import static com.jacsstuff.quizucan.Utils.QUESTION_PACK_NAMES_INTENT_EXTRA;
import static com.jacsstuff.quizucan.Utils.RESPONSE_PARSE_ERROR;
import static com.jacsstuff.quizucan.Utils.USER_NOT_FOUND_RESPONSE;

import com.jacsstuff.quizucan.LoadingDialog;
import com.jacsstuff.quizucan.list.QuestionPackSimpleList;
import com.jacsstuff.quizucan.manager.QuestionPackDBManager;
import com.jacsstuff.quizucan.R;
import com.jacsstuff.quizucan.RequestManager;
import com.jacsstuff.quizucan.RequestType;
import com.jacsstuff.quizucan.Utils;
import com.jacsstuff.quizucan.WebViewFactory;
import com.jacsstuff.quizucan.manager.QuestionPackManager;

import java.util.Map;

public class DownloadQuestionPacksActivity extends AppCompatActivity {


    private Context context;
    protected boolean isResponseGood;
    private RequestManager requestManager;
    private QuestionPackManager questionPackManager;
    private WebView webView;
    protected String [] questionPackNames;
    private String authorName;
    private LoadingDialog loadingDialog;

    private QuestionPackSimpleList listGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_download_question_packs);
        context = DownloadQuestionPacksActivity.this;
        setupToolbar();
        listGroup = new QuestionPackSimpleList(context, this);
        requestManager = new RequestManager(context);
        questionPackManager = new QuestionPackDBManager(context);
        questionPackNames = getIntent().getStringArrayExtra(QUESTION_PACK_NAMES_INTENT_EXTRA);
        authorName = getIntent().getStringExtra(AUTHOR_NAME_INTENT_EXTRA);
        setToolbarTitle();
        loadingDialog = new LoadingDialog(context, R.string.download_qp_dialog_message);
        setupViews();
    }

    private void setupViews(){
        listGroup.setListView(R.id.listView);
        listGroup.setButtonView(R.id.downloadSelectedButton);
        listGroup.setTextView(R.id.noQuestionPacksAvailableText);
        listGroup.initializeSimpleList(questionPackNames);

        listGroup.setButtonOnClick(new View.OnClickListener() {

            public void onClick(View view){
                requestManager.setParameter(Utils.AUTHOR_NAME_PARAM, authorName);
                requestManager.setParameter(Utils.QUIZ_PACK_NAMES_PARAM, listGroup.getSelectedStrings());
                String requestUrl = requestManager.getUrl(RequestType.GET_QUESTION_PACKS);

                webView = WebViewFactory.getWebview(context, new HttpGrabber());
                loadingDialog.show();
                webView.loadUrl(requestUrl);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home_enabled_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if(id == R.id.home_menu_item) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy(){
        Log.i("DownloadQP", "Entered onDestroy");
        questionPackManager.closeConnections();
        super.onDestroy();
    }
    @Override
    protected void onPause(){

        Log.i("DownloadQP", "Entered onPause");
        questionPackManager.closeConnections();
        super.onPause();
    }
    @Override
    protected void onStop(){
        Log.i("DownloadQP", "Entered onStop");
        questionPackManager.closeConnections();
        super.onStop();
    }
    @Override
    protected void onResume(){
        questionPackManager = new QuestionPackDBManager(context);
        super.onResume();
    }



    private void setupToolbar(){
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        ActionBar actionBar = getSupportActionBar();
        if(actionBar != null){
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayOptions(ActionBar.DISPLAY_HOME_AS_UP | ActionBar.DISPLAY_SHOW_TITLE );
        }
    }



    private void setToolbarTitle(){
        String title = getResources().getString(R.string.author_title);
        if(authorName != null){
           title = title.concat(authorName);
        }
        ActionBar actionBar = getSupportActionBar();
        if(actionBar != null){
            actionBar.setTitle(title);
         }
    }


    private class HttpGrabber extends AsyncTask<String, String, Integer> {

        String response  = "";
        String toastMessage = "";

        public Integer doInBackground(String... params){

            int downloadCount;
            String request = params[0];
            response = Utils.getMessageBody(request);
            
            if(response.equals(RESPONSE_PARSE_ERROR)){
                toastMessage = getResources().getString(R.string.server_error);
            }
            else if(response.contains(USER_NOT_FOUND_RESPONSE)){
                toastMessage = getResources().getString(R.string.user_not_found_message);
            }
            else if(response.contains(NO_QUESTIONS_FOUND_RESPONSE)){
                isResponseGood = true;
                toastMessage = getResources().getString(R.string.user_not_found_message);
            }
            else if(response.isEmpty()){
                toastMessage =  getResources().getString(R.string.server_error_message);
            }
            else{
                Map<String,String> questionPackChunks = Utils.getDataFromResponse(response);
                downloadCount = questionPackManager.saveQuestionPacks(questionPackChunks, authorName);
                isResponseGood = true;
                if(downloadCount == 1){
                    toastMessage =  getResources().getString(R.string.single_download_complete_toast);
                }else {
                    toastMessage = getResources().getString(R.string.download_complete_toast, downloadCount);
                }
            }
            return 1;
        }


        public void onPostExecute(Integer value){

            if(!isResponseGood) {
                Utils.toast(context, toastMessage);
            }
            else{
                // make a toast counting number of successful downloaded files
                Utils.toast(context, toastMessage);
                listGroup.initializeSimpleList(questionPackNames);
            }
            loadingDialog.dismiss();
        }

    }

}
