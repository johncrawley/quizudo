package com.jacsstuff.quizucan.controller;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.ListView;
import android.widget.TextView;

import com.jacsstuff.quizucan.Activities.QuizActivity;
import com.jacsstuff.quizucan.Activities.QuizResultsActivity;
import com.jacsstuff.quizucan.QuestionResult;
import com.jacsstuff.quizucan.QuestionResultsSingleton;
import com.jacsstuff.quizucan.QuizSingleton;
import com.jacsstuff.quizucan.R;
import com.jacsstuff.quizucan.ResultsMessageHelper;
import com.jacsstuff.quizucan.list.ResultsListAdapter;

import java.util.ArrayList;
import java.util.List;

import static com.jacsstuff.quizucan.Utils.DISPLAY_ANSWER_DIALOG_INTENT_EXTRA;
import static com.jacsstuff.quizucan.Utils.NUMBER_OF_QUESTIONS_INTENT_EXTRA;
import static com.jacsstuff.quizucan.Utils.PREVIOUS_NUMBER_OF_QUESTIONS_PREFERENCE;
import static com.jacsstuff.quizucan.Utils.PREVIOUS_SHOW_ANSWER_PREFERENCE;
import static com.jacsstuff.quizucan.Utils.PREVIOUS_SUBMIT_ANSWER_ON_TOUCH_PREFERENCE;
import static com.jacsstuff.quizucan.Utils.QUIZ_SETTINGS_PREFERENCES;
import static com.jacsstuff.quizucan.Utils.SUBMIT_ANSWER_ON_TOUCH_INTENT_EXTRA;

/**
 * Created by John on 29/06/2016.
 *
 * Helps out the Quiz Results Activity
 */
public class QuizResultsController {

    Context context;

    private QuestionResultsSingleton singletonResultsStore;
    private List<QuestionResult> questionResults;
    private String[] resultStringsArray;
    private List <String> resultStringsList;
    private ResultsMessageHelper resultsMessageHelper;
    private QuizResultsActivity quizResultsActivity;
    private TextView quizResultsMessage;
    private ListView quizResultsList;

    public QuizResultsController(Context context, QuizResultsActivity quizResultsActivity) {
        this.context = context;
        this.quizResultsActivity = quizResultsActivity;
        this.quizResultsMessage = quizResultsActivity.getResultsTextView();
        this.quizResultsList = quizResultsActivity.getResultsListView();
        resultStringsList = new ArrayList<>();
        singletonResultsStore = QuestionResultsSingleton.getInstance();
        questionResults = singletonResultsStore.getResults();
        resultsMessageHelper = new ResultsMessageHelper(context);
    }

    public void processResults(){
        for(QuestionResult result : questionResults){
            resultStringsList.add(result.getResultAsString());
        }
        resultStringsArray = resultStringsList.toArray(new String[resultStringsList.size()]);
        int correctAnswerCount = singletonResultsStore.getCorrectAnswerCount();
        int questionCount = questionResults.size();

        quizResultsActivity.setStatistic(correctAnswerCount, questionCount);
        String resultsMessage = resultsMessageHelper.getResultMessage(correctAnswerCount, questionResults.size());
        quizResultsMessage.setText(resultsMessage);
        quizResultsList.setAdapter(new ResultsListAdapter(context, R.layout.result_row, questionResults));

        if(resultStringsList.isEmpty()){
            quizResultsActivity.finish();
        }
    }

    public void retryQuiz(){

        QuizSingleton quizSingleton = QuizSingleton.getInstance();
        quizSingleton.retryQuiz();
        Intent intent = new Intent(context, QuizActivity.class);
        context.startActivity(intent);
    }

}
