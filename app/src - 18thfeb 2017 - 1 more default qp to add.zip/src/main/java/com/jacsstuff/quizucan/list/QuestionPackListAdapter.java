package com.jacsstuff.quizucan.list;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CheckedTextView;
import android.widget.TextView;

import com.jacsstuff.quizucan.QuestionPackDetail;
import com.jacsstuff.quizucan.R;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by John on 12/12/2016.
 * an adapter for UI lists that contain details about the question packs.
 */
public class QuestionPackListAdapter extends ArrayAdapter<QuestionPackDetail> {

    Context context;
    private List<QuestionPackDetail> items;
   // private List<Integer> selectedIds;
   // private int wasAlreadySetCount = 0;
    boolean hasFirstCheckBoxBeenAssigned= false;
    CheckedTextView firstCheckedTextView = null;

    public QuestionPackListAdapter(Context context, int textViewResourceId, List<QuestionPackDetail> items){
        super(context, textViewResourceId, items);
        this.context = context;
        this.items = items;
        Collections.sort(items, new QuestionPackNameComparator());
        //selectedIds = new ArrayList<>();
    }


    /*
    public QuestionPackListAdapter(Context context, int textViewResourceId, List<QuestionPackDetail> items, List<Integer> selectedIds){
        super(context, textViewResourceId, items);
        this.context = context;
        this.items = items;
        this.selectedIds = selectedIds;
    }

    public QuestionPackListAdapter(Context context, int textViewResourceId, List<QuestionPackDetail> items, List<Integer> selectedIds, QuestionPackList questionPackList){
        super(context, textViewResourceId, items);
        this.context = context;
        this.items = items;
        this.selectedIds = selectedIds;

    }



    private void log(String msg){
        Log.i("QP ListAdapter", msg);
    }
*/
    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        View view = convertView;
        if(view == null){
            LayoutInflater vi = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = vi.inflate(R.layout.question_pack_list_item, null);
        }

        QuestionPackDetail questionPackDetail = items.get(position);
        if(questionPackDetail != null){
            TextView displayName = (TextView)view.findViewById(R.id.displayName);
            TextView authorName = (TextView)view.findViewById(R.id.author);
            CheckedTextView checkbox = (CheckedTextView) view.findViewById(R.id.checkbox);

            int id = questionPackDetail.getKey();
            view.setTag(id);

            if(!hasFirstCheckBoxBeenAssigned){
                firstCheckedTextView = checkbox;
                checkbox.setTag(id);
                hasFirstCheckBoxBeenAssigned = true;
            }


            if(displayName != null){
                displayName.setText(questionPackDetail.getName());
            }
            if(authorName != null){
                authorName.setText(questionPackDetail.getAuthor());
            }
            /*
            if(false){
           // if(wasAlreadySetCount <= items.size()) {
                //CheckedTextView checkbox = (CheckedTextView) view.f
                Log.i("QP ListAdapter", "listitem:" + displayName.getText() + " id: " + id + " isChecked:" + checkbox.isChecked());

                if(selectedIds.contains(id)) {
                    boolean preCheck = checkbox.isChecked();
                    checkbox.setChecked(true);
                    boolean postCheck = checkbox.isChecked();
                    Log.i("QP ListAdapter", "Set checkTextView with id:" + id + " pre: " + preCheck + " post: " + postCheck);
                }
                if(hasFirstCheckBoxBeenAssigned){
                    int firstCheckBoxId = (int)firstCheckedTextView.getTag();
                    if(!selectedIds.contains(firstCheckBoxId)){
                        firstCheckedTextView.setChecked(false);
                    }
                }
                wasAlreadySetCount++;
            }
*/
        }
        return view;
    }
}
