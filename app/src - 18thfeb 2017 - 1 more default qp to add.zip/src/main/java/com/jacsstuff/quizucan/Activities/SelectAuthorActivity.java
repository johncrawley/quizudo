package com.jacsstuff.quizucan.Activities;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebView;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.jacsstuff.quizucan.AuthorPreferences;
import com.jacsstuff.quizucan.LoadingDialog;
import com.jacsstuff.quizucan.OneShotToaster;
import com.jacsstuff.quizucan.R;
import com.jacsstuff.quizucan.RequestManager;
import com.jacsstuff.quizucan.RequestType;
import com.jacsstuff.quizucan.Utils;
import com.jacsstuff.quizucan.WebViewFactory;

import java.util.Set;

import static com.jacsstuff.quizucan.Utils.AUTHOR_NAME_INTENT_EXTRA;
import static com.jacsstuff.quizucan.Utils.NO_QUESTIONS_FOUND_RESPONSE;
import static com.jacsstuff.quizucan.Utils.RESPONSE_PARSE_ERROR;
import static com.jacsstuff.quizucan.Utils.USER_NOT_FOUND_RESPONSE;
import static com.jacsstuff.quizucan.Utils.QUESTION_PACK_NAMES_INTENT_EXTRA;
import static com.jacsstuff.quizucan.Utils.DEL_AUTHOR_NAME_INTENT_EXTRA;

public class SelectAuthorActivity extends AppCompatActivity implements ClosableDialog{

    Context context;
    private ListView authorsList;
    private EditText authorInput;
    private RequestManager requestManager;
    private AuthorPreferences authorPreferences;
    private LoadingDialog loadingDialog;
    protected boolean isResponseGood;
    protected String[] questionPackNames;
    protected boolean saveAuthorToPreferences;
    protected String selectedAuthorName;
    private boolean isFirstRequestAttempt; // if request fails, will try again. Only try twice per button click.
    private OneShotToaster toaster;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_author);
        context = SelectAuthorActivity.this;
        toaster = new OneShotToaster(context);
        setupToolbar();
        this.isResponseGood = false;
        authorsList = (ListView) findViewById(R.id.listView);
        authorInput = (EditText) findViewById(R.id.editText);
        setupKeyListener();
        authorPreferences = new AuthorPreferences(context);
        requestManager = new RequestManager(context);
        setupList();
        loadingDialog = new LoadingDialog(context, R.string.loading_dialogue);
    }

    protected void onResume() {
        super.onResume();
        setupList();
    }

    private void setupKeyListener() {

        authorInput.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(authorInput.getWindowToken(), 0);
                    String authorName = v.getText().toString().trim();
                    getAuthorsQuestionPacksFirstAttempt(authorName);
                    saveAuthorToPreferences = true;
                    return true;
                }
                return false;
            }
        });
    }

    private void setupList() {

        final String[] authorsArray = authorPreferences.getAuthors();
        authorsList.setChoiceMode(AbsListView.CHOICE_MODE_SINGLE);
        authorsList.setAdapter(new ArrayAdapter<>(context, android.R.layout.simple_list_item_1, authorsArray));
        authorsList.setSelector(R.color.selectedListItemHidden);
        authorsList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                getAuthorsQuestionPacksFirstAttempt(authorsArray[position]);
                saveAuthorToPreferences = false;
            }
        });

        authorsList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(context, RemoveAuthorActivity.class);
                intent.putExtra(DEL_AUTHOR_NAME_INTENT_EXTRA, authorsArray[position]);
                startActivity(intent);
                return true;
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home_enabled_menu, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if (id == R.id.home_menu_item) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }


    private void setupToolbar() {
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar == null) return;
        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayOptions(ActionBar.DISPLAY_HOME_AS_UP | ActionBar.DISPLAY_SHOW_TITLE);
    }

    private void getAuthorsQuestionPacks(String authorName) {

        if (authorName.equals("")) {
            return;
        }
        this.selectedAuthorName = authorName;
        loadingDialog.show();
        toaster.reset();
        WebView webView = WebViewFactory.getWebview(context, new HttpGrabber(), this);
        requestManager.setParameter(Utils.AUTHOR_NAME_PARAM, authorName);
        String requestUrl = requestManager.getUrl(RequestType.LIST_QUESTION_PACKS);
        try {
            webView.loadUrl(requestUrl);
        }catch(Exception e){
            handleDownloadException(e);
        }
    }

    public void toast(int messageCode){
        toaster.toast(getResources().getString(messageCode));
    }
    public void toast(String message){
        toaster.toast(message);
    }

    public void closeDialog(){
        this.loadingDialog.dismiss();
    }

    private void handleDownloadException(Exception e){
        loadingDialog.dismiss();
        Log.i("SelectAuthor", e.getMessage());
        toast("unable to download question packs.");
    }


    private void getAuthorsQuestionPacksFirstAttempt(String authorName){
        this.isFirstRequestAttempt = true; // resetting value so we don't infinite loop.
        getAuthorsQuestionPacks(authorName);
    }
    private void getAuthorsQuestionPacksSecondAttempt(String authorName){
        this.isFirstRequestAttempt = false; // resetting value so we don't infinite loop.
        getAuthorsQuestionPacks(authorName);
    }


    private void startDownloadQuestionsActivity() {

        Intent intent = new Intent(context, DownloadQuestionPacksActivity.class);
        intent.putExtra(QUESTION_PACK_NAMES_INTENT_EXTRA, questionPackNames);
        intent.putExtra(AUTHOR_NAME_INTENT_EXTRA, this.selectedAuthorName);
        startActivity(intent);
    }


    private class HttpGrabber extends AsyncTask<String, String, Integer> {

        String response  = "";
        String toastMessage = "";
        boolean isSecondAttemptRequired = false;

        public Integer doInBackground(String... params){

            questionPackNames = new String[0];
            response = Utils.getMessageBody(params[0]);

            if(response.equals(RESPONSE_PARSE_ERROR)){
                toastMessage = getResources().getString(R.string.server_error);
                isSecondAttemptRequired = true;
            }
            else if(response.contains(USER_NOT_FOUND_RESPONSE)){
                toastMessage = getResources().getString(R.string.user_not_found_message);
            }
            else if(response.contains(NO_QUESTIONS_FOUND_RESPONSE)){
                isResponseGood = true;
                toastMessage = getResources().getString(R.string.user_not_found_message);
            }
            else if(response.isEmpty()){
                toastMessage =  getResources().getString(R.string.server_error_message);
            }
            else{
                Log.i("selectAuthor", " questionpacknames =" + response);
                isResponseGood = true;
                questionPackNames = response.split(",");
            }
            return 1;
        }


        public void onPostExecute(Integer value){
            loadingDialog.dismiss();
            if(!isResponseGood) {
                if(isSecondAttemptRequired && isFirstRequestAttempt){
                    getAuthorsQuestionPacksSecondAttempt(selectedAuthorName);
                }
                else toast(toastMessage);
            }
            else{
                if(saveAuthorToPreferences) {
                    Set<String> authors = authorPreferences.saveAuthorName(selectedAuthorName);
                    authorsList.setAdapter(new ArrayAdapter<>(context, android.R.layout.simple_list_item_1, authors.toArray(new String[authors.size()])));
                }
                startDownloadQuestionsActivity();
            }
        }

    }
}