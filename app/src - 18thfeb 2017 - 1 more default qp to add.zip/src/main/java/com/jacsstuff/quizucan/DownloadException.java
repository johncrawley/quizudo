package com.jacsstuff.quizucan;

/**
 * Created by John on 19/01/2017.
 */
public class DownloadException extends Exception{
}
