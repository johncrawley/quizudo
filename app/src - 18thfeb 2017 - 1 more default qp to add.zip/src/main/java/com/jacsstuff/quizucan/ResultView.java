package com.jacsstuff.quizucan;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by John on 09/08/2016.
 */
public class ResultView extends View{

    Context context;

    Paint mStatusTextPaint;
    Paint mTriviaTextPaint, mActualAnswerPaint;
    TextString answerStatusText,triviaText, actualAnswerText;
    List<TextString> textStrings;

    Paint mBackgroundPaint;
    Paint mShadowPaint;
    RectF mRectBounds;
    RectF mShadowRectBounds; //a shadow that will cover all the background. Nihilistic.
    int backgroundAlpha;
    int textBackgroundTopMargin; // the margin for the text background
    int textBackgroundBottomMargin; // the bottom margin for the text background

    public ResultView(Context context, AttributeSet attrs){
        super(context, attrs);

        this.context = context;
        answerStatusText = new TextString();
        int x = 60;
        int y = getMeasuredHeight()/2 + 20;
        triviaText       = new TextString(context, x, y, R.color.resultOverlayTriviaText);
        actualAnswerText = new TextString(context, x, y, R.color.resultOverlayActualAnswerText);

        triviaText.setHeight(56);
        actualAnswerText.setHeight(55);

        textStrings = new ArrayList<>();
        textStrings.add(answerStatusText);
        textStrings.add(triviaText);
        textStrings.add(actualAnswerText);

        TypedArray a = context.getTheme().obtainStyledAttributes(
                attrs,
                R.styleable.ResultView,
                0, 0);
        try {
            answerStatusText.setVisibility(a.getBoolean(R.styleable.ResultView_textVisible, true));
            answerStatusText.setText(a.getString(R.styleable.ResultView_text));
            answerStatusText.setHeight(a.getDimension(R.styleable.ResultView_textHeight, 12.0f));
            backgroundAlpha = (a.getInteger(R.styleable.ResultView_backgroundAlpha, 255));
            textBackgroundTopMargin = (a.getInteger(R.styleable.ResultView_background_top_margin,200));
            textBackgroundBottomMargin = (a.getInteger(R.styleable.ResultView_background_bottom_margin,200));


        } finally {
            a.recycle();
        }
        init();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {

        super.onMeasure(widthMeasureSpec, heightMeasureSpec);

        final int height = getMeasuredHeight(); //calculated
        final int width = getMeasuredWidth(); //parent width

        setMeasuredDimension(width, height);
    }

/*
    public void setText(String text){
        answerStatusText.setText(text);
        answerStatusText.setWidth(mStatusTextPaint.measureText(text));
    }
*/
    public void setCorrectAnswer(String heading, String trivia){
        answerStatusText.setText(heading);

        float statusTextWidth = answerStatusText.getTextWidth();
        answerStatusText.setPosition((getMeasuredWidth()/2)- (int)statusTextWidth/2, getMeasuredHeight()/2);
        answerStatusText.getPaint().setColor(ContextCompat.getColor(context,R.color.resultOverlayCorrectAnswerText));

        actualAnswerText.setVisibility(false);

        triviaText.setVisibility(true);
        triviaText.setText(trivia);

        float triviaTextYPosition = getMeasuredHeight()/2 + answerStatusText.getHeight() + (answerStatusText.getHeight()/2);
        triviaText.setPosition(30, (int)triviaTextYPosition);
        invalidate();
        requestLayout();
    }


    public void setIncorrectAnswer(String heading, String actualAnswer){
        answerStatusText.setText(heading);
        float statusTextWidth = answerStatusText.getTextWidth();
        answerStatusText.setPosition((getMeasuredWidth()/2)- (int)statusTextWidth/2, getMeasuredHeight()/2);



        float actualAnswerTextYPosition = getMeasuredHeight()/2 + answerStatusText.getHeight() + (answerStatusText.getHeight()/2);
        actualAnswerText.setPosition(30, (int)actualAnswerTextYPosition);
        actualAnswerText.setText(actualAnswer);
        actualAnswerText.setVisibility(true);
        triviaText.setVisibility(false);

        //mStatusTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        //mStatusTextPaint.setTextSize(answerStatusText.getHeight());

        answerStatusText.getPaint().setColor(ContextCompat.getColor(context,R.color.resultOverlayIncorrectAnswerText));

        invalidate();
    }

    private void init() {
        mStatusTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        mBackgroundPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mBackgroundPaint.setStyle(Paint.Style.FILL);
        mBackgroundPaint.setColor(ContextCompat.getColor(context, R.color.resultOverlayBackground));
       // mStatusTextPaint.setTextSize(answerStatusText.getHeight());

        //mShadowPaint = new Paint(0);
        mShadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mShadowPaint.setStyle(Paint.Style.FILL);
        mShadowPaint.setColor(ContextCompat.getColor(context, R.color.resultBackgroundShadow));
        //mShadowPaint.setMaskFilter(new BlurMaskFilter(8, BlurMaskFilter.Blur.NORMAL));
    }


    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        //draw the full-window shadow
        mShadowPaint.setAlpha(backgroundAlpha);
        canvas.drawRect(mShadowRectBounds, mShadowPaint);

        //draw the status background
        mBackgroundPaint.setAlpha(255);
        canvas.drawRect(mRectBounds,mBackgroundPaint);

        // Draw the label text


        for(TextString textString : textStrings){
           if(textString.isVisible()){
                canvas.drawText(textString.getText(),textString.getPositionX(), textString.getPositionY(), textString.getPaint());
           }
        }

        //mStatusTextPaint.getTextWidths(mText, )
    }


    protected void  onSizeChanged (int w,
                                   int h,
                                   int oldw,
                                   int oldh){

        // Account for padding
        float xpad = (float)(getPaddingLeft() + getPaddingRight());
        float ypad = (float)(getPaddingTop() + getPaddingBottom());

        mRectBounds = new RectF(0.0f,0.0f + textBackgroundTopMargin, w,h - textBackgroundBottomMargin);
        mShadowRectBounds = new RectF(0.0f, 0.0f,w,h);
        // Account for the label
        //if (mShowText) xpad += mTextWidth;

        float ww = (float)w - xpad;
        float hh = (float)h - ypad;
    }

}


class TextString{

    String text;
    int positionX, positionY;
    float width,height;
    boolean visible;
    Paint paint;

    public TextString(){
        this.visible = true;
        this.text = "";
        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    }

    public TextString(Context context, int x, int y, int color){
        this();
        this.positionX = x;
        this.positionY = y;
        this.paint.setColor(ContextCompat.getColor(context,color));
    }

    public Paint getPaint(){
        return this.paint;
    }

    public void setVisibility(boolean visible){
        this.visible = visible;
    }

    public boolean isVisible(){
        return this.visible;
    }

    public String getText() {
        return text;
    }

    public int getPositionX() {
        return positionX;
    }

    public int getPositionY() {
        return positionY;
    }

    public float getWidth() {
        return width;
    }

    public float getHeight() {
        return height;
    }

    public void setHeight(float height){
        this.height = height;
        this.paint.setTextSize(height);
    }


    public float getTextWidth(){
        return this.paint.measureText(this.text);
    }
    public void setWidth(float width){
        this.width = width;
    }

    public void setText(String text){
        if(text == null){
            text = "";
        }
        this.text = text;
    }

    public void setPosition(int x, int y){
        this.positionX = x;
        this.positionY = y;
    }
}


