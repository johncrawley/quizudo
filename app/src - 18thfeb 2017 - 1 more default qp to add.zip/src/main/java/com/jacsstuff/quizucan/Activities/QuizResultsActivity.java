package com.jacsstuff.quizucan.Activities;

import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.TextView;

import com.jacsstuff.quizucan.controller.QuizResultsController;
import com.jacsstuff.quizucan.R;

public class QuizResultsActivity extends AppCompatActivity {

    private TextView quizResultsMessage;
    private TextView quizResultsStatistic;
    private ListView quizResultsList;
    private QuizResultsController quizResultsController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_results);
        setupToolbar();

        quizResultsMessage = (TextView)findViewById(R.id.quiz_results_message);
        quizResultsStatistic = (TextView)findViewById(R.id.quiz_results_statistic);
        quizResultsList = (ListView)findViewById(R.id.quiz_results_list);

        quizResultsController = new QuizResultsController(QuizResultsActivity.this, this);
        quizResultsController.processResults();
    }

    public void finishActivity(){
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.quiz_results_menu, menu);
        return true;
    }

    public ListView getResultsListView(){
        return this.quizResultsList;
    }
    public TextView getResultsTextView(){
        return this.quizResultsMessage;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if(id == R.id.home_menu_item) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        //noinspection SimplifiableIfStatement
        if (id == R.id.retry_menu_item) {
            quizResultsController.retryQuiz();
        }
        return super.onOptionsItemSelected(item);
    }


    private void setupToolbar(){
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        ActionBar actionBar = getSupportActionBar();
        if(actionBar == null){
            return;
        }
        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayOptions(ActionBar.DISPLAY_HOME_AS_UP | ActionBar.DISPLAY_SHOW_TITLE );
        actionBar.setDisplayShowHomeEnabled(true);
        String title = getResources().getString(R.string.quiz_completed_heading);
        actionBar.setTitle(title);
    }

    public void setStatistic(int correctlyAnswered, int totalQuestions){
        quizResultsStatistic.setText(getResources().getString(R.string.quiz_results_statistic, correctlyAnswered, totalQuestions));
    }

}
