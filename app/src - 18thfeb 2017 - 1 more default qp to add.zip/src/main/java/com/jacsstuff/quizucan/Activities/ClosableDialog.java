package com.jacsstuff.quizucan.Activities;

/**
 * Created by John on 19/01/2017.
 *
 *  Anything that implements this will have a loading dialogue that can be dismissed externally.
 *  It should also have a OneShotToaster that can be called. The One Shot Toaster allows only one toast
 *  to be made without being reset, which is useful if you don't want multiple toasts getting made per action.
 */
public interface ClosableDialog {

    void closeDialog();
    void toast(int messageCode);
}
