package com.jacsstuff.quizucan.Activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;

import com.jacsstuff.quizucan.LoadingDialog;
import com.jacsstuff.quizucan.Utils;
import com.jacsstuff.quizucan.list.MenuListAdapter;
import com.jacsstuff.quizucan.list.ListMenuItem;
import com.jacsstuff.quizucan.controller.MainController;
import com.jacsstuff.quizucan.R;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity  {

    private MainController controller;
    private Context context;
    private final int CREATE_QUIZ_BUTTON_ID = 1001;
    private final int MANAGE_QUESTIONS_BUTTON_ID = 1002;
    private final int TEST_DEFAULT_QUESTIONS_RESET = 1004;
    //private final int TEST_DIALOG_ID = 1003;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = MainActivity.this;
        setupToolbar();
        controller = new MainController(context);
        setupMenuList();
    }

    private void setupToolbar(){
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_activity_menu, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if(id == R.id.about_menu_item) {
            Intent intent = new Intent(this, AboutAppActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    private void setupMenuList(){

        ListView menuList;
        List<ListMenuItem> menuItems;

        menuList = (ListView)findViewById(R.id.listView);
        if(menuList == null){
            return;
        }
        menuItems = new ArrayList<>(2);
        menuItems.add(new ListMenuItem(CREATE_QUIZ_BUTTON_ID, getResources().getString(R.string.main_activity_start_quiz_button)));
        menuItems.add(new ListMenuItem(MANAGE_QUESTIONS_BUTTON_ID, getResources().getString(R.string.manage_questions_button_text)));
        //menuItems.add(new ListMenuItem(TEST_DEFAULT_QUESTIONS_RESET, "Reset Default Question Pref"));

        //adding the main title image as a header doesn't work so well.
        //View header = getLayoutInflater().inflate(R.layout.main_logo, null);
        //menuList.addHeaderView(header);
        //menuItems.add(new ListMenuItem(TEST_DIALOG_ID, "Test Dialog activity"));
        MenuListAdapter menuListAdapter = new MenuListAdapter(context, R.layout.menu_row, menuItems);
        menuList.setAdapter(menuListAdapter);
        setListViewHeightBasedOnChildren(menuList);
        menuList.setChoiceMode(AbsListView.CHOICE_MODE_SINGLE);
        menuList.setSelector(R.color.selectedListItem);
        menuList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                loadActivity(view);
            }
        });

    }

    public void loadActivity(View view){
        if(view.getTag() == null){
            return;
        }
        int id = (int)view.getTag();
        Intent intent;
        if(id == CREATE_QUIZ_BUTTON_ID){
           controller.execute("new quiz");
       }else if(id == MANAGE_QUESTIONS_BUTTON_ID){
            intent = new Intent(context, PreferencesActivity.class);
            context.startActivity(intent);
        }
        /*
        else if(id == TEST_DEFAULT_QUESTIONS_RESET){
            SharedPreferences prefs = getSharedPreferences(Utils.QUIZ_SETTINGS_PREFERENCES, MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.remove(Utils.WERE_DEFAULT_QPS_ADDED_PREFERENCE);
            editor.apply();
            Utils.toast(context, "Default Questions Preference reset");
        }*/
    }



    private void setListViewHeightBasedOnChildren(ListView listView) {
        ListAdapter listAdapter = listView.getAdapter();
        if (listAdapter == null) {
            return;
        }

        int totalHeight = 0;
        for (int i = 0; i < listAdapter.getCount(); i++) {
            View listItem = listAdapter.getView(i, null, listView);
            listItem.measure(0,0);
            totalHeight += listItem.getMeasuredHeight();
        }
        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight + (listView.getDividerHeight() * (listAdapter.getCount() - 1));
        listView.setLayoutParams(params);
    }

}
