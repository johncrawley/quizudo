package com.jacsstuff.quizucan.manager;

import com.jacsstuff.quiz.Question;
import com.jacsstuff.quiz.QuestionPack;
import com.jacsstuff.quizucan.model.QuestionPackDetail;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by John on 19/12/2016.
 * Interface.
 */
public interface QuestionPackManager {


        int saveQuestionPacks(Map<String, String> dataChunks, String authorName);
        List<QuestionPackDetail> getQuestionPackDetails();
        int deleteQuestionPacks(Set<Integer> ids);
        List <QuestionPack> getQuestionPacks(Set<Integer> ids);
        List <Question> getQuestions(Set<Integer> ids);
        void  closeConnections();
        boolean isEmpty();
}

