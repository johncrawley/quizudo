package com.jacsstuff.quizucan.list;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import com.jacsstuff.quizucan.R;
import com.jacsstuff.quizucan.controller.MainController;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by John on 23/02/2017.
 * Wrapper for a list view with some extra work done to display the main menu items
 */
public class MenuListView {

    private ListView menuList;
    private List<ListMenuItem> menuItems;
    private Context context;
    private MainController controller;

    public MenuListView(View listView, Context context, MainController controller) {
        menuList = (ListView) listView;
        menuItems = new ArrayList<>(2);
        this.context = context;
        this.controller = controller;
    }

    public void addItem(int id, String name){
        menuItems.add(new ListMenuItem(id, name));
    }

    public void init(){
        if(menuList == null || controller == null){
            return;
        }
        MenuListAdapter menuListAdapter = new MenuListAdapter(context, R.layout.menu_row, menuItems);
        menuList.setAdapter(menuListAdapter);
        setListViewHeightBasedOnChildren(menuList);
        menuList.setChoiceMode(AbsListView.CHOICE_MODE_SINGLE);
        menuList.setSelector(R.color.selectedListItem);
        setupListClick(controller);
    }

    public void setupListClick(final MainController controller) {
        menuList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                controller.loadActivity(view);
            }
        });
    }


    private void setListViewHeightBasedOnChildren(ListView listView) {
        ListAdapter listAdapter = listView.getAdapter();
        if (listAdapter == null) {
            return;
        }

        int totalHeight = 0;
        for (int i = 0; i < listAdapter.getCount(); i++) {
            View listItem = listAdapter.getView(i, null, listView);
            listItem.measure(0,0);
            totalHeight += listItem.getMeasuredHeight();
        }
        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight + (listView.getDividerHeight() * (listAdapter.getCount() - 1));
        listView.setLayoutParams(params);
    }

}
