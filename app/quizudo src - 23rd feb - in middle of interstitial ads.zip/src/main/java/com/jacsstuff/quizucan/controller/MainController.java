package com.jacsstuff.quizucan.controller;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.View;

import com.jacsstuff.quizucan.Activities.CreateQuizActivity;
import com.jacsstuff.quizucan.Activities.MainActivity;
import com.jacsstuff.quizucan.Activities.PreferencesActivity;
import com.jacsstuff.quizucan.Activities.QuizActivity;

/**
 * Created by John on 27/06/2016.
 * Performing some logic for the main activity
 */
public class MainController {

    Context context;
    MainActivity mainActivity;

    public MainController(MainActivity mainActivity, Context context){

        this.mainActivity = mainActivity;
        this.context = context;
    }

    public void newQuiz(){
        Log.i("new Quiz", "Beginning new quiz");
        Intent intent = new Intent(context, CreateQuizActivity.class);
        context.startActivity(intent);
    }


    public void loadActivity(View view){
        if(view.getTag() == null){
            return;
        }
        int id = (int)view.getTag();
        Intent intent;
        if(id == mainActivity.CREATE_QUIZ_BUTTON_ID){
            newQuiz();
        }else if(id == mainActivity.MANAGE_QUESTIONS_BUTTON_ID){
            intent = new Intent(context, PreferencesActivity.class);
            context.startActivity(intent);
        }
        /*
        else if(id == TEST_DEFAULT_QUESTIONS_RESET){
            SharedPreferences prefs = getSharedPreferences(Utils.QUIZ_SETTINGS_PREFERENCES, MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.remove(Utils.WERE_DEFAULT_QPS_ADDED_PREFERENCE);
            editor.apply();
            Utils.toast(context, "Default Questions Preference reset");
        }*/
    }

}
