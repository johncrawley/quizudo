package com.jacsstuff.quizucan.controller;

import android.content.Context;
import android.content.Intent;
import android.widget.ListView;
import android.widget.TextView;

import com.jacsstuff.quizucan.Activities.QuizActivity;
import com.jacsstuff.quizucan.Activities.QuizResultsActivity;
import com.jacsstuff.quizucan.model.QuestionResult;
import com.jacsstuff.quizucan.model.QuestionResultsSingleton;
import com.jacsstuff.quizucan.model.QuizSingleton;
import com.jacsstuff.quizucan.R;
import com.jacsstuff.quizucan.ResultsMessageHelper;
import com.jacsstuff.quizucan.list.ResultsListAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by John on 29/06/2016.
 *
 * Helps out the Quiz Results Activity
 */
public class QuizResultsController {

    Context context;

    private QuestionResultsSingleton singletonResultsStore;
    private List<QuestionResult> questionResults;
    private String[] resultStringsArray;
    private List <String> resultStringsList;
    private ResultsMessageHelper resultsMessageHelper;
    private QuizResultsActivity quizResultsActivity;
    private TextView quizResultsMessage;
    private ListView quizResultsList;

    public QuizResultsController(Context context, QuizResultsActivity quizResultsActivity) {
        this.context = context;
        this.quizResultsActivity = quizResultsActivity;
        this.quizResultsMessage = quizResultsActivity.getResultsTextView();
        this.quizResultsList = quizResultsActivity.getResultsListView();
        resultStringsList = new ArrayList<>();
        singletonResultsStore = QuestionResultsSingleton.getInstance();
        questionResults = singletonResultsStore.getResults();
        resultsMessageHelper = new ResultsMessageHelper(context);
    }

    public void processResults(){
        for(QuestionResult result : questionResults){
            resultStringsList.add(result.getResultAsString());
        }
        resultStringsArray = resultStringsList.toArray(new String[resultStringsList.size()]);
        int correctAnswerCount = singletonResultsStore.getCorrectAnswerCount();
        int questionCount = questionResults.size();

        quizResultsActivity.setStatistic(correctAnswerCount, questionCount);
        String resultsMessage = resultsMessageHelper.getResultMessage(correctAnswerCount, questionResults.size());
        quizResultsMessage.setText(resultsMessage);
        quizResultsList.setAdapter(new ResultsListAdapter(context, R.layout.result_row, questionResults));

        if(resultStringsList.isEmpty()){
            quizResultsActivity.finish();
        }
    }

    public void retryQuiz(){

        QuizSingleton quizSingleton = QuizSingleton.getInstance();
        quizSingleton.retryQuiz();
        Intent intent = new Intent(context, QuizActivity.class);
        context.startActivity(intent);
    }

}
