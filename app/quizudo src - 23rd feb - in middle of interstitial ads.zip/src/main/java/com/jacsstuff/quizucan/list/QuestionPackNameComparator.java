package com.jacsstuff.quizucan.list;

import com.jacsstuff.quizucan.model.QuestionPackDetail;

import java.util.Comparator;

/**
 * Created by John on 04/02/2017.
 * Used for sorting the lists of question packs by name
 */
public class QuestionPackNameComparator implements Comparator<QuestionPackDetail>  {

    public int compare(QuestionPackDetail qp1, QuestionPackDetail qp2){
        String name1 = qp1.getName();
        String name2 = qp2.getName();
        return name1.compareToIgnoreCase(name2);
    }

}
