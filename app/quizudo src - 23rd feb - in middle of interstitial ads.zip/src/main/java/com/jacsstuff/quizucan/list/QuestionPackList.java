package com.jacsstuff.quizucan.list;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.ListView;
import android.widget.TextView;

import com.jacsstuff.quizucan.model.QuestionPackDetail;
import com.jacsstuff.quizucan.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by John on 27/12/2016.
 *
 * This class groups together a list used to display question pack items,
 *  the textView that is shown when no question pack items are in the list,
 *  and the button that performs the action on the selected question pack items.
 *
 * The action performed by the button will change per activity, so there is a public method
 *  that allows the caller to specify an OnClickListener for it.
 *
 */
public class QuestionPackList {

    protected ListView listView; //the list that contains  the question pack items
    protected Button buttonView; // the button that initiates the action to be performed on the selected list items
    protected TextView noQuestionPacksFoundText; // the text that will appear when there are no list items to display
    protected Context context;
    private Map <Integer, Boolean> isSelectedMap;
    protected Activity activity;
/*
    public QuestionPackList(Context context, Activity a, int listId, int buttonId, int textId){
        this.context = context;
        this.activity = a;
        listView = (ListView)getView(listId);
        buttonView = (Button)getView(buttonId);
        noQuestionPacksFoundText = (TextView)getView(textId);
        isSelectedMap = new HashMap<>();
    }
*/

    public QuestionPackList(Context context, Activity a){
        this.context = context;
        this.activity = a;
        isSelectedMap = new HashMap<>();
    }

    public void setButtonView(int buttonId){
        buttonView = (Button)getView(buttonId);
    }

    public void setListView(int listId){
        listView = (ListView)getView(listId);
    }
    public void setTextView(int textId){
        noQuestionPacksFoundText = (TextView)getView(textId);
    }

    public void disableButton(){
        buttonView.setEnabled(false);
    }

    private View getView(int id){
        return activity.findViewById(id);
    }

    public void setButtonOnClick(View.OnClickListener listener){
        buttonView.setOnClickListener(listener);
    }

    public void initializeList(final List<QuestionPackDetail> questionPackDetails){
        log("Entered InitializeList()-v1");
        setupViews(!questionPackDetails.isEmpty());
        final ArrayAdapter arrayAdapter = new QuestionPackListAdapter(context, android.R.layout.simple_list_item_checked, questionPackDetails);
        setListViewOptions(arrayAdapter);
        setupListClickListener();
        disableButton();
        arrayAdapter.notifyDataSetChanged();
    }

    public void initializeList(final List<QuestionPackDetail> questionPackDetails, int[] previouslySelectedIds){
        log("Entered InitializeList()-v2");
        setupViews(!questionPackDetails.isEmpty());
        List<Integer> previouslySelectedIdsList = new ArrayList<>();
        if(previouslySelectedIds!=null) {
            for (int i : previouslySelectedIds) {
                previouslySelectedIdsList.add(i);
            }
        }
        final ArrayAdapter arrayAdapter = new QuestionPackListAdapter(context, android.R.layout.simple_list_item_checked, questionPackDetails);
        setListViewOptions(arrayAdapter);
        setupListClickListener();
        setSelectedIds(previouslySelectedIds);
        setButtonEnabledState();

        if(previouslySelectedIds != null){
            for(int i : previouslySelectedIds) {
            isSelectedMap.put(i, true);
            log("about to click on item with id: " + i);
            listView.performItemClick(listView.getChildAt(i), i, listView.getItemIdAtPosition(i));
            }
        }
        arrayAdapter.notifyDataSetChanged();
    }

    protected void setupViews(boolean areItemsPresent){
        if(areItemsPresent){
            setupViewsForItemsPresent();
            return;
        }
        setupViewsForItemsNotPresent();
    }

    private void setupViewsForItemsPresent(){
        noQuestionPacksFoundText.setVisibility(View.GONE);
    }

    // what happens when there are no items in the list: we display a "nothing found" message instead.
    private void setupViewsForItemsNotPresent(){
        listView.setVisibility(View.GONE);
        buttonView.setVisibility(View.GONE);
        noQuestionPacksFoundText.setVisibility(View.VISIBLE);
    }

    protected void setListViewOptions(ArrayAdapter arrayAdapter){
        listView.setChoiceMode(AbsListView.CHOICE_MODE_MULTIPLE);
        listView.setAdapter(arrayAdapter);
        listView.setSelector(R.color.selectedListItemHidden);
    }


    protected void setupListClickListener(){
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){

                ViewGroup layout = (ViewGroup)view;
                if(layout == null){return;}
                CheckedTextView checkedTextItem = (CheckedTextView)layout.getChildAt(1);
                if(checkedTextItem == null){return;}
                boolean isChecked = checkedTextItem.isChecked();
                isChecked = !isChecked;
                checkedTextItem.setChecked(isChecked);
                int questionPackId = (int)view.getTag();
                isSelectedMap.put(questionPackId, isChecked);
                log("list item clicked; isSelectedMap set to " + isChecked + ", checkedTextItem status: " + checkedTextItem.isChecked());
                for(int qpId : isSelectedMap.keySet()){
                    log("qp: " + qpId + " status: " + isSelectedMap.get(qpId));
                }

                setButtonEnabledState();
            }
        });
    }

    private void setButtonEnabledState(){
        if(!isSomethingSelected(isSelectedMap)){
            buttonView.setEnabled(false);
        }
        else{
            buttonView.setEnabled(true);
        }


    }

    private static boolean isSomethingSelected(Map<Integer, Boolean> itemsMap){

        boolean isSomethingSelected = false;
        for(int tempKey: itemsMap.keySet()){
            if(itemsMap.get(tempKey)){
                isSomethingSelected = true;
                break;
            }
        }
        return isSomethingSelected;
    }

    public Set<Integer> getSelectedIds(){
        Set <Integer> selectedIds = new HashSet<>();
        for(int id : isSelectedMap.keySet()){
            if(isSelectedMap.get(id)){
                selectedIds.add(id);
            }
        }
        return selectedIds;
    }

    public int[] getSelectedIdsArray(){

        List <Integer> selectedIdsList = new ArrayList<>();
        for(int id : isSelectedMap.keySet()){
            if(isSelectedMap.get(id)){
                selectedIdsList.add(id);
            }
        }
        int[] selectedIdsArray = new int[selectedIdsList.size()];
        for(int i=0; i< selectedIdsList.size(); i++){
            selectedIdsArray[i] = selectedIdsList.get(i);
        }
        return selectedIdsArray;
    }


    private void log(String msg){
        Log.i("QuestionPackList", msg);
    }



    public void setSelectedIds(int[] selectedIdsArray){
        if(selectedIdsArray == null){
            return;
        }
        for(int i : selectedIdsArray){
            isSelectedMap.put(i, true);
            //log("about to click on item with id: " + i);
            //listView.performItemClick(listView.getChildAt(i), i, listView.getItemIdAtPosition(i));


            /*
            ViewGroup layout = (ViewGroup) listView.findViewWithTag(i);
            int count = listView.getCount();
            for(int j=0; j<count; j++){
                ViewGroup vg = (ViewGroup)listView.getItemAtPosition(j);//listView.getChildAt(i);
                if(vg == null){
                    log("viewGroup child at " + j + " is null");
                }
                listView.getItemAtPosition(j);

            }
            log("list view count: " + count);
            if(layout == null){
                continue;
            }
            CheckedTextView checkedTextView = (CheckedTextView)layout.findViewById(R.id.checkbox);
            checkedTextView.setChecked(true);
            */
        }
    }
}




