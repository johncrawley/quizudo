package com.jacsstuff.quizucan;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import java.util.HashSet;
import java.util.Set;

/**
 * Created by John on 09/12/2016.
 *
 * Supplies a list of existing (already searched-for) authors to the Select Authors Activity
 *  to display in the quick list.
 */
public class AuthorPreferences {

    private final String IS_DEFAULT_AUTHOR_SET_PREFERENCE = "isDefaultAuthorSet";
    private Context context;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor preferencesEditor;
    public AuthorPreferences(Context context){
        this.context = context;
        sharedPreferences = context.getSharedPreferences("authors", context.MODE_PRIVATE);
        adDefaultAuthor();
    }


    public Set<String> saveAuthorName(String authorName){
        preferencesEditor = sharedPreferences.edit();
        Set<String> authors = new HashSet<>();
        authors.addAll(sharedPreferences.getStringSet(context.getResources().getString(R.string.prefkey_authors), new HashSet<String>(0)));
        Log.i("performSearch", "authorsSet size on load from prefs: " + authors.size());
        authors.add(authorName);
        preferencesEditor.putStringSet(context.getResources().getString(R.string.prefkey_authors), authors);
        preferencesEditor.apply();
        return authors;
    }

    public String[] getAuthors(){
        Set<String> authorsSet = sharedPreferences.getStringSet(context.getResources().getString(R.string.prefkey_authors), new HashSet<String>(0));
        return authorsSet.toArray(new String[authorsSet.size()]);
    }

    public void removeAuthorName(String authorName){
        preferencesEditor = sharedPreferences.edit();
        Set<String> authors = new HashSet<>();
        authors.addAll(sharedPreferences.getStringSet(context.getResources().getString(R.string.prefkey_authors), new HashSet<String>(0)));
        authors.remove(authorName);
        preferencesEditor.putStringSet(context.getResources().getString(R.string.prefkey_authors), authors);
        preferencesEditor.apply();
    }

    private void adDefaultAuthor(){
        boolean isDefaultAuthorSet = sharedPreferences.getBoolean(IS_DEFAULT_AUTHOR_SET_PREFERENCE, false);
        if(!isDefaultAuthorSet){
            preferencesEditor = sharedPreferences.edit();
            saveAuthorName(context.getResources().getString(R.string.default_author_name));
            preferencesEditor.putBoolean(IS_DEFAULT_AUTHOR_SET_PREFERENCE, true);
            preferencesEditor.apply();
        }
    }
}
