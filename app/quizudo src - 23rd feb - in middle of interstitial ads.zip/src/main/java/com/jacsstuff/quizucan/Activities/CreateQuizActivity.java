package com.jacsstuff.quizucan.Activities;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import com.jacsstuff.quiz.Question;
import com.jacsstuff.quizucan.DefaultQuestionLoader;
import com.jacsstuff.quizucan.LoadingDialog;
import com.jacsstuff.quizucan.model.QuestionResultsSingleton;
import com.jacsstuff.quizucan.model.QuizSingleton;
import com.jacsstuff.quizucan.list.QuestionPackList;
import com.jacsstuff.quizucan.manager.QuestionPackDBManager;
import com.jacsstuff.quizucan.model.QuestionPackSingleton;
import com.jacsstuff.quizucan.R;
import com.jacsstuff.quizucan.manager.QuestionPackManager;

import java.util.List;

public class CreateQuizActivity extends AppCompatActivity {

    private QuestionPackManager questionPackManager;
    private QuestionPackList questionPackList;
    private  Context context;
    private LoadingDialog loadingDialog;
    private boolean isDbInitFinished = true;
    //private final String LIST_SELECTED_STATE ="list_selected_state";
    //private int[] previouslySelectedIds;
   // private boolean retrieved = false; //whether the questionPackList has been retrieved from the singleton

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        log("Entered onCreate()");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_quiz);
        context = CreateQuizActivity.this;

        setupToolbar();
        loadingDialog = new LoadingDialog(context, R.string.loading_questions);
        // N.B Questions are loaded in the onResume() method
    }

    private void log(String msg){
        Log.i("CreateQuizActivity", msg);
    }

    @Override
    protected void onSaveInstanceState(Bundle state){
        super.onSaveInstanceState(state);
        //ListViewSingleton listViewSingleton = ListViewSingleton.getInstance();
        //listViewSingleton.setQuestionPackList(questionPackList);
       // state.putIntArray();
       // state.putIntArray(LIST_SELECTED_STATE, questionPackList.getSelectedIdsArray());
    }
    @Override
    protected void onRestoreInstanceState(Bundle state){
        super.onRestoreInstanceState(state);
       // previouslySelectedIds = state.getIntArray(LIST_SELECTED_STATE);
    }



    @Override
    protected void onDestroy(){
        questionPackManager.closeConnections();
        super.onDestroy();
    }
    protected void onResume(){
        super.onResume();
        loadQuestions("onResume()");
    }

    private void setupViews(){
        questionPackList = new QuestionPackList(context, this);
        questionPackList.setListView(R.id.listView);
        questionPackList.setTextView(R.id.no_question_packs_found_text);
        questionPackList.setButtonView(R.id.configureQuizButton);
        questionPackList.setButtonOnClick(new View.OnClickListener(){
            public void onClick(View view){
                new QuizFileLoader().execute("");
            }
        });
        questionPackList.initializeList(questionPackManager.getQuestionPackDetails());

    }

    private void loadQuestions(String callerId) {
        if (isDbInitFinished) {
            isDbInitFinished = false;
            loadingDialog.show();
            DBInitialiser initialiser = new DBInitialiser();
            initialiser.execute(callerId);
        }
    }

    private void setupToolbar() {
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayOptions(ActionBar.DISPLAY_HOME_AS_UP | ActionBar.DISPLAY_SHOW_TITLE);
        }
    }

    private class DBInitialiser extends AsyncTask<String, String, Integer>{

        public Integer doInBackground(String... params){
            //String callerId = params[0];

            DefaultQuestionLoader defaultQuestionLoader = new DefaultQuestionLoader(context);
            defaultQuestionLoader.loadQuestions();
            questionPackManager = new QuestionPackDBManager(context);

            return 1;
        }

        public void onPostExecute(Integer value){
            loadingDialog.dismiss();
            setupViews();
            isDbInitFinished = true;
        }

    }

    private void printSelectedIds(){

        StringBuilder ids = new StringBuilder("Selected Ids are: ");
        for(int id : questionPackList.getSelectedIds()){
            ids.append(id);
            ids.append(" ");
        }
        log(ids.toString());

    }

    private class QuizFileLoader extends AsyncTask<String, String, Integer> {


        QuestionPackSingleton questionPackSingleton = QuestionPackSingleton.getInstance();
        public Integer doInBackground(String... params){

            questionPackSingleton.reset();
            log("number of questions in singleton after reset:" + questionPackSingleton.getNumberOfQuestions());
            printSelectedIds();
            List<Question> questions = questionPackManager.getQuestions(questionPackList.getSelectedIds());
            questionPackSingleton.addNewQuestions(questions);
            QuizSingleton quizSingleton = QuizSingleton.getInstance();
            quizSingleton.killRunningQuiz(); // If we're starting a new quiz, we dont want to give the opportunity of resuming a previous quiz
                                            // why not? We'd have to create another structure to hold the previous quiz questions, and swap them over.
                                            // Also what if somebody decides to delete or update the questions of the running quiz?
                                            // As it stands, you cannot delete questions from the db and go back to the 'configure quiz' screen
                                            // without passing this activity, and basically wiping any old unfinished quiz away.

            QuestionResultsSingleton questionResultsSingleton = QuestionResultsSingleton.getInstance();
            questionResultsSingleton.resetResults(); // as well as removing the exisitng questions, we have to remove the previous results.

            if(questionPackSingleton.isEmpty()) {
                return 0;
            }
            return 1;
        }

        public void onPostExecute(Integer value){
            configureQuizActivity();
        }


/*
        private void addDefaultQuestionPack() {
            QuestionPack defaultQuestionPack = new QuestionPack("default questions");
            defaultQuestionPack.setDescription("A selection of random questions");
            defaultQuestionPack.addTopic("General Knowledge");
            for (Question question : new DummyQuestionLoaderImpl().loadQuestions()) {
                defaultQuestionPack.addQuestion(question);
            }
            questionPackSingleton.addDefaultQuestionPack(defaultQuestionPack);
        }*/
    }



    public void configureQuizActivity(){

        Intent intent = new Intent(this, ConfigureQuizActivity.class);
        startActivity(intent);
    }


}