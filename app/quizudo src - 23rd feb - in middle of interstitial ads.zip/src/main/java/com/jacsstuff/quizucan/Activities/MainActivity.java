package com.jacsstuff.quizucan.Activities;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.jacsstuff.quizucan.controller.MainController;
import com.jacsstuff.quizucan.R;
import com.jacsstuff.quizucan.list.MenuListView;


public class MainActivity extends AppCompatActivity  {

    private MainController controller;
    private Context context;
    public final int CREATE_QUIZ_BUTTON_ID = 1001;
    public final int MANAGE_QUESTIONS_BUTTON_ID = 1002;
    //private final int TEST_DEFAULT_QUESTIONS_RESET = 1004;
    //private final int TEST_DIALOG_ID = 1003;
    private InterstitialAd mInterstitialAd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = MainActivity.this;
        setupToolbar();
        controller = new MainController(this, context);
        setupMenuList();
        setupBannerAd();
    }

    private void setupBannerAd(){
        AdView ad = (AdView) findViewById(R.id.adView);
        if(ad != null) {
            ad.loadAd(new AdRequest.Builder().build());
        }
    }

    private void setupToolbar(){
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
    }

    private void setupInterstitialAd(){
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId("ca-app-pub-3940256099942544/1033173712");

        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                requestNewInterstitial();
                controller.newQuiz();
            }
        });
        requestNewInterstitial();
    }


    private void requestNewInterstitial() {
        AdRequest adRequest = new AdRequest.Builder()
                .addTestDevice("SEE_YOUR_LOGCAT_TO_GET_YOUR_DEVICE_ID")
                .build();

        mInterstitialAd.loadAd(adRequest);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_activity_menu, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if(id == R.id.about_menu_item) {
            Intent intent = new Intent(this, AboutAppActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    private void setupMenuList(){
        Resources r = getResources();
        MenuListView menuListView = new MenuListView(findViewById(R.id.listView), context, controller);
        menuListView.addItem(CREATE_QUIZ_BUTTON_ID,      r.getString(R.string.main_activity_start_quiz_button));
        menuListView.addItem(MANAGE_QUESTIONS_BUTTON_ID, r.getString(R.string.manage_questions_button_text));
        menuListView.init();
    }
}
