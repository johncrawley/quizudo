package com.jacsstuff.quizucan;

import android.util.Log;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by John on 03/11/2016.
 *
 * Utils used in various classes for various purposes. What a description!
 */
public class Utils {

    public static final String HTTP_PREFIX = "http://";
    public static final String GET_LIST_OF_FILES_REQUEST = "/listAvailableFiles.php";
    public static final String QUESTION_PACK_REQUEST = "/getQuizPacks.php";
    public static final String QUIZ_SITE_TEST_REQUEST = "/test.php";
    public static final String AUTHOR_NAME_PARAM = "userId";
    public static final String QUIZ_PACK_NAMES_PARAM = "names";
    public static final String PARAMS_START = "?";
    public static final String PARAM_EQUALS = "=";
    public static final String PARAM_DELIMITER = "&";
    public static final String QUIZ_SITE_TEST_EXPECTED_RESPOSE = "quizquiz!";
    public static final String USER_NOT_FOUND_RESPONSE = "[User Not Found]";
    public static final String NO_QUESTIONS_FOUND_RESPONSE = "[No Questions Found]";
    public static final String RESPONSE_BRACKETS = "~~~";
    public static final String RESPONSE_PARSE_ERROR = "Response Parse Error.";
    public static final String FILENAME_EXTENSION = ".qzp";
    public static final String QUIZ_PACK_RESPONSE_DELIMITER = "%~~%";
    public static final String QUIZ_PACK_RESPONSE_NAME_IDENTIFIER = "id=";
    public static final String QUIZ_PACK_RESPONSE_DATA_DELIMITER = ",";
    public static final String AUTHOR_DELIMITER = "__";
    public static final int    LOADING_DIALOG_TIMEOUT = 7000;
    public static final String QUESTION_PACK_NAMES_INTENT_EXTRA = "questionPackNames";
    public static final String AUTHOR_NAME_INTENT_EXTRA = "authorName";
    public static final String QUESTION_PACK_REQUEST_DELIMITER = ",";
    public static final String NUMBER_OF_QUESTIONS_INTENT_EXTRA = "numberOfQuestions";
    public static final String DISPLAY_ANSWER_DIALOG_INTENT_EXTRA = "showAnswerDialog";
    public static final String SUBMIT_ANSWER_ON_TOUCH_INTENT_EXTRA = "submitAnswerOnTouch";
    public static final String QUIZ_SETTINGS_PREFERENCES = "quizSettings";

    public static final String ADD_QUESTIONS_PREFERENCE = "AddQuestionPacks";
    public static final String REMOVE_QUESTIONS_PREFERENCE = "RemoveQuestionPacks";
    public static final String CONFIGURE_DOWNLOAD_SITE_PREFERENCE = "ConfigureDownloadSite";
    public static final String PREVIOUS_NUMBER_OF_QUESTIONS_PREFERENCE = "previousNumberOfQuestions";
    public static final String PREVIOUS_SUBMIT_ANSWER_ON_TOUCH_PREFERENCE = "submitAnswerOnTouch";
    public static final String PREVIOUS_SHOW_ANSWER_PREFERENCE = "showAnswer";
    public static final String WERE_DEFAULT_QPS_ADDED_PREFERENCE = "wereDefaultQPsAdded";
    public static final int DEFAULT_NUMBER_OF_QUESTIONS = 10;

    public static final String IS_ANSWER_CORRECT_INTENT_EXTRA = "isAnswerCorrect";
    public static final String CORRECT_ANSWER_INTENT_EXTRA = "correctAnswer";
    public static final String TRIVIA_INTENT_EXTRA = "trivia";
    public static final String DEL_AUTHOR_NAME_INTENT_EXTRA = "deleteAuthorName";


    public static boolean withinBounds(String str, int index) {
        return index > -1 && index < str.length();
    }


    public static String getMessageBody(String response) {
        String messageBody;
        int startIndex = response.indexOf(RESPONSE_BRACKETS) + RESPONSE_BRACKETS.length();
        int endIndex = response.lastIndexOf(RESPONSE_BRACKETS);
        Log.i("Utils", "response  body: " + response);
        if (startIndex > 0 && endIndex > 0 && startIndex < endIndex) {
            messageBody = response.substring(startIndex, endIndex);
        } else {
            messageBody = RESPONSE_PARSE_ERROR;
        }
        return messageBody;
    }


    public static Map<String, String> getDataFromResponse(String response){

        Map <String, String> dataList = new HashMap<>();

        String [] dataArray = response.split(QUIZ_PACK_RESPONSE_DELIMITER);

        for(String dataChunk : dataArray){
            int delimiterIndex = dataChunk.indexOf(QUIZ_PACK_RESPONSE_DATA_DELIMITER);
            int nameIdentifierEndIndex = dataChunk.indexOf(QUIZ_PACK_RESPONSE_NAME_IDENTIFIER) + QUIZ_PACK_RESPONSE_NAME_IDENTIFIER.length();

            boolean areIndexesWithinBounds = Utils.withinBounds(dataChunk, delimiterIndex) && Utils.withinBounds(dataChunk, nameIdentifierEndIndex);
            if(areIndexesWithinBounds){

                String name =  dataChunk.substring(nameIdentifierEndIndex, delimiterIndex);
                String data = dataChunk.substring(delimiterIndex + 1);
                dataList.put(name,data);
            }
        }

        return dataList;
    }


}