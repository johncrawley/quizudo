package com.jacsstuff.quizucan.model;

import com.jacsstuff.quiz.Question;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by John on 24/06/2016.
 */
public class QuestionResult {

    private List<String>providedAnswers;
    private List<String> correctAnswers;
    private List<String> incorrectChosenAnswers;
    private boolean wasAnsweredCorrectly;
    private int questionNumber;
    private String questionText;

    public QuestionResult(Question question, int questionNumber, List<String> chosenAnswers){

        this.incorrectChosenAnswers = new ArrayList<>();
        this.correctAnswers = question.getCorrectAnswers();
        this.questionNumber = questionNumber;
        this.questionText = question.getQuestionText();
        this.providedAnswers = chosenAnswers;
        this.wasAnsweredCorrectly = isAnswerCorrect(chosenAnswers);
    }


    private boolean isAnswerCorrect(List<String> chosenAnswers){

        int correctAnswerCount = 0;
        boolean isAnswerCorrect = true;

        for(String chosenAnswer: chosenAnswers){
           if(this.correctAnswers.contains(chosenAnswer)){
                    correctAnswerCount++;
           }
           // incorrect answer chosen
            else {
               this.incorrectChosenAnswers.add(chosenAnswer);
               isAnswerCorrect = false;
           }
        }
        //not all the correct answers were selected
        if(correctAnswerCount != this.correctAnswers.size()){
            isAnswerCorrect = false;
        }
        return isAnswerCorrect;
    }


    public QuestionResult(int questionNumber, String questionText, List<String> providedAnswers){
        this.questionNumber = questionNumber;
        this.questionText = questionText;
        this.providedAnswers = new ArrayList<>(providedAnswers);

        // assuming a correct answer by default
        this.wasAnsweredCorrectly = true;
    }

    public void setQuestionNumber(int number){
        this.questionNumber = number;
    }


    public String getResultAsString(){
        String wasCorrect = "Correct";
        if(!this.wasAnsweredCorrectly){
            wasCorrect = "Incorrect";
        }
        return (this.questionNumber + 1) + " " + this.questionText + " \n " + wasCorrect;
    }

    //some of the answers supplied may be correct, but if only 1 is incorrect
    // then the overall answer is incorrect.
    public void setIncorrectResult(List <String> correctAnswers, List <String> incorrectAnswers){
        this.wasAnsweredCorrectly = false;
        this.correctAnswers = new ArrayList<>(correctAnswers);
        this.incorrectChosenAnswers = new ArrayList<>(incorrectAnswers);
    }

    public int getQuestionNumber() {
        return questionNumber;
    }

    public String getQuestionResultText(){
        return (this.getQuestionNumber() + 1) + ". "  + this.getQuestionText();
    }

    public String getQuestionText() {
        return questionText;
    }

    public List<String> getCorrectAnswers() {
        return correctAnswers;
    }

    public List<String> getIncorrectAnswers() {
        return incorrectChosenAnswers;
    }

    public boolean wasAnsweredCorrectly() {
        return wasAnsweredCorrectly;
    }



}
