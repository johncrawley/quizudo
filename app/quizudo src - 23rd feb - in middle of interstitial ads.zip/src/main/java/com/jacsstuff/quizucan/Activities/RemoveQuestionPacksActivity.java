package com.jacsstuff.quizucan.Activities;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.jacsstuff.quizucan.list.QuestionPackList;
import com.jacsstuff.quizucan.manager.QuestionPackDBManager;
import com.jacsstuff.quizucan.R;
import com.jacsstuff.quizucan.Utils;
import com.jacsstuff.quizucan.manager.QuestionPackManager;

public class RemoveQuestionPacksActivity extends AppCompatActivity{

    private Context context;
    private QuestionPackManager questionPackManager;
    private QuestionPackList questionPackList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remove_question_packs);
        context = RemoveQuestionPacksActivity.this;
        setupToolbar();
        setupViews();
        questionPackManager = new QuestionPackDBManager(context);
        initializeList();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home_enabled_menu, menu);
        return true;
    }


    @Override
    protected void onDestroy(){
        questionPackManager.closeConnections();
        super.onDestroy();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if(id == R.id.home_menu_item) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    private void setupToolbar() {
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayOptions(ActionBar.DISPLAY_HOME_AS_UP | ActionBar.DISPLAY_SHOW_TITLE);
        }
    }
    private void setupViews() {
        questionPackList = new QuestionPackList(context, this);
        questionPackList.setButtonView(R.id.delete_question_packs_button);
        questionPackList.setTextView(R.id.no_question_packs_found_text);
        questionPackList.setListView(R.id.listView);
        questionPackList.setButtonOnClick(new View.OnClickListener(){
            public void onClick(View view){
                new QuizFileDeleter().execute("");
            }
        });
    }

    private void initializeList(){
        questionPackList.initializeList(questionPackManager.getQuestionPackDetails());
    }

    private class QuizFileDeleter extends AsyncTask<String, String, Integer> {

        String deleteMessage = "";

        public Integer doInBackground(String... params){

            int deletedFilesCount = questionPackManager.deleteQuestionPacks(questionPackList.getSelectedIds());
            if(deletedFilesCount > 1){
                deleteMessage = getResources().getString(R.string.files_deleted, deletedFilesCount);
            }
            else{
                deleteMessage = getResources().getString(R.string.file_deleted);
            }
            return 1;
        }

        public void onPostExecute(Integer value){
            initializeList();
            questionPackList.disableButton();
            Toast.makeText(context, deleteMessage, Toast.LENGTH_SHORT).show();
        }
    }

}

