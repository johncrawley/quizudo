package com.jacsstuff.quizucan.manager;

import android.content.Context;

import com.jacsstuff.quiz.Question;
import com.jacsstuff.quiz.QuestionPack;
import com.jacsstuff.quizucan.QuestionPackDetail;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by John on 31/12/2016.
 *
 *  Takes care of managing the the db connection for loading and saving question packs
 *  Also contains a detailed list of question packs available
 * TODO: what happens if a user downloads the same question pack again
 *   delete existing and overwrite?
 *   still need to implement delete code.
 */
public class QuestionPackDBManager implements QuestionPackManager {

    DBWriter dbWriter;
    private Map<Integer, QuestionPackDetail> questionPacks;


    public QuestionPackDBManager(Context context){
        questionPacks = new HashMap<>();
        dbWriter = new DBWriter(context);
    }

    public int saveQuestionPacks(Map<String, String> dataChunks, String authorName){

        for(String key: dataChunks.keySet()){
            dbWriter.addQuestionPack(dataChunks.get(key));
        }
        return 0;
    }

    public List<QuestionPackDetail> getQuestionPackDetails() {
        this.questionPacks = dbWriter.getQuestionPackDetails();
        List<QuestionPackDetail> qpDetailList = new ArrayList<>();
        for (int key : questionPacks.keySet()){
            qpDetailList.add(questionPacks.get(key));
        }
        return qpDetailList;
    }

    public int deleteQuestionPacks(Set<Integer> ids){
        return 0;
    }

    public List <QuestionPack> getQuestionPacks(Set<Integer> ids){
        return null;
    }
    public List <Question> getQuestions(Set<Integer> ids){

        Set <Long> questionPackRowIdList= new HashSet<>();

        for( int key : ids){
            questionPackRowIdList.add(questionPacks.get(key).getId());
        }
       return dbWriter.getQuestions(questionPackRowIdList);
    }

    public boolean isEmpty(){
        return true;
    }

}
