package com.jacsstuff.quizucan.Activities;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import com.jacsstuff.quiz.Question;
import com.jacsstuff.quiz.QuestionPack;
import com.jacsstuff.quizucan.DummyQuestionLoaderImpl;
import com.jacsstuff.quizucan.list.QuestionPackList;
import com.jacsstuff.quizucan.manager.QuestionPackDBManager;
import com.jacsstuff.quizucan.manager.QuestionPackFileManager;
import com.jacsstuff.quizucan.QuestionPackSingleton;
import com.jacsstuff.quizucan.R;
import com.jacsstuff.quizucan.manager.QuestionPackManager;

import java.util.List;

public class CreateQuizActivity extends AppCompatActivity {

    private QuestionPackManager questionPackManager;
    private QuestionPackList questionPackList;
    private  Context context;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_quiz);
        context = CreateQuizActivity.this;

        setupToolbar();
        //questionPackManager = new QuestionPackFileManager(context);
        questionPackManager = new QuestionPackDBManager(context);
        setupViews();

    }

    private void setupViews(){
        questionPackList = new QuestionPackList(context, this);
        questionPackList.setListView(R.id.listView);
        questionPackList.setTextView(R.id.no_question_packs_found_text);
        questionPackList.setButtonView(R.id.configureQuizButton);
        questionPackList.setButtonOnClick(new View.OnClickListener(){
            public void onClick(View view){
                new QuizFileLoader().execute("");
            }
        });
        questionPackList.initializeList(questionPackManager.getQuestionPackDetails());
    }


    private void setupToolbar() {
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayOptions(ActionBar.DISPLAY_HOME_AS_UP | ActionBar.DISPLAY_SHOW_TITLE);
        }
    }

    private class QuizFileLoader extends AsyncTask<String, String, Integer> {


        public Integer doInBackground(String... params){

            QuestionPackSingleton questionPackSingleton = QuestionPackSingleton.getInstance();
            questionPackSingleton.reset();

           // List<QuestionPack> questionPacks = questionPackManager.getQuestionPacks(questionPackList.getSelectedIds());
            //questionPackSingleton.add(questionPacks);
            List<Question> questions = questionPackManager.getQuestions(questionPackList.getSelectedIds());
            questionPackSingleton.addQuestions(questions);

            if(questionPackSingleton.isEmpty()) {
                QuestionPack defaultQuestionPack = new QuestionPack("default questions");
                defaultQuestionPack.setDescription("A selection of random questions");
                defaultQuestionPack.addTopic("General Knowledge");
                for(Question question : new DummyQuestionLoaderImpl().loadQuestions()){
                    defaultQuestionPack.addQuestion(question);
                }
                questionPackSingleton.addDefaultQuestionPack(defaultQuestionPack);
            }
            return 1;
        }

        public void onPostExecute(Integer value){
            configureQuizActivity();
        }

    }



    public void configureQuizActivity(){

        Intent intent = new Intent(this, ConfigureQuizActivity.class);
        startActivity(intent);
    }


}