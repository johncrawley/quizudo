package com.jacsstuff.quizucan.manager;

/**
 * Created by John on 07/01/2017.
 *
 QuestionDBDetail
 question
 topics
 QuestionPackID -- this isn't required, as the reference to the QP key in the db is only created once the QP has been added to the DB
                    and by that time the data for this object has already been parsed.
 */
public class QuestionDBDetail {

    private String question; // contains the JSON for the Question object
    private String topics; // contains the topics for the question, comma separated value of topics, doesn't matter as the db search will take care of finding topics from questions.
    private String flags; // attempt at future proofing - may contain a list of key value pairs, that would be parsed out at a later date.

    public QuestionDBDetail(String question, String topics, String flags){
        this.question = question;
        this.topics = topics;
        this.flags = flags;
    }

    public String getQuestion(){
        return this.question;
    }

    public String getTopics(){
        return this.topics;
    }
    public String getFlags(){
        return this.flags;
    }

    public void setFlags(String flags){
        this.flags = flags;
    }
}
