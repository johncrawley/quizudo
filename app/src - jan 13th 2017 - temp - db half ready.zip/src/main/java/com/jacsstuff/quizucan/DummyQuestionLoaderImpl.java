package com.jacsstuff.quizucan;

import android.util.Log;

import com.jacsstuff.quiz.Question;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by John on 27/06/2016.
 */
public class DummyQuestionLoaderImpl {

    String [] questionTexts = {"What is the capital of France?",
                                " In what year did the first Moon Landing take place?",
                                " What is the longest river in the world?",
                                " Who filed the first full patent for the electric telephone?",
                                " For what work was Alfred Einstein awarded the 1921 Nobel Prize in Physics?",
                                " What is the third tallest mountain in the world?",
                                " How many oscars has Al Pacino won?",
                                " Who invented the electric guitar?",
                                " How many Number 1 hits did the Beatles have in the US and the UK?",
                                " What year was John F. Kennedy assassinated?",
                                " What is the name of the biggest lake in the world?",
                                " What medical discovery is Alexander Fleming best known for?",
                                " Who was the first man in space?",
                                " Who is acknowledged as the first person to break the 4 minute mile?",
                                " Who directed The Shawshank Redemption?",
                                " Who was the first person to isolate DNA from a cell?",
                                " Who was in charge of the first expedition to reach the South Pole?",
                                " In what year did the First World War end?",
                                " Which living bird has the largest wingspan?"};


    String [] answerCorrectChoices = {"Paris", "1969","The Nile","Alexander Graham Bell", "The Photo Electric Effect",
                                    "Kangchenjunga", "One", "George Beauchamp and Adolph Rickenbacker",
                                    "27", "1963", "The Caspian Sea", "Penicillin", "Yuri Gagarin", "Roger Bannister", "Frank Darabont",
                                    "Friedrich Miescher", "Roald Amundsen", "1918", "Wandering Albatross"};


    String[] incorrectAnswers = {"Lyon", "Marsailles", "Bordeaux", "St Etienne",
                                 "1968", "1967", "1963", "1965",
                                 "The Amazon", "The Ganges", "The Thames", "The Oronoco",
                                 "Guglielmo Marconi", "Thomas Edison", "Antonio Meucci", "Johann Philipp Reis",
                                 "The General Theory of Relativity", "The Special Theory of Relativity", "Quantum field Theory", "Theory of Critical Opalescence",
                                 " Lhotse", "Mount Rainier", "Aconcagua", "Annapurna I",
                                 "Zero", "Two", "Three", "Four",
                                 "Les Paul", "Leo Fender", "Elvis Presley", "Orville Gibson",
                                 "23", "18", "29", "30",
                                 "1966", "1962", "1965", "1964",
                                 "The Red Sea", "Lake Superior", "Lake Victoria", "Lake Michigan",
                                 "Smallpox vaccination", "Anesthetic", "Cure for Foot and Mouth Disease", "Insulin",
                                 "Chuck Yaeger", "Buzz Aldrin", "John Glenn Jr", "Oleg Makarov",
                                 "Larry Shields", "Albert Hill", "Joe Falcon", "Sebastian Coe",
                                 "Steven Spielberg", "Jonathan Demme", "Ron Howard", "Tony Scott",
                                 "James Watson", "Martha Chase", "Frederick Griffith", "John Hammond",
                                 "Robert Scott", "Ernest Shackleton", "Tom Creane", "Edmund Hillary",
                                 "1919","1921","1920","1916",
                                 "Bald Eagle", "African Martial Eagle", "Andean condor", "Great White Pelican"};


    private final String GENERAL_KNOWLEDGE = "General Knowledge";


    public List<Question> loadQuestions(){
        String test = "";
        int incorrectAnswerIndex = 0;
        int correctAnswerIndex = 0;

        List<Question> questions = new ArrayList<>(20);
        List <String> topics = new ArrayList<>(1);
        topics.add(GENERAL_KNOWLEDGE);

        for(String questionText : this.questionTexts){

            List<String> correctAnswerList = new ArrayList(1);
            if(correctAnswerIndex < this.answerCorrectChoices.length) {
                correctAnswerList.add(this.answerCorrectChoices[correctAnswerIndex]);
                correctAnswerIndex++;
            }
            List<String> incorrectAnswerList = new ArrayList(4);
            for(int i = 0; i< 4; i++){
                if(incorrectAnswerIndex < incorrectAnswers.length) {
                    String incorrectAnswer = this.incorrectAnswers[incorrectAnswerIndex];
                    incorrectAnswerList.add(incorrectAnswer);
                    incorrectAnswerIndex++;
                }
            }
            Log.i("quiz dummy loader", "*********************************************");

            Log.i("quiz dummy loader", "correctAnswer: " + correctAnswerList.get(0));
            for(String i: incorrectAnswerList){
                Log.i("quiz dummy loader", "inCorrectAnswer: " + i);
            }
            questions.add(new Question(questionText, incorrectAnswerList,correctAnswerList, topics));
        }
        return questions;
    }
}
