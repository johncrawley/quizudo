package com.jacsstuff.quizucan.manager;

import android.provider.BaseColumns;

/**
 * Created by John on 31/12/2016.
 *
 * Contains the names and row names of the tables that hold data for the QuestionPack and Question entries.
 */
public final class DbContract {

    private DbContract(){}

    public static class QuestionsEntry implements BaseColumns {
        public static final String TABLE_NAME = "questions";
        public static final String COLUMN_NAME_QUESTION = "question";
        public static final String COLUMN_NAME_QUESTION_PACK_ID = "question_pack_id";
        public static final String COLUMN_NAME_TOPICS = "topics";
        public static final String COLUMN_NAME_FLAGS = "flags";
    }

    public static class QuestionPackEntry implements BaseColumns {
        public static final String TABLE_NAME = "question_packs";
        public static final String COLUMN_NAME_UNIQUE_NAME = "unique_name";
        public static final String COLUMN_NAME_DESCRIPTION = "description";
        public static final String COLUMN_NAME_TITLE = "title";
        public static final String COLUMN_NAME_AUTHOR = "author";
        public static final String COLUMN_NAME_VERSION = "version";
        public static final String COLUMN_NAME_DATE_CREATED = "date_created";
        public static final String COLUMN_NAME_DATE_DOWNLOADED = "date_downloaded";
    }
/*

    Scenarios
        Nevermind how we save the data, how do we load question packs?
        First of all, the questions added to the pool for a quiz will be based on the
        criteria we select from a list.

        There will be a number of different lists available to select from.
        For 1st release, we'll stick to just question packs but we need to keep the door open for others.
        Examples:

        Select all questions from authors...
        Select all question from question packs...
        Select all questions with these topics...

        When populating such lists, do we need a separate table for each criteria?
            E.g. question_pack table, topics table, authors table?

        The problem with having a new table for each criterion is that every time a question pack is removed,
        we have to check to see whether the table record for all topics, authors should exist

        We should still need a table for question packs however.

        -----------------------
        Sorting based on author
        -----------------------

        If we associate a question pack with an author, then we shouldn't associate a question with an author (or does it matter?)
        read up on normal forms

        If author is stored in quesiton_packs table, selecting questions based on author is like:
        select question from questions
         where question.question_pack_id = question_packs.id and question_packs.name = [author_name]

 */


}
