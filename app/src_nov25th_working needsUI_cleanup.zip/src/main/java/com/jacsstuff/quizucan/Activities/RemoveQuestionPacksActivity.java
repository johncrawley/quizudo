package com.jacsstuff.quizucan.Activities;

import android.content.Context;
import android.os.AsyncTask;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.ListView;
import android.widget.TextView;

import com.jacsstuff.quizucan.FileSet;
import com.jacsstuff.quizucan.R;
import com.jacsstuff.quizucan.Utils;

public class RemoveQuestionPacksActivity extends AppCompatActivity implements View.OnClickListener {

    Button deleteSelectedQuestionPacksButton;
    ListView questionPackList;
    Context context;
    FileSet fileSet;
    TextView noQuestionPacksFoundText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remove_question_packs);

        context = RemoveQuestionPacksActivity.this;

        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_HOME_AS_UP | ActionBar.DISPLAY_SHOW_TITLE );

        noQuestionPacksFoundText = (TextView)findViewById(R.id.no_question_packs_found_text);
        questionPackList = (ListView) findViewById(R.id.listView);
        deleteSelectedQuestionPacksButton = (Button) findViewById(R.id.delete_question_packs_button);
        deleteSelectedQuestionPacksButton.setOnClickListener(this);
        initializeList();
    }


    public void onClick(View view) {
        if (view.getId() == R.id.delete_question_packs_button) {
            fileSet.getSelectedFiles();
            new QuizFileDeleter().execute("");
        }
    }

    private class QuizFileDeleter extends AsyncTask<String, String, Integer> {

        String deleteMessage = "";

        public Integer doInBackground(String... params){

            deleteMessage = Utils.deleteSelectedFiles(context, fileSet);
            return 1;
        }

        public void onPostExecute(Integer value){
            initializeList();
            Utils.makeToast(context, deleteMessage);
        }
    }


    public void initializeList(){

        // this variable has to beset to final because it is accessed from within an inner class.
        final FileSet finalFileSet = new FileSet(context, Utils.getStoredQuizFiles(context));
        this.fileSet = finalFileSet;

        if(this.fileSet.size() != 0){
            this.noQuestionPacksFoundText.setVisibility(View.GONE);
        }
        else{
            questionPackList.setVisibility(View.GONE);
            deleteSelectedQuestionPacksButton.setVisibility(View.GONE);
        }
        Utils.configureMultipleChoiceList(context, questionPackList, finalFileSet.getDisplayNames());
        questionPackList.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){
                CheckedTextView item = (CheckedTextView)view;
                boolean checked = item.isChecked();
                finalFileSet.setSelected(position,checked);
            }
        });

    }

}
