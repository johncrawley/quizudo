package com.jacsstuff.quizucan.Activities;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.jacsstuff.quizucan.controller.QuizResultsController;
import com.jacsstuff.quizucan.R;

public class QuizResultsActivity extends AppCompatActivity implements View.OnClickListener {

    Button mainMenuButton;
    TextView quizResultsMessage;
    ListView quizResultsList;
    QuizResultsController quizResultsController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_results);

        mainMenuButton = (Button)findViewById(R.id.main_menu_button);
        mainMenuButton.setOnClickListener(this);


        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_HOME_AS_UP | ActionBar.DISPLAY_SHOW_TITLE );

        quizResultsMessage = (TextView)findViewById(R.id.quiz_results_message);
        quizResultsList = (ListView)findViewById(R.id.quiz_results_list);

        quizResultsController = new QuizResultsController(QuizResultsActivity.this, quizResultsMessage, quizResultsList, mainMenuButton);

    }

    @Override
    /*
    public void onBackPressed() {
        Context context = QuizResultsActivity.this;
        Intent intent = new Intent(context, ConfigureQuizActivity.class);
        context.startActivity(intent);
    }*/

    public void onClick(View view){
        int id = view.getId();
        if(id == R.id.main_menu_button){
            quizResultsController.execute(view);
        }
    }
}
