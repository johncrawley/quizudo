package com.jacsstuff.quizucan.Activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebView;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.jacsstuff.quizucan.R;
import com.jacsstuff.quizucan.RequestManager;
import com.jacsstuff.quizucan.RequestType;
import com.jacsstuff.quizucan.Utils;
import com.jacsstuff.quizucan.WebViewFactory;

import java.util.HashSet;
import java.util.Set;

import static com.jacsstuff.quizucan.Utils.AUTHOR_NAME_INTENT_EXTRA;
import static com.jacsstuff.quizucan.Utils.NO_QUESTIONS_FOUND_RESPONSE;
import static com.jacsstuff.quizucan.Utils.RESPONSE_PARSE_ERROR;
import static com.jacsstuff.quizucan.Utils.USER_NOT_FOUND_RESPONSE;
import static com.jacsstuff.quizucan.Utils.QUESTION_PACK_NAMES_INTENT_EXTRA;

public class SelectAuthorActivity extends AppCompatActivity {

    Context context;
    private Set<String> authorsSet;
    private ListView authorsList;
    private EditText authorInput;
    SharedPreferences sharedPref;
    RequestManager requestManager;

    WebView webView;
    protected boolean isResponseGood;
    protected String [] questionPackNames;
    protected boolean saveAuthorToPreferences;
    protected String selectedAuthorName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_author);
        context = SelectAuthorActivity.this;
        setupToolbar();
        this.isResponseGood = false;

        authorsList = (ListView)findViewById(R.id.listView);
        authorInput = (EditText)findViewById(R.id.editText);
        authorInput.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(authorInput.getWindowToken(), 0);
                    String authorName = v.getText().toString().trim();
                    boolean dontSaveNameToPrefs = false;
                    getAuthorsQuestionPacks(authorName, dontSaveNameToPrefs);
                    return true;
                }
                return false;
            }
        });

        requestManager = new RequestManager(context);
        sharedPref = getPreferences(Context.MODE_PRIVATE);
        authorsSet = sharedPref.getStringSet(getResources().getString(R.string.prefkey_authors), new HashSet<String>(0));

        final String [] authorsArray = authorsSet.toArray(new String[authorsSet.size()]);
        authorsList.setChoiceMode(AbsListView.CHOICE_MODE_SINGLE);
        authorsList.setAdapter(new ArrayAdapter<String>(context, android.R.layout.simple_list_item_1, authorsArray));
        authorsList.setSelector(R.color.selectedListItemHidden);

        authorsList.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){
                boolean saveNameToPrefs = true;
                getAuthorsQuestionPacks(authorsArray[position], saveNameToPrefs);
            }
        });
    }


    private void setupToolbar(){
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_HOME_AS_UP | ActionBar.DISPLAY_SHOW_TITLE );
    }

    private void getAuthorsQuestionPacks(String authorName, boolean isAuthorSelectedFromList){

        if(authorName.equals("")){
            return;
        }
        this.selectedAuthorName = authorName;
        webView = WebViewFactory.getWebview(context, new HttpGrabber());
        requestManager.setParameter(Utils.AUTHOR_NAME_PARAM, authorName);
        String requestUrl = requestManager.getUrl(RequestType.LIST_QUESTION_PACKS);
        Log.i("selectAuthor", "requestUrl:" + requestUrl);
        webView.loadUrl(requestUrl);
        this.saveAuthorToPreferences = isAuthorSelectedFromList;
   }


    private void saveAuthorName(String authorName){
        SharedPreferences.Editor preferencesEditor = sharedPref.edit();
        Set<String> authors = new HashSet<>();
        authors.addAll(sharedPref.getStringSet(getResources().getString(R.string.prefkey_authors), new HashSet<String>(0)));
        Log.i("performSearch", "authorsSet size on load from prefs: " + authors.size());
        authors.add(authorName);
        preferencesEditor.putStringSet(getResources().getString(R.string.prefkey_authors), authors);
        preferencesEditor.apply();
        authorsList.setAdapter(new ArrayAdapter<String>(context, android.R.layout.simple_list_item_1, authors.toArray(new String[authors.size()])));

    }


    private void startDownloadQuestionsActivity(){

        Intent intent = new Intent(context,DownloadQuestionPacksActivity.class);
        intent.putExtra(QUESTION_PACK_NAMES_INTENT_EXTRA, questionPackNames);
        intent.putExtra(AUTHOR_NAME_INTENT_EXTRA, this.selectedAuthorName);
        startActivity(intent);
    }


    private class HttpGrabber extends AsyncTask<String, String, Integer> {

        String response  = "";
        String toastMessage = "";

        public Integer doInBackground(String... params){

            questionPackNames = new String[0];
            response = Utils.getMessageBody(params[0]);

            if(response.equals(RESPONSE_PARSE_ERROR)){
                toastMessage = getResources().getString(R.string.server_error);
            }
            else if(response.contains(USER_NOT_FOUND_RESPONSE)){
                toastMessage = getResources().getString(R.string.user_not_found_message);
            }
            else if(response.contains(NO_QUESTIONS_FOUND_RESPONSE)){
                isResponseGood = true;
                toastMessage = getResources().getString(R.string.user_not_found_message);
            }
            else if(response.isEmpty()){
                toastMessage =  getResources().getString(R.string.server_error_message);;
            }
            else{
                Log.i("selectAuthor", " questionpacknames =" + response);
                isResponseGood = true;
                questionPackNames = response.split(",");
            }
            return 1;
        }


        public void onPostExecute(Integer value){

            if(!isResponseGood) {
                Utils.makeToast(context, toastMessage);
            }
            else{
                if(!saveAuthorToPreferences) {
                    saveAuthorName(selectedAuthorName);
                }
                startDownloadQuestionsActivity();
            }
        }

    }
}