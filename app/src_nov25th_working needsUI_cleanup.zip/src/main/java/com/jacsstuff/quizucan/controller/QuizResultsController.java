package com.jacsstuff.quizucan.controller;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.jacsstuff.quizucan.Activities.MainActivity;
import com.jacsstuff.quizucan.QuestionResult;
import com.jacsstuff.quizucan.QuestionResultsSingleton;
import com.jacsstuff.quizucan.R;
import com.jacsstuff.quizucan.ResultsMessageHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by John on 29/06/2016.
 */
public class QuizResultsController {

    Context context;

    QuestionResultsSingleton singletonResultsStore;
    List<QuestionResult> questionResults;
    String[] resultStringsArray;
    List <String> resultStringsList;
    ResultsMessageHelper resultsMessageHelper;

    public QuizResultsController(Context context, TextView quizResultsMessage, ListView quizResultsList, Button mainMenuButton){
        this.context = context;

        resultStringsList = new ArrayList<>();
        singletonResultsStore = QuestionResultsSingleton.getInstance();
        questionResults = singletonResultsStore.getResults();
        resultsMessageHelper = new ResultsMessageHelper();

        List<String> resultStrings = new ArrayList<>();
        for(QuestionResult result : questionResults){
            resultStringsList.add(result.getResultAsString());
        }
        resultStringsArray = resultStringsList.toArray(new String[resultStringsList.size()]);
        int correctAnswerCount = singletonResultsStore.getCorrectAnswerCount();
        int questionCount = questionResults.size();

        //String resultsStat = correctAnswerCount + "/" + questionCount + " ";
        String resultsStatistic = context.getResources().getString(R.string.quiz_results_score_message,correctAnswerCount,questionCount) + " ";
        boolean noQuestionsAnsweredCorrectly = correctAnswerCount == 0;
        boolean lessThanTwoQuestionsInQuiz = resultStringsList.size()<2;
        if(noQuestionsAnsweredCorrectly || lessThanTwoQuestionsInQuiz){
            resultsStatistic = "";
        }
        String resultsMessage = resultsStatistic + resultsMessageHelper.getResultMessage(correctAnswerCount, questionResults.size());

        quizResultsMessage.setText(resultsMessage);
       // quizResultsList.setAdapter(new ArrayAdapter<String>(context, android.R.layout.simple_list_item_1, resultStringsArray));
        quizResultsList.setAdapter(new com.jacsstuff.quizucan.ResultsListAdapter(context, R.layout.result_row, questionResults));
    }


    public void execute(View view){
        if(view.getId() == R.id.main_menu_button){
            Intent intent = new Intent(context, MainActivity.class);
            context.startActivity(intent);
        }
    }

}
