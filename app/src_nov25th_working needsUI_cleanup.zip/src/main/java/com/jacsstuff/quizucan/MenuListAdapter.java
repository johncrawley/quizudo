package com.jacsstuff.quizucan;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.Arrays;
import java.util.List;

/**
 * Created by John on 29/10/2016.
 */
public class MenuListAdapter extends ArrayAdapter<ListMenuItem> {

    Context context;
    List <ListMenuItem> items;
    int itemLayoutId;

    public MenuListAdapter(Context context,  int textViewResourceId, List<ListMenuItem> menuItemList){

        super(context, textViewResourceId, menuItemList);
        this.items = menuItemList;
        this.context = context;
        this.itemLayoutId = textViewResourceId;
    }



    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            LayoutInflater vi = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = vi.inflate(this.itemLayoutId, null);
           // view = vi.inflate(R.layout.menu_row, parent);
        }

        ListMenuItem item = items.get(position);
        TextView textView = (TextView)view.findViewById(R.id.text);
        textView.setText(item.getText());
        int id = item.getId();
        view.setTag(id);

        return view;
    }

}
