package com.jacsstuff.quizucan.manager;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;

/**
 * Created by John on 31/12/2016.
 */
public class QuestionPackDBHelper extends SQLiteOpenHelper {

    // If you change the database schema, you must increment the database version.
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "FeedReader.db";

    //"CREATE TABLE " + FeedEntry.TABLE_NAME + " (" +
    private static final String SQL_CREATE_QUESTION_ENTRIES =

            "CREATE TABLE IF NOT EXISTS " + DatabaseContract.QuestionsEntry.TABLE_NAME + " (" +
                    DatabaseContract.QuestionPackEntry._ID + " INTEGER PRIMARY KEY," +
                    DatabaseContract.QuestionsEntry.COLUMN_NAME_QUESTION_PACK_ID + " TEXT," +
                    DatabaseContract.QuestionsEntry.COLUMN_NAME_QUESTION + " TEXT," +
                    DatabaseContract.QuestionsEntry.COLUMN_NAME_TOPICS + " TEXT";

    private static final String SQL_CREATE_QUESTION_PACK_ENTRIES =
            "CREATE TABLE IF NOT EXISTS " + DatabaseContract.QuestionPackEntry.TABLE_NAME + " (" +
                    DatabaseContract.QuestionPackEntry._ID + " INTEGER PRIMARY KEY," +
                    DatabaseContract.QuestionPackEntry.COLUMN_NAME_AUTHOR + " TEXT," +
                    DatabaseContract.QuestionPackEntry.COLUMN_NAME_DATE_CREATED + " TEXT," +
                    DatabaseContract.QuestionPackEntry.COLUMN_NAME_DESCRIPTION + " TEXT," +
                    DatabaseContract.QuestionPackEntry.COLUMN_NAME_TITLE+ " TEXT";

    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + DatabaseContract.QuestionsEntry.TABLE_NAME;


    public QuestionPackDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_QUESTION_ENTRIES);
        db.execSQL(SQL_CREATE_QUESTION_PACK_ENTRIES);

    }
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
    }
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }




}
