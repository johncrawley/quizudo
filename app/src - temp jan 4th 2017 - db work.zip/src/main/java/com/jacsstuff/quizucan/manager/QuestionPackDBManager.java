package com.jacsstuff.quizucan.manager;

import android.content.Context;

import com.jacsstuff.quiz.QuestionPack;
import com.jacsstuff.quizucan.QuestionPackDetail;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by John on 31/12/2016.
 */
public class QuestionPackDBManager implements QuestionPackManager {

    DBWriter dbWriter;
    public QuestionPackDBManager(Context context){
        dbWriter = new DBWriter(context);
    }

    public int saveQuestionPacks(Map<String, String> dataChunks, String authorName){


        for(String key: dataChunks.keySet()){
            dbWriter.addQuestionPack(authorName, key,  dataChunks.get(key));
        }
        return 0;
    };

    public List<QuestionPackDetail> getQuestionPackDetails(){

        return new ArrayList<>();
    };

    public int deleteQuestionPacks(Set<Integer> ids){
        return 0;
    };

    public List <QuestionPack> getQuestionPacks(Set<Integer> ids){
        return new ArrayList<>();
    };

    public boolean isEmpty(){
        return true;
    }

}
