package com.jacsstuff.quizucan;

import com.jacsstuff.quiz.Question;
import com.jacsstuff.quiz.QuestionPack;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by John on 30/08/2016.
 *
 * Used for saving the Question Pack File objects chosen by the user, also saves the settings
 * in the 'configure quiz' activity for the next time a quiz is created.
 */
public class QuestionPackSingleton{

    private static QuestionPackSingleton instance;
    private List<QuestionPack> questionPacks;
    private int totalQuestions = 0;
    private boolean isUsingDefaultQuestionPack;

    private QuestionPackSingleton(){
        questionPacks = new ArrayList<>();
    }

    public static QuestionPackSingleton getInstance(){
        if(instance == null){
            instance = new QuestionPackSingleton();
        }
        return instance;
    }

    public void reset(){
        questionPacks = new ArrayList<>();
        totalQuestions = 0;
    }

    public void add(QuestionPack questionPack){
        this.questionPacks.add(questionPack);
        totalQuestions += questionPack.getQuestions().size();
        this.isUsingDefaultQuestionPack = false;
    }

    public void add(List<QuestionPack> questionPacks){
        this.questionPacks.addAll(questionPacks);
        for(QuestionPack qp: questionPacks) {
            totalQuestions += qp.getQuestions().size();
        }
        this.isUsingDefaultQuestionPack = false;
    }

    public void addDefaultQuestionPack(QuestionPack questionPack){
        this.questionPacks.add(questionPack);
        totalQuestions += questionPack.getQuestions().size();
        this.isUsingDefaultQuestionPack = true;
    }

    public boolean isUsingDefaultQuestionPack(){
        return this.isUsingDefaultQuestionPack;
    }


    public boolean isEmpty(){
        return this.totalQuestions == 0;
    }

    public List<Question> getQuestions(){
        List<Question> questions = new ArrayList<>();
        for(QuestionPack questionPack: questionPacks){
            questions.addAll(questionPack.getQuestions());
        }
        return questions;
    }

    public int getNumberOfQuestions(){
        return this.totalQuestions;
    }

}
