package com.jacsstuff.quizucan;

import android.util.Log;

import com.jacsstuff.quiz.Question;
import com.jacsstuff.quiz.QuestionPack;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by John on 30/08/2016.
 */
public class JSONParser {

    public void log(String msg){
        Log.i("parseFile()", msg);
    }

    public QuestionPack parseFile(String filepath){

        // try(InputStream inputStream = new FileInputStream(filepath);
        // JsonReader reader = Json.createReader(inputStream)){

        QuestionPack questionPack = new QuestionPack();
        try{
            InputStream inputStream = new FileInputStream(filepath);
            StringBuilder str = new StringBuilder();
            int input;
            while((input = inputStream.read()) != -1){
                str.append((char)input);
            }
            inputStream.close();
            questionPack = parseString(str.toString());

        }

        catch(IOException e){
            System.out.println(e.getMessage());

        }
        return questionPack;
    }

    public QuestionPack parseString(String input){

        QuestionPack questionPack = new QuestionPack();
        Question question;

        try{
            JSONObject quizObject = new JSONObject(input);
            JSONArray results = quizObject.getJSONArray("questions");
            JSONArray quizTopics = quizObject.getJSONArray("topics");

            for(int i=0;  i< quizTopics.length();i++){
                String topic = quizTopics.getString(i);
                if(!topic.equals("")){
                    topic = topic.substring(1,topic.length()-1);
                }
                questionPack.addTopic(topic);
            }
            questionPack.setName(quizObject.getString("name"));
            questionPack.setDescription(quizObject.getString("description"));

            for(int i=0;i<results.length();i++){
                JSONObject result = results.getJSONObject(i);
                question = new Question();
                question.addTopics(parseValues(result, "topics"));
                question.addAnswers(parseValues(result, "answerChoices"),false);
                question.addAnswers(parseValues(result, "correctAnswers"), true);
                question.setTrivia(result.getString("trivia"));
                question.setQuestionText(result.getString("questionText"));
                questionPack.addQuestion(question);
            }
        }catch(JSONException e){
            Log.i("JSON EXCEPTION","Oh well. Unable to read JSON string: " + input);
        }

        return questionPack;
    }



    private List<String> parseValues(JSONObject result, String arrayName){

        List<String> valuesList = new ArrayList<>();
        try {
            JSONArray jsonValueArray = result.getJSONArray(arrayName);
            if(jsonValueArray !=null){
                for(int i=0; i<jsonValueArray.length();i++){
                    String value = jsonValueArray.getString(i).trim();

                    value = value.trim();
                    if (value.startsWith("\"")) {
                        value = value.substring(1);
                    }
                    if (value.endsWith("\"")) {
                        value = value.substring(0, value.length() - 1);
                    }
                    if (!value.equals("")) {
                        valuesList.add(value);
                    }
                }
            }

        }catch(JSONException e){
            Log.i("JSONEXCEPTION:", " Unable to parseFile json list: " + arrayName);
        }
        return valuesList;
    }



}
