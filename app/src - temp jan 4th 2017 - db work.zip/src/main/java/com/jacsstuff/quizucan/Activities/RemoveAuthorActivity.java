package com.jacsstuff.quizucan.Activities;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import static com.jacsstuff.quizucan.Utils.DEL_AUTHOR_NAME_INTENT_EXTRA;

import com.jacsstuff.quizucan.AuthorPreferences;
import com.jacsstuff.quizucan.R;

public class RemoveAuthorActivity extends Activity {

    private Button yesButton;
    private Button noButton;
    private TextView dialogText;
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remove_author);
        context = RemoveAuthorActivity.this;
        Intent intent = getIntent();
        String authorName = intent.getStringExtra(DEL_AUTHOR_NAME_INTENT_EXTRA);
        if(authorName == null){
            authorName = "";
        }
        dialogText = (TextView)findViewById(R.id.dialogText);
        yesButton = (Button)findViewById(R.id.yesButton);
        noButton  = (Button)findViewById(R.id.noButton);

        dialogText.setText(getResources().getString(R.string.remove_author_dialog_text, authorName));

        noButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                finish();
            }
        });
        final String authorNameToDelete = authorName;
        yesButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                removeAuthorFromPreferences(authorNameToDelete);
                finish();
            }
        });
    }

    private void removeAuthorFromPreferences(String name){

        if(name.isEmpty()){
            return;
        }
        AuthorPreferences authorPreferences = new AuthorPreferences(context);
        authorPreferences.removeAuthorName(name);
        finish();
    }
}
