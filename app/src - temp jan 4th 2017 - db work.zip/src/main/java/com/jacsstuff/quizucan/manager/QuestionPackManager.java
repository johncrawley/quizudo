package com.jacsstuff.quizucan.manager;

import com.jacsstuff.quiz.QuestionPack;
import com.jacsstuff.quizucan.QuestionPackDetail;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by John on 19/12/2016.
 */
public interface QuestionPackManager {


        int saveQuestionPacks(Map<String, String> dataChunks, String authorName);
        List<QuestionPackDetail> getQuestionPackDetails();
        int deleteQuestionPacks(Set<Integer> ids);
        List <QuestionPack> getQuestionPacks(Set<Integer> ids);
        boolean isEmpty();
}

