package com.jacsstuff.quizucan.manager;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.jacsstuff.quiz.Question;
import com.jacsstuff.quiz.QuestionPack;
import com.jacsstuff.quizucan.JSONParser;

import java.util.List;

/**
 * Created by John on 31/12/2016.
 */
public class DBWriter {

    QuestionPackDBHelper mDbHelper;
    int questionPackIdCounter;

    public DBWriter(Context context){
        mDbHelper = new QuestionPackDBHelper(context);
        questionPackIdCounter = (int)System.currentTimeMillis();
    }


    public void addQuestionPack(String author, String questionPackName, String data){
        JSONParser parser = new JSONParser();
        QuestionPack questionPack = parser.parseString(data);
        //parser.parseFile
        String description = questionPack.getDescription();
        String name = questionPack.getName();
        long date = System.currentTimeMillis();

        //List<Question>
        for(Question question: questionPack.getQuestions()){
            String
            addRecord(question.get);

        }
        addQuestionPackRecord(ques

    }


    public long addQuestionPackRecord(QuestionPack questionPack){

        SQLiteDatabase db = mDbHelper.getWritableDatabase();
        ContentValues questionPackValues = new ContentValues();

        String authorName = "";//questionPack.getAuthorName(); TODO: change api  and parser to include author field
        String questionPackName = questionPack.getName();
        long downloadedTime = System.currentTimeMillis();
        String description = questionPack.getDescription();


        questionPackValues.put(DatabaseContract.QuestionPackEntry.COLUMN_NAME_AUTHOR, authorName);
        questionPackValues.put(DatabaseContract.QuestionPackEntry.COLUMN_NAME_TITLE, questionPackName);
        questionPackValues.put(DatabaseContract.QuestionPackEntry.COLUMN_NAME_DATE_DOWNLOADED, downloadedTime);
        questionPackValues.put(DatabaseContract.QuestionPackEntry.COLUMN_NAME_DESCRIPTION, questionPackName);

        long newRowId = db.insert(DatabaseContract.QuestionPackEntry.TABLE_NAME, null, questionPackValues);

        return newRowId;
    }

    public void addRecord(String question, String topics, String questionPackName, String authorName, long date){

        SQLiteDatabase db = mDbHelper.getWritableDatabase();

        //db.beginTransaction();
// Create a new map of values, where column names are the keys
        ContentValues questionValues = new ContentValues();

        questionValues.put(DatabaseContract.QuestionsEntry.COLUMN_NAME_QUESTION, question);
        questionValues.put(DatabaseContract.QuestionsEntry.COLUMN_NAME_TOPICS, topics);

// Insert the new row, returning the primary key value of the new row

        db.insert(DatabaseContract.QuestionsEntry.TABLE_NAME, null, questionValues);


        //db.setTransactionSuccessful();
        //db.endTransaction();
    }




}
