package com.jacsstuff.quizucan.Activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.NumberPicker;
import android.widget.TextView;
import static com.jacsstuff.quizucan.Utils.PREVIOUS_NUMBER_OF_QUESTIONS_PREFERENCE;
import static com.jacsstuff.quizucan.Utils.PREVIOUS_SUBMIT_ANSWER_ON_TOUCH_PREFERENCE;
import static com.jacsstuff.quizucan.Utils.PREVIOUS_SHOW_ANSWER_PREFERENCE;
import static com.jacsstuff.quizucan.Utils.DEFAULT_NUMBER_OF_QUESTIONS;
import static com.jacsstuff.quizucan.Utils.NUMBER_OF_QUESTIONS_INTENT_EXTRA;
import static com.jacsstuff.quizucan.Utils.DISPLAY_ANSWER_DIALOG_INTENT_EXTRA;
import static com.jacsstuff.quizucan.Utils.SUBMIT_ANSWER_ON_TOUCH_INTENT_EXTRA;
import static com.jacsstuff.quizucan.Utils.QUIZ_SETTINGS_PREFERENCES;
import com.jacsstuff.quizucan.QuestionPackSingleton;
import com.jacsstuff.quizucan.QuizSingleton;
import com.jacsstuff.quizucan.R;

public class ConfigureQuizActivity extends AppCompatActivity implements View.OnClickListener{

    private CheckBox instantResults;
    private CheckBox submitAnswerOnTouch;
    private Button resumeQuizButton;
    private QuestionPackSingleton questionPackSingleton;
    private NumberPicker numberPicker;
    private SharedPreferences preferences;
    private QuizSingleton quizSingleton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_configure_quiz);
        setupToolbar();
        quizSingleton = QuizSingleton.getInstance();
        preferences = getSharedPreferences(QUIZ_SETTINGS_PREFERENCES, MODE_PRIVATE);
        setupViews();
        setupQuestionsFoundText();
        setupNumberPicker();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home_enabled_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if(id == R.id.home_menu_item) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    private void setupViews(){
        questionPackSingleton = QuestionPackSingleton.getInstance();
        instantResults = (CheckBox) findViewById(R.id.instantResults);
        submitAnswerOnTouch = (CheckBox) findViewById(R.id.submitAnswerOnTouch);
        Button beginQuizButton = (Button)findViewById(R.id.beginQuiz);
        resumeQuizButton = (Button)findViewById(R.id.resumeQuiz);
        if(beginQuizButton == null){
            return;
        }
        beginQuizButton.setOnClickListener(this);
        resumeQuizButton.setOnClickListener(this);
        submitAnswerOnTouch.setChecked(preferences.getBoolean(PREVIOUS_SUBMIT_ANSWER_ON_TOUCH_PREFERENCE, false));
        instantResults.setChecked(preferences.getBoolean(PREVIOUS_SHOW_ANSWER_PREFERENCE, false));
    }
    @Override
    protected void onResume(){
        showResumeButtonIfQuizStarted();
        super.onResume();
    }

    private void showResumeButtonIfQuizStarted(){

        Log.i("ConfigQuiz", " quizSingleton: quiz is running: " + quizSingleton.isQuizRunning());
        if(!quizSingleton.isQuizRunning()){
            resumeQuizButton.setVisibility(View.GONE);
        }
        else{
            resumeQuizButton.setVisibility(View.VISIBLE);
        }
    }

    private void setupQuestionsFoundText(){
         TextView numberOfQuestionsAvailableText = (TextView) findViewById(R.id.numberOfQuestionsAvailable);
        int numberOfQuestions = questionPackSingleton.getNumberOfQuestions();
        String displayString = getResources().getString(R.string.configure_quiz_questions_maximum_found, numberOfQuestions);
        if(numberOfQuestions == 1){
            displayString = getResources().getString(R.string.configure_quiz_single_question_found);
        }
        if(questionPackSingleton.isUsingDefaultQuestionPack()){
            displayString = getResources().getString(R.string.configure_quiz_questions_found_default, numberOfQuestions);
        }
        if(numberOfQuestionsAvailableText == null){
            return;
        }
        numberOfQuestionsAvailableText.setText(displayString);
    }

    private void setupNumberPicker(){

        numberPicker = (NumberPicker)findViewById(R.id.numberPicker);
        if(numberPicker == null){
            return;
        }
        numberPicker.setMinValue(1);

        int maxValue = questionPackSingleton.getNumberOfQuestions();
        String [] valuesArray = new String[maxValue];
        for(int i = 0; i < maxValue; i++){
            valuesArray[i]  = "" + (i+1);
        }
        numberPicker.setWrapSelectorWheel(false);
        numberPicker.setDisplayedValues(valuesArray);

        numberPicker.setMaxValue(maxValue);
        numberPicker.setValue(getPreviousNumberOfQuestions());
    }



    //returns the value for the previously selected number of questions
    // if that value is above the current maximum, the current maximum is returned instead.
    private int getPreviousNumberOfQuestions() {
        int numberOfAvailableQuestions = questionPackSingleton.getNumberOfQuestions();
        int numberOfQuestions = preferences.getInt(PREVIOUS_NUMBER_OF_QUESTIONS_PREFERENCE, DEFAULT_NUMBER_OF_QUESTIONS);

        if (numberOfQuestions > numberOfAvailableQuestions){
            numberOfQuestions = numberOfAvailableQuestions;
        }
        if(numberOfQuestions < 1){
            numberOfQuestions = 1;
        }
        return numberOfQuestions;
    }

    private void setupToolbar(){
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        ActionBar actionBar = getSupportActionBar();
        if(actionBar != null){
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayOptions(ActionBar.DISPLAY_HOME_AS_UP | ActionBar.DISPLAY_SHOW_TITLE );
        }
    }


    public void onClick(View view){
        if(view.getId()==R.id.beginQuiz){
            saveCurrentConfig();
            quizSingleton.createNewQuiz(numberPicker.getValue());
            startQuizActivity();
        }
        else if(view.getId() == R.id.resumeQuiz){
            saveCurrentConfig();
            startQuizActivity();
        }
    }

    private void saveCurrentConfig(){
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt(PREVIOUS_NUMBER_OF_QUESTIONS_PREFERENCE, numberPicker.getValue());
        editor.putBoolean(PREVIOUS_SHOW_ANSWER_PREFERENCE, instantResults.isChecked());
        editor.putBoolean(PREVIOUS_SUBMIT_ANSWER_ON_TOUCH_PREFERENCE, submitAnswerOnTouch.isChecked());
        editor.apply();
    }

    private void startQuizActivity(){

        Log.i("startQuizActivity()", "Starting quiz activity.");
        Intent intent = new Intent(this, QuizActivity.class);
        intent.putExtra(NUMBER_OF_QUESTIONS_INTENT_EXTRA, numberPicker.getValue());
        intent.putExtra(DISPLAY_ANSWER_DIALOG_INTENT_EXTRA, instantResults.isChecked());
        intent.putExtra(SUBMIT_ANSWER_ON_TOUCH_INTENT_EXTRA, submitAnswerOnTouch.isChecked());

        startActivity(intent);
    }



}
