package com.jacsstuff.quizucan;

import android.content.Context;
import android.widget.Toast;

/**
 * Created by John on 19/01/2017.
 *
 *  Allows only one toast to be fired without being reset.
 *  Used where an error message and toast might be triggered by a WebViewClient
 *  and we don't want the HttpGrabber to fire off another one, which may or may not happen.
 */
public class OneShotToaster {

    private Context context;
    private boolean toasted; // default is false;
    public OneShotToaster(Context context){
        this.context = context;
    }

    public void toast(String message) {
        if (!toasted) {
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
        }
        toasted = true;
    }

    public void reset(){
        toasted = false;
    }
}
