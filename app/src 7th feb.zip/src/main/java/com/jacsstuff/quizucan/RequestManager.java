package com.jacsstuff.quizucan;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import static com.jacsstuff.quizucan.Utils.HTTP_PREFIX;
import static com.jacsstuff.quizucan.Utils.PARAM_DELIMITER;
import static com.jacsstuff.quizucan.Utils.PARAM_EQUALS;
import static com.jacsstuff.quizucan.Utils.QUESTION_PACK_REQUEST_DELIMITER;

/**
 * Created by John on 21/11/2016.
 */
public class RequestManager {
    private SharedPreferences preferences;
    private SharedPreferences.Editor editor;
    private Context context;
    private String defaultDownloadSite;
    private Map<String, String> paramsMap;

    public RequestManager(Context context){
        this.context = context;
        paramsMap = new HashMap<>();
        preferences = context.getSharedPreferences("downloadSite", Context.MODE_PRIVATE);
        defaultDownloadSite =  context.getResources().getString(R.string.default_download_site);
    }

    private String getParameters(){

        StringBuilder str = new StringBuilder();
        str.append(Utils.PARAMS_START);
        boolean isFirstParameter = true;
        for(String key: paramsMap.keySet()){
            if(!isFirstParameter){
                str.append(PARAM_DELIMITER);
            }
            str.append(key);
            str.append(PARAM_EQUALS);
            str.append(paramsMap.get(key));
            isFirstParameter = false;
        }
        return str.toString();
    }

    public String getUrl(RequestType requestType){
        String request = "";
        String downloadSite = preferences.getString(context.getResources().getString(R.string.prefkey_download_site), defaultDownloadSite);
        request = HTTP_PREFIX + downloadSite +  getRequestOperation(requestType) + getParameters();

        return request;
    }

    public String getDownloadSite(){
        return preferences.getString(context.getResources().getString(R.string.prefkey_download_site), defaultDownloadSite);
    }

    public void saveDownloadSite(String newDownloadSite){
        editor = preferences.edit();
        editor.putString(context.getResources().getString(R.string.prefkey_download_site), newDownloadSite);
        editor.apply();
    }

    public String getTempUrl(String tempSite, RequestType requestType){
        Log.i("requestManager", "tempSite: " + HTTP_PREFIX + tempSite + getRequestOperation(requestType) );
        return HTTP_PREFIX + tempSite + getRequestOperation(requestType);

    }

    public void setParameter(String paramName, String paramValue){
        paramsMap.put(paramName, paramValue);
    }

    public void setParameter(String paramName, Set<String> paramValues){
        String values = "";
        for(String value : paramValues){
            values += value + QUESTION_PACK_REQUEST_DELIMITER;
        }
        paramsMap.put(paramName, values.substring(0, values.length()-1));
    }


    private String getRequestOperation(RequestType requestType){

        String requestOperation = "";
        switch (requestType){
            case GET_QUESTION_PACKS:
                requestOperation = Utils.QUESTION_PACK_REQUEST;
                break;
            case LIST_QUESTION_PACKS:
                requestOperation = Utils.GET_LIST_OF_FILES_REQUEST;
                break;
            case TEST_CONNECTION:
                requestOperation = Utils.QUIZ_SITE_TEST_REQUEST;
                break;
        }
        return requestOperation;
    }


}
