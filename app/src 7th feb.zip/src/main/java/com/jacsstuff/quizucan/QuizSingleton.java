package com.jacsstuff.quizucan;

/**
 * Created by John on 19/01/2017.
 *
 *  Used to keep  a Quiz object in memory between activities, just for the purpose
 *  of allowing the user to resume a quiz after pressing the back button.
 *
 */
public class QuizSingleton {

    private static QuizSingleton instance;
    private Quiz quiz;

    private QuizSingleton(){
        quiz = new Quiz();
    }

    public static QuizSingleton getInstance(){
        if(instance == null){
            instance = new QuizSingleton();
        }
        return instance;
    }

    public Quiz getQuiz(){

        return this.quiz;
    }

    public void createNewQuiz(int maxQuestions){
        quiz.createQuiz(maxQuestions);
    }

    public boolean isQuizRunning(){
        return quiz.isRunning();
    }

}
