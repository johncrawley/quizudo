package com.jacsstuff.quizucan;

/**
 * Created by John on 05/08/2016.
 */
public enum ResultMessage {
    NONE_CORRECT ("Too bad, you didn't get any questions right this time around. Better luck next time."),
    LESS_THAN_TWENTY ("Oh well, please try again."),
    LESS_THAN_FORTY ("Nice try, you will do better next time!"),
    LESS_THAN_FIFTY ("You got nearly half of the questions correct!"),
    LESS_THAN_SIXTY ("Good effort! You can improve further, don't give up!"),
    LESS_THAN_SEVENTY ("Not a bad result at all, play again soon."),
    LESS_THAN_EIGHTY ("Good result, well done!"),
    LESS_THAN_NINTY ("Great result, you really know your stuff!"),
    LESS_THAN_PERFECT ("Congratulations, what an excellent result!"),
    PERFECT ("Congratulations, a perfect score!! You beat the quiz!!");

    private final String value;

    ResultMessage(String value){
        this.value = value;
    }

    public String getMessage(){
        return this.value;
    }
}
