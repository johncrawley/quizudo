package com.jacsstuff.quizucan;

/**
 * Created by John on 22/11/2016.
 */
public enum RequestType {

    LIST_QUESTION_PACKS(), GET_QUESTION_PACKS(), TEST_CONNECTION();

}
