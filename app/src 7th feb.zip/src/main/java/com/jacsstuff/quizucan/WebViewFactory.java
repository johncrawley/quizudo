package com.jacsstuff.quizucan;

import android.content.Context;
import android.os.AsyncTask;
import android.webkit.WebView;

import com.jacsstuff.quizucan.Activities.ClosableDialog;

/**
 * Created by John on 09/11/2016.
 * Helps create a web view with a JS interface to retrieve JavaScript-enabled web content.
 */
public class WebViewFactory {

    public static WebView getWebview(Context context, AsyncTask task, ClosableDialog closableDialg){

        WebView webView = new WebView(context);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebViewClient(new CustomWebViewClient(webView, closableDialg) );
        webView.addJavascriptInterface(new CustomJavaScriptInterface(task), "HtmlViewer");
        return webView;
    }
}
